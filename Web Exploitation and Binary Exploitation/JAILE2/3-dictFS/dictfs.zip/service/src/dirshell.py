#!/usr/bin/env python3
from best_dict import Dict
import json


class DirShell:
    def __init__(self):
        print(
            """░▒▓███████▓▒░░▒▓█▓▒░░▒▓██████▓▒░▒▓████████▓▒░▒▓████████▓▒░▒▓███████▓▒░      ░▒▓█▓▒░░▒▓█▓▒░  ░▒▓█▓▒░      ░▒▓████████▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓████▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░        ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓█▓▒░              ░▒▓█▓▒▒▓█▓▒░   ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░        ░▒▓█▓▒░   ░▒▓██████▓▒░ ░▒▓██████▓▒░        ░▒▓█▓▒▒▓█▓▒░   ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░        ░▒▓█▓▒░   ░▒▓█▓▒░            ░▒▓█▓▒░        ░▒▓█▓▓█▓▒░    ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░            ░▒▓█▓▒░        ░▒▓█▓▓█▓▒░    ░▒▓█▓▒░▒▓██▓▒░▒▓█▓▒░░▒▓█▓▒░ 
░▒▓███████▓▒░░▒▓█▓▒░░▒▓██████▓▒░  ░▒▓█▓▒░   ░▒▓█▓▒░     ░▒▓███████▓▒░          ░▒▓██▓▒░     ░▒▓█▓▒░▒▓██▓▒░▒▓████████▓▒░ 
                                                                                                                        
                                                                                                                        """
        )
        print(
            "Welcome to our completely custom filesystem! you can use the following commands in our in-house built DirShell™:"
        )
        print("ls - list files and directories")
        print("cd <dir> - change directory")
        print("cat <file> - print file contents")
        print("pwd - print current directory")
        print(
            "touch <file> - create/rewrite a file (root only) - if the filename starts with @ it is read-only [beta]"
        )
        print("mkdir <dir> - create a directory (root only) [beta]")
        print(
            "rewrite <file> - rewrite a file with hex characters (root only) - bypasses read-only @ prefix. USE WITH CAUTION [beta]"
        )
        print("su - switch to root user (secret password required)")
        print("exit - exit the shell")

        print("\n\n")
        print(
            "The filesystem is read-only for non-root users but we are experimenting with write capabilities in our current beta version"
        )

        print("\n\n")

        with open("mnt.json", "r") as f:
            mnt = Dict(
                json.load(f)
            )  # we are experimenting with the Dict class as we want to migrate away from `dict` because of the lack of features
        self.filesystem = {
            "a.txt": "I am a test content of a.txt",
            "b.txt": "HELLO WORLD",
            "c.txt": "Lorem ipsum dolor sit amet",
            "x": {"aa.txt": "aaaaaaaa"},
            "mnt": mnt,
            "z": {},
        }

        self.current_path = []
        self.is_root = False
        self.root_password = "<REDACTED>"

    def get_attribute(self, obj, attr):
        if hasattr(obj, attr):
            return getattr(obj, attr)
        else:
            return obj.get(attr)

    def get_current_dir(self, current_path=None):
        current = self.filesystem
        if not current_path:
            current_path = self.current_path
        for dir in current_path:
            try:
                current = getattr(current, dir)
            except:
                current = current.get(dir)
        return current

    def ls(self):
        current = self.get_current_dir()
        files = [
            f
            for f in current.keys()
            if isinstance(current[f], str) or isinstance(current[f], bytes)
        ]
        dirs = [d for d in current.keys() if not isinstance(current[d], str)]
        print("\nfiles:", ", ".join(files))
        print("\ndirs:", ", ".join(dirs))

    def cd(self, dirname):
        if dirname == "..":
            if self.current_path:
                return self.current_path.pop()
        d = self.get_attribute(self.get_current_dir(), dirname)
        if d is not None and not isinstance(d, str):
            self.current_path.append(dirname)
        else:
            print("No such directory")

    def cat(self, filename):
        current = self.get_current_dir()
        print(self.get_attribute(current, filename))

    def touch(self, filename, content):
        if not self.is_root:
            print("Permission denied")
            return
        current = self.get_current_dir()
        try:
            setattr(current, filename, content)
        except AttributeError:
            print(
                "The file you are trying to touch has a @ prefix which makes it read-only"
            )

    def debug_rewrite(self, filename, content):
        if not self.is_root:
            print("Permission denied")
            return
        current = self.get_current_dir()
        if hasattr(current, filename):
            current_copy = self.current_path.copy()
            current_top = current_copy.pop()
            setattr(
                self.get_current_dir(current_path=current_copy),
                current_top,
                current.replace(**{filename: bytes.fromhex(content)}),
            )

    def mkdir(self, dirname):
        if not self.is_root:
            print("Permission denied")
            return
        current = self.get_current_dir()
        setattr(current, dirname, Dict())

    def su(self, password):
        if password == self.root_password:
            self.is_root = True
        else:
            print("Wrong password")

    def pwd(self):
        print(f"/{'/'.join(self.current_path)}")


def main():
    shell = DirShell()
    while True:
        cmd = input(
            f"/{'/'.join(shell.current_path)}{'#>' if shell.is_root else '$>'} "
        ).split()
        if not cmd:
            continue
        try:
            if cmd[0] == "ls":
                shell.ls()
            elif cmd[0] == "cd":
                if len(cmd) > 1:
                    shell.cd(cmd[1])
            elif cmd[0] == "cat":
                if len(cmd) > 1:
                    shell.cat(cmd[1])
            elif cmd[0] == "touch":
                if len(cmd) > 1:
                    content = input("file contents: ")
                    shell.touch(cmd[1], content)
            elif cmd[0] == "rewrite":
                if len(cmd) > 1:
                    content = input("file contents: ")
                    shell.debug_rewrite(cmd[1], content)
            elif cmd[0] == "su":
                password = input("password: ")
                shell.su(password)
            elif cmd[0] == "pwd":
                shell.pwd()
            elif cmd[0] == "mkdir":
                if len(cmd) > 1:
                    shell.mkdir(cmd[1])

            elif cmd[0] == "exit":
                break
        except Exception as e:
            print("An error occurred", e)


if __name__ == "__main__":
    main()
