#!/usr/bin/env bun

const net = require("net");

const bake = async (ingredients) => {
  return await eval(ingredients);
};

const hasValidIngredients = (recipe) => {
  const FORBIDDEN_INGREDIENTS = /[()\/\[\];"'_!]/;
  if (FORBIDDEN_INGREDIENTS.test(recipe)) {
    console.error("🥖 These ingredients will spoil our bun!");
    return false;
  }
  const flavors = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const tasteProfile = [];
  for (let i = 0; i < recipe.length; i++) {
    const ingredient = recipe[i];
    if (flavors.includes(ingredient) && !tasteProfile.includes(ingredient)) {
      tasteProfile.push(ingredient);
    }
  }
  if (tasteProfile.length > 2) {
    console.error(
      "🍞 Too many flavors will ruin the bun! Found " + tasteProfile.length
    );
    return false;
  }
  return true;
};

const bakery = net.createServer((customer) => {
  console.log("🥐 A hungry customer has arrived at the bakery!");
  customer.write("tasty-bun> ");

  customer.on("data", async (order) => {
    try {
      const recipe = order.toString().trim();

      if (recipe === "exit") {
        customer.write("🥯 Thank you for visiting our bakery! Goodbye!\n");
        customer.end();
        return;
      }

      if (!hasValidIngredients(recipe)) {
        customer.write("🍩 Sorry, we can't bake with these ingredients!\n");
        customer.write("tasty-bun> ");
        return;
      }

      const bakedBun = await bake(recipe);
      customer.write(bakedBun + "\n");
    } catch (e) {
      console.error("Error during baking:", e);
      customer.write("🥞 Oops! The bun fell flat: " + e.toString() + "\n");
    }

    customer.write("tasty-bun> ");
  });

  customer.on("error", (err) => {
    console.error("Socket error:", err);
    customer.write("🥯 A socket error occurred, but we're still open!\n");
    customer.write("tasty-bun> ");
  });

  customer.on("end", () => {
    console.log("🥨 A customer has left our bakery");
  });
});

process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
});

process.on("uncaughtException", (err) => {
  console.error("Unhandled exception caught:", err);
});

const displayBakeryBanner = () => {
  console.log(`
  🍞🥐🥖🥯🍩🥨 "The Tasty Bun" Bakery 🥨🍩🥯🥖🥐🍞
  Welcome to our special bun shop!
  We are very particular about our ingredients...
  `);
};

displayBakeryBanner();
bakery.listen(2337, () => {
  console.log("🍞 Bakery now open on port 2337! Come get your tasty buns!");
});
