<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';
require_once 'classes/BlogPost.php';

$auth = new Auth();
$blogPost = new BlogPost();

$postId = $_GET['id'] ?? '';
if (empty($postId)) {
    header('Location: index.php');
    exit;
}

$post = $blogPost->getPostById($postId);
if (!$post) {
    header('Location: index.php');
    exit;
}

// Check permissions - allow viewing if public, if user is admin, or if user owns the post
if (!$post['is_public'] && !$auth->isAdmin() && (!$auth->isLoggedIn() || $post['author_id'] != $_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($post['title']) ?> - Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/purify.min.js" nonce="<?= $nonce ?>"></script>
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main">
        <div class="container">
            <?php if (!$post['is_public']): ?>
                <div class="alert" style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; margin-bottom: 2rem;">
                    ⚠️ This is a <?= $auth->isAdmin() ? 'DRAFT' : 'PENDING APPROVAL' ?> preview - not visible to public
                </div>
            <?php endif; ?>

            <article class="post-card" style="max-width: 800px; margin: 0 auto;">
                <h1 style="font-size: 2.5rem; margin-bottom: 1rem;"><?= htmlspecialchars($post['title']) ?></h1>
                <div class="post-meta" style="font-size: 1rem; margin-bottom: 2rem;">
                    By <?= htmlspecialchars($post['username']) ?> • 
                    <?= date('M j, Y g:i A', strtotime($post['created_at'])) ?>
                    <?php if (!$post['is_public']): ?>
                        <span style="color: #856404; font-weight: bold;"> • <?= $auth->isAdmin() ? 'DRAFT' : 'PENDING APPROVAL' ?></span>
                    <?php endif; ?>
                </div>
                
                <?php if ($auth->isAdmin() && !$post['is_public']): ?>
                    <div style="margin-bottom: 2rem;">
                        <?php 
                        $hasExternalImages = $blogPost->hasExternalImages($postId);
                        if ($hasExternalImages): ?>
                            <button onclick="processImages(this.getAttribute('postid'))" postid="<?= $post['id'] ?>" class="btn process-images-btn" style="background: #fd7e14; color: white; margin-right: 0.5rem;">
                                Process External Images
                            </button>
                        <?php endif; ?>

                        <button onclick="publishPost(this.getAttribute('postid'))" postid="<?= $post['id'] ?>" class="btn" style="background: #28a745; color: white;">
                            <?= $post['author_id'] == $_SESSION['user_id'] ? 'Publish Post' : 'Approve & Publish' ?>
                        </button>
                        <a href="<?= $post['author_id'] == $_SESSION['user_id'] ? 'drafts.php' : 'pending.php' ?>" class="btn" style="background: #6c757d; color: white; margin-left: 0.5rem; text-decoration: none; display: inline-block;">
                            Back to <?= $post['author_id'] == $_SESSION['user_id'] ? 'Drafts' : 'Pending' ?>
                        </a>
                    </div>
                    
                    <?php if ($hasExternalImages): ?>
                        <div class="alert" style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; margin-bottom: 2rem;">
                            ⚠️ This post contains external images that haven't been processed yet. Click "Process External Images" to download and host them locally before publishing.
                        </div>
                    <?php endif; ?>
                <?php elseif (!$post['is_public'] && $post['author_id'] == $_SESSION['user_id'] && !$auth->isAdmin()): ?>
                    <div style="margin-bottom: 2rem;">
                        <div class="alert" style="background: #e7f3ff; color: #0c5460; border: 1px solid #bee5eb; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                            📝 This post is waiting for admin approval before it can be published.
                        </div>
                        <a href="my-posts.php" class="btn" style="background: #6c757d; color: white; text-decoration: none; display: inline-block;">
                            Back to My Posts
                        </a>
                    </div>
                <?php endif; ?>

                <div class="post-content" style="font-size: 1.1rem; line-height: 1.8;" id="post-content">
                    <script nonce="<?= $nonce ?>">
                        const encodedContent = '<?= base64_encode($post['content']) ?>';
                        const decodedContent = atob(encodedContent);
                        document.getElementById('post-content').innerHTML = DOMPurify.sanitize(decodedContent);
                    </script>
                </div>
            </article>
        </div>
    </main>

    <script nonce="<?= $nonce ?>">
        let isPreviewProcessed = false;

        async function processImages(postId) {
            FlashMessage.confirm('Process all external images in this post? This will show you a preview with locally hosted images.', async (confirmed) => {
                if (!confirmed) return;
                
                try {
                    const response = await fetch('api/process-images.php', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ postId })
                    });

                    const result = await response.json();
                    
                    if (response.ok) {
                        const processedContent = atob(result.processedContent);
                        document.getElementById('post-content').innerHTML = DOMPurify.sanitize(processedContent);
                        
                        const processBtn = document.querySelector('button[onclick*="processImages"]');
                        if (processBtn) {
                            processBtn.textContent = 'Images Processed (Preview)';
                            processBtn.style.background = '#6c757d';
                            processBtn.disabled = true;
                        }
                        
                        const existingNotice = document.querySelector('.preview-notice');
                        if (!existingNotice) {
                            const notice = document.createElement('div');
                            notice.className = 'alert preview-notice';
                            notice.style.cssText = 'background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; margin-bottom: 2rem;';
                            notice.innerText = '📱 Preview Mode: Images are processed for preview only. They will be permanently processed when you publish the post.';
                            document.querySelector('.post-card').insertBefore(notice, document.querySelector('.post-content'));
                        }
                        
                        isPreviewProcessed = true;
                        FlashMessage.success('Images processed for preview!');
                    } else {
                        FlashMessage.error('Error: ' + result.error);
                    }
                } catch (error) {
                    FlashMessage.error('Network error: ' + error.message);
                }
            });
        }

        async function publishPost(postId) {
            FlashMessage.confirm('Are you sure you want to publish this post?', async (confirmed) => {
                if (!confirmed) return;
                
                try {
                    const response = await fetch('api/publish.php', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ postId })
                    });

                    const result = await response.json();
                    
                    if (response.ok) {
                        FlashMessage.success('Post published successfully!');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        FlashMessage.error('Error: ' + result.error);
                    }
                } catch (error) {
                    FlashMessage.error('Network error: ' + error.message);
                }
            });
        }
    </script>
</body>
</html>
