<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';
require_once 'classes/BlogPost.php';

$auth = new Auth();
$blogPost = new BlogPost();

$posts = $blogPost->getPublicPosts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/purify.min.js" nonce="<?= $nonce ?>"></script>
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main">
        <div class="container">
            <div class="hero">
                <h2>Documenting the Evolution of Internet Culture</h2>
                <p>From Rage Comics to TikTok Trends</p>
            </div>

            <div class="posts">
                <?php foreach ($posts as $post): ?>
                    <article class="post-card">
                        <h3><?= htmlspecialchars($post['title']) ?></h3>
                        <div class="post-meta">
                            By <?= htmlspecialchars($post['username']) ?> • 
                            <?= date('M j, Y', strtotime($post['created_at'])) ?>
                        </div>
                        <div class="post-content">
                            <script nonce="<?= $nonce ?>">
                                encodedContent = '<?= base64_encode($post['content']) ?>';
                                decodedContent = atob(encodedContent);
                                document.write(DOMPurify.sanitize(decodedContent));
                            </script>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
</body>
</html>
