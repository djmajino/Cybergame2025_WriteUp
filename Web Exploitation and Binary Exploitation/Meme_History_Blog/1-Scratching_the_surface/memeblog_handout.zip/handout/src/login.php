<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';

$auth = new Auth();
$error = '';

if ($_POST) {
    if ($auth->login($_POST['username'], $_POST['password'])) {
        header('Location: index.php');
        exit;
    } else {
        $error = 'Invalid credentials';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <div class="container" style="max-width: 400px; margin-top: 5rem;">
        <form class="post-form" method="POST">
            <h2>Login</h2>

            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary">Login</button>
            <p style="margin-top: 1rem; text-align: center;">
                Don't have an account? <a href="register.php">Register here</a><br>
                <small>Default admin: username "admin", password "password"</small>
            </p>
        </form>
    </div>

    <?php if ($error): ?>
        <script nonce="<?= $nonce ?>">
            FlashMessage.error('<?= htmlspecialchars($error) ?>');
        </script>
    <?php endif; ?>
</body>
</html>
