<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';
require_once 'classes/BlogPost.php';

$auth = new Auth();
$auth->requireAdmin();

$blogPost = new BlogPost();
$pendingPosts = $blogPost->getAllPendingPosts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Posts - Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main">
        <div class="container">
            <h2 style="color: white; margin-bottom: 2rem;">Posts Pending Approval</h2>

            <?php if (empty($pendingPosts)): ?>
                <div class="post-card">
                    <p>No posts pending approval.</p>
                </div>
            <?php else: ?>
                <div class="posts">
                    <?php foreach ($pendingPosts as $post): ?>
                        <article class="post-card">
                            <h3><?= htmlspecialchars($post['title']) ?></h3>
                            <div class="post-meta">
                                By <?= htmlspecialchars($post['username']) ?> • 
                                Submitted: <?= date('M j, Y g:i A', strtotime($post['created_at'])) ?>
                            </div>
                            <div class="draft-actions" style="margin-top: 1rem;">
                                <a href="preview.php?id=<?= $post['id'] ?>" class="btn btn-primary">Review</a>
                                <button  onclick="publishPost(this.getAttribute('postid'))" postid="<?= $post['id'] ?>" class="btn" style="background: #28a745; color: white; margin-left: 0.5rem;">Approve & Publish</button>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script nonce="<?= $nonce ?>">
        async function publishPost(postId) {
            FlashMessage.confirm('Are you sure you want to approve and publish this post?', async (confirmed) => {
                if (!confirmed) return;
                
                try {
                    const response = await fetch('api/publish.php', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ postId })
                    });

                    const result = await response.json();
                    
                    if (response.ok) {
                        FlashMessage.success('Post approved and published!');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        FlashMessage.error('Error: ' + result.error);
                    }
                } catch (error) {
                    FlashMessage.error('Network error: ' + error.message);
                }
            });
        }
    </script>
</body>
</html>
