<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';
require_once 'classes/BlogPost.php';

$auth = new Auth();
$auth->requireLogin();

$blogPost = new BlogPost();
$myPosts = $blogPost->getDraftsByAuthor($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Posts - Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main">
        <div class="container">
            <h2 style="color: white; margin-bottom: 2rem;">My Posts</h2>

            <?php if (empty($myPosts)): ?>
                <div class="post-card">
                    <p>You haven't created any posts yet. <a href="create.php">Create your first post!</a></p>
                </div>
            <?php else: ?>
                <div class="posts">
                    <?php foreach ($myPosts as $post): ?>
                        <article class="post-card">
                            <h3><?= htmlspecialchars($post['title']) ?></h3>
                            <div class="post-meta">
                                Created: <?= date('M j, Y g:i A', strtotime($post['created_at'])) ?>
                                <?php if ($post['updated_at'] !== $post['created_at']): ?>
                                    • Updated: <?= date('M j, Y g:i A', strtotime($post['updated_at'])) ?>
                                <?php endif; ?>
                                <span style="color: #856404; font-weight: bold;"> • PENDING APPROVAL</span>
                            </div>
                            <div class="draft-actions" style="margin-top: 1rem;">
                                <a href="preview.php?id=<?= $post['id'] ?>" class="btn btn-primary">Preview</a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
