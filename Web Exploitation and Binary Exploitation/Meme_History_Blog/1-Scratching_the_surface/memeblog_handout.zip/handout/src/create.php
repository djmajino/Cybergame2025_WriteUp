<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';
require_once 'classes/BlogPost.php';

$auth = new Auth();
$auth->requireLogin();

if ($_POST) {
    $blogPost = new BlogPost();
    $postId = $blogPost->create($_POST['title'], $_POST['content'], $_SESSION['user_id']);
    header("Location: preview.php?id=$postId");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post - Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/purify.min.js" nonce="<?= $nonce ?>"></script>
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="main">
        <div class="container">
            <form class="post-form" method="POST">
                <h2>Create New Post</h2>
                <p style="margin-bottom: 1.5rem; color: #666;">
                    <?php if ($auth->isAdmin()): ?>
                        As an admin, your post will be created as a draft. You can publish it immediately from the preview page.
                    <?php else: ?>
                        Your post will be submitted for admin approval before being published.
                    <?php endif; ?>
                </p>
                
                <div class="form-group">
                    <label for="title">Title:</label>
                    <input type="text" id="title" name="title" required>
                </div>

                <div class="form-group">
                    <label for="content">Content:</label>
                    <textarea id="content" name="content" rows="15" required></textarea>
                    <small>HTML is allowed. Images from external URLs will be automagically hosted.</small>
                </div>

                <button type="submit" class="btn btn-primary">
                    <?= $auth->isAdmin() ? 'Create Draft' : 'Submit for Approval' ?>
                </button>
            </form>
        </div>
    </main>
</body>
</html>
