class FlashMessage {
  static show(message, type = "info", duration = 5000) {
    // Remove existing flash messages
    const existing = document.querySelectorAll(".flash-message");
    existing.forEach((el) => el.remove());

    // Create flash message element
    const flash = document.createElement("div");
    flash.className = `flash-message flash-${type}`;
    flash.innerHTML = `
            <span></span>
            <button class="flash-close">×</button>
        `;
    flash.querySelector(".flash-close").onclick = () => {
      flash.remove();
    };

    flash.querySelector("span").textContent = message;

    // Add to page
    document.body.appendChild(flash);

    // Auto remove after duration
    setTimeout(() => {
      if (flash.parentElement) {
        flash.remove();
      }
    }, duration);
  }

  static success(message, duration = 5000) {
    this.show(message, "success", duration);
  }

  static error(message, duration = 7000) {
    this.show(message, "error", duration);
  }

  static warning(message, duration = 6000) {
    this.show(message, "warning", duration);
  }

  static confirm(message, callback) {
    // Remove existing confirm dialogs
    const existing = document.querySelectorAll(".flash-confirm");
    existing.forEach((el) => el.remove());

    const confirm = document.createElement("div");
    confirm.className = "flash-confirm";
    confirm.innerHTML = `
            <div class="flash-confirm-content">
                <p></p>
                <div class="flash-confirm-buttons">
                    <button class="btn btn-primary flash-confirm-yes">Yes</button>
                    <button class="btn flash-confirm-no">Cancel</button>
                </div>
            </div>
        `;
    confirm.querySelector("p").textContent = message;

    document.body.appendChild(confirm);

    // Handle button clicks
    confirm.querySelector(".flash-confirm-yes").onclick = () => {
      confirm.remove();
      callback(true);
    };

    confirm.querySelector(".flash-confirm-no").onclick = () => {
      confirm.remove();
      callback(false);
    };
  }
}
