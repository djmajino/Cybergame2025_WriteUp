<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/BlogPost.php';

header('Content-Type: application/json');

$auth = new Auth();
$auth->requireAdmin();

$data = json_decode(file_get_contents('php://input'), true);
$postId = $data['postId'] ?? '';

if (empty($postId)) {
    http_response_code(400);
    echo json_encode(['error' => 'Post ID required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$blogPost = new BlogPost();
if ($blogPost->publish($postId)) {
    echo json_encode(['success' => true, 'message' => 'Post published']);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to publish post']);
}

?>
