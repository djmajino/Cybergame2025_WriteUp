<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/BlogPost.php';

header('Content-Type: application/json');

$auth = new Auth();
$auth->requireAdmin();


$data = json_decode(file_get_contents('php://input'), true);
$postId = $data['postId'] ?? '';

if (empty($postId)) {
    http_response_code(400);
    echo json_encode(['error' => 'Post ID required']);
    exit;
}

$blogPost = new BlogPost();

try {
    $post = $blogPost->getPostById($postId);
    if (!$post) {
        http_response_code(404);
        echo json_encode(['error' => 'Post not found']);
        exit;
    }

    $processedContent = $blogPost->getProcessedContentPreview($post['content']);
    echo json_encode([
        'success' => true, 
        'message' => 'Images processed for preview',
        'processedContent' => base64_encode($processedContent)
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error processing images: ' . $e->getMessage()]);
}

?>
