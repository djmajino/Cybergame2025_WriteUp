<?php
$nonce = base64_encode(random_bytes(8));

$csp = "script-src 'nonce-$nonce' 'sha256-0fQyyBH4tw1haqwijgfZtcoBLBYVWJPwJ4iJjHFUwRY=' 'sha256-I1rbvXqXZmrMValU4SWC65enfArEBy0F8Yc7lJyp2Ms=' 'unsafe-hashes' 'self'; " .
       "style-src 'self' 'unsafe-inline'; " .
       "img-src 'self'; " .
       "base-uri 'self'; " .
       "object-src 'none'; ";

header("Content-Security-Policy: $csp");
?>
