<?php
// Ensure Auth is available
if (!isset($auth)) {
    require_once __DIR__ . '/../classes/Auth.php';
    $auth = new Auth();
}
?>
<header class="header">
    <div class="container">
        <h1 class="logo">🐸 Meme History Chronicles</h1>
        <nav class="nav">
            <?php if ($auth->isLoggedIn() && $auth->isAdmin()): ?>
                <span class="admin-message" flag1="SK-CERT{flag1_for_testing}">Hello, Admin! (˶˃ ᵕ ˂˶)</span>
            <?php endif; ?>
            <a href="index.php">Home</a>
            <?php if ($auth->isLoggedIn()): ?>
                <a href="create.php">Create Post</a>
                <a href="my-posts.php">My Posts</a>
                <?php if ($auth->isAdmin()): ?>
                    <a href="pending.php">Pending Approval</a>
                <?php endif; ?>
                <a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
