<?php
require_once 'includes/csp.php';
require_once 'classes/Auth.php';

$auth = new Auth();
$error = '';
$success = '';

if ($_POST) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if (empty($username) || empty($password)) {
        $error = 'Username and password are required';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = 'Username can only contain letters, numbers, and underscores';
    } elseif ($auth->register($username, $password)) {
        $success = 'Registration successful! You can now login and create posts.';
    } else {
        $error = 'Username already exists';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Meme History Blog</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/flash.js" nonce="<?= $nonce ?>"></script>
</head>
<body>
    <div class="container" style="max-width: 400px; margin-top: 5rem;">
        <form class="post-form" method="POST">
            <h2>Create Account</h2>

            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                <small>Letters, numbers, and underscores only</small>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <small>Minimum 6 characters</small>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>

            <button type="submit" class="btn btn-primary">Register</button>
            <p style="margin-top: 1rem; text-align: center;">
                Already have an account? <a href="login.php">Login here</a>
            </p>
        </form>
    </div>

    <?php if ($error): ?>
        <script nonce="<?= $nonce ?>">
            FlashMessage.error('<?= htmlspecialchars($error) ?>');
        </script>
    <?php endif; ?>

    <?php if ($success): ?>
        <script nonce="<?= $nonce ?>">
            FlashMessage.success('<?= htmlspecialchars($success) ?>');
        </script>
    <?php endif; ?>
</body>
</html>
