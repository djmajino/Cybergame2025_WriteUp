<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/ImageManager.php';

class BlogPost {
    private $db;
    private $imageManager;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->imageManager = new ImageManager();
    }

    public function create($title, $content, $authorId) {
        $id = bin2hex(random_bytes(16));
        
        // Don't process images automatically for non-admin users
        // Content is stored as-is for review
        
        $query = "INSERT INTO posts (id, title, content, author_id) VALUES (?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$id, $title, $content, $authorId]);
        
        return $id;
    }

    public function publish($postId) {
        // First process any external images before publishing
        $this->processPostImages($postId);
        
        $query = "UPDATE posts SET is_public = TRUE WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$postId]);
    }

    public function getPublicPosts($limit = 100, $offset = 0) {
        $query = "SELECT p.*, u.username FROM posts p 
                  JOIN users u ON p.author_id = u.id 
                  WHERE p.is_public = TRUE 
                  ORDER BY p.created_at DESC 
                  LIMIT " . intval($limit) . " OFFSET " . intval($offset);
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDraftsByAuthor($authorId) {
        $query = "SELECT * FROM posts WHERE author_id = ? AND is_public = FALSE ORDER BY created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$authorId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllPendingPosts() {
        $query = "SELECT p.*, u.username FROM posts p 
                  JOIN users u ON p.author_id = u.id 
                  WHERE p.is_public = FALSE 
                  ORDER BY p.created_at ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getPostById($postId) {
        $query = "SELECT p.*, u.username FROM posts p 
                  JOIN users u ON p.author_id = u.id 
                  WHERE p.id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$postId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function processPostImages($postId) {
        $query = "SELECT content FROM posts WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$postId]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$post) {
            return false;
        }

        // Process images in content and update the database
        $processedContent = $this->processImages($post['content']);
        
        // Update the post with processed content
        $query = "UPDATE posts SET content = ? WHERE id = ?";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$processedContent, $postId]);
    }

    public function getProcessedContentPreview($content) {
        return $this->processImages($content, true);
    }

    private function processImages($content, $isTemporary = false) {
        // Only process if content starts with <img src=
        // We only support a single thumbnail image at the beginning of posts
        // This creates a nicer, more consistent format for the blog
        if (!preg_match('/^\s*<img\s+src=/i', trim($content))) {
            return $content;
        }
        
        // Find the first image URL and replace with hosted version
        $pattern = '/^(\s*<img\s+[^>]*src=")(\w+:\/\/[^"]+)("[^>]*>)/i';
        return preg_replace_callback($pattern, function($matches) use ($isTemporary) {
            try {
                $hostedFilename = $this->imageManager->downloadAndStore($matches[2], $isTemporary);
                return $matches[1] . 'uploads/' . $hostedFilename . $matches[3];
            } catch (Exception $e) {
                return $matches[0]; // Keep original if download fails
            }
        }, $content, 1); // Limit to 1 replacement
    }

    public function hasExternalImages($postId) {
        $query = "SELECT content FROM posts WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$postId]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$post) {
            return false;
        }

        // Only check if content starts with <img src= (thumbnail support only)
        if (!preg_match('/^\s*<img\s+src=/i', trim($post['content']))) {
            return false;
        }

        // Check if the first image has external URL
        $pattern = '/^\s*<img\s+[^>]*src="(\w+:\/\/[^"]+)"/i';
        return preg_match($pattern, trim($post['content'])) === 1;
    }
}
?>
