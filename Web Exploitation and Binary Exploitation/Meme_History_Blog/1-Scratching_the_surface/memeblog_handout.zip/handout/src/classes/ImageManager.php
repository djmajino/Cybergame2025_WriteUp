<?php

class ImageManager {
    private $uploadDir = __DIR__ . '/../uploads/';

    public function __construct() {
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
        
        // Run cleanup on construction (triggered by normal app usage)
        $this->cleanupTempFiles();
    }

    public function downloadAndStore($imageUrl, $isTemporary) {
        if ($isTemporary) {
            $tempUploadDir = $this->uploadDir . 'temp/';
            if (!is_dir($tempUploadDir)) {
                mkdir($tempUploadDir, 0755, true);
            }
        }

        // Validate URL
        if (!filter_var($imageUrl, FILTER_VALIDATE_URL)) {
            throw new Exception('Invalid URL');
        }

        // Download image
        $imageData = file_get_contents($imageUrl);
        if ($imageData === false) {
            throw new Exception('Failed to download image');
        }

        // Check file size
        if (strlen($imageData) < 1 || strlen($imageData) > 1048576) {
            throw new Exception('Image size must be between 1 byte and 1MB');
        }

        // Get file extension
        $imageInfo = getimagesizefromstring($imageData);
        if ($imageInfo === false) {
            throw new Exception('Invalid image format');
        }

        $extension = match($imageInfo['mime']) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            default => 'img', // there are other formats, but we will use a generic extension because there's so many of them
        };

        

        $hash = md5($imageData);
        $filename = $hash . '.' . $extension;
        

        $filepath = $isTemporary ? $tempUploadDir . $filename : $this->uploadDir . $filename;

        // Save file
        file_put_contents($filepath, $imageData);

        $prefix = $isTemporary ? 'temp/' : '';

        return $prefix . $hash . '.' . $extension;
    }

    public function cleanupTempFiles() {
        $tempUploadDir = $this->uploadDir . 'temp/';
        
        if (!is_dir($tempUploadDir)) {
            return;
        }

        $files = glob($tempUploadDir . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                // Delete files older than 5 minutes
                if (time() - filemtime($file) > 300) {
                    unlink($file);
                }
            }
        }
    }
}
?>
