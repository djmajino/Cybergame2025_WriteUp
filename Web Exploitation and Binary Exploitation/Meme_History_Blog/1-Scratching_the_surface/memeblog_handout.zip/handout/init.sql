CREATE DATABASE IF NOT EXISTS blogig;
USE blogig;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE posts (
    id VARCHAR(32) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author_id INT NOT NULL,
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id)
);

INSERT INTO users (username, password_hash, is_admin) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', TRUE); -- Password: `password` only for testing, changed in remote ;))
INSERT INTO posts (id, title, content, author_id, is_public) VALUES
/* 1 */('a1b2c3d4e5f6789012345678abcdef01',
  'All Your Base Are Belong To Us: The Dawn of Gaming Memes',
  '<img src="uploads/b00aabb4f2577a13ceabe3ca70b42280.img"></img><p>This broken-English taunt from the 1992 European Mega Drive port of <em>Zero Wing</em> exploded on forums in 2000 after a Flash music video hit Newgrounds and Something Awful. It is now cited as one of the first truly global gaming memes.</p><p>The episode proved that even a localization error could become a lasting cultural reference once remixable media met fast-growing message boards.</p>',
  1, TRUE),

/* 2 */('fedcba0987654321abcdef1234567890',
  'Dancing Baby: The Original Viral Video',
  '<img src="uploads/b0590392b5d3738f257888edc44d1b97.img"></img><p>Also called "Baby Cha-Cha," this 3-D render escaped Autodesk demo files in 1996 via e-mail chains and CompuServe, then crossed into mainstream television with <em>Ally McBeal</em> (1998).</p><p>Its looping, low-poly charm showed that GIF-sized novelty could travel far before YouTube or social media existed.</p>',
  1, TRUE),

/* 3 */('123456789abcdef0fedcba0987654321',
  'Hampster Dance: The Soundtrack of Early Internet',
  '<img src="uploads/ad4b0f606e0f8465bc4c4c170b37e1a3.img"></img><p>Canadian student Deidre LaCarte''s 1998 page tiled dozens of dancing hamsters over a sped-up sample of Roger Miller''s "Whistle Stop." Traffic repeatedly crashed free hosts, inspiring copycats and a 2000 novelty single.</p><p>The site cemented the "endless-scroll, endless-loop" formula for attention-grabbing web humor.</p>',
  1, TRUE),

/* 4 */('987654321fedcba0123456789abcdef0',
  'YTMND and the Birth of Remix Culture',
  '<img src="uploads/d835884373f4d6c8f24742ceabe74946.img"></img><p>Max Goldberg''s single-serving <em>yourethemannowdog.com</em> (2001) evolved into YTMND.com on 1 April 2004, letting anyone combine a tiled image, zoom text, and looping audio in one click.</p><p>Fads like "Picard Song," "LOL Internet," and countless mashups demonstrated how micro-sites could scaffold a community of remix artists long before TikTok.</p>',
  1, TRUE),

/* 5 */('abcdef0123456789fedcba0987654321',
  'O RLY Owl: The Question That Defined Forums',
  '<img src="uploads/64cdd2181ef9fcec482626518de680be.img"></img><p>The snowy-owl macro asking "O RLY?" appeared on Usenet in 2001 but flooded boards such as Something Awful and 4chan circa 2004-05, spawning call-and-response replies such as "YA RLY" and "NO WAI."</p><p>It distilled skepticism into two syllables, proving how image macros could become a shared vernacular.</p>',
  1, TRUE),

/* 6 */('11223344556677889900aabbccddeeff',
  'Rickrolling (2007): The Era of Bait-and-Switch Links',
  '<img src="uploads/5797f000c425d7855ca39451ba27576c.img"></img><p>4chan''s April Fools'' gag of disguising links to Rick Astley''s 1987 hit "Never Gonna Give You Up" turned into a worldwide prank. By 2008 even YouTube itself "Rickrolled" its front page.</p><p>The meme re-framed clickbait as comedy and revived Astley''s career decades later.</p>',
  1, TRUE),

/* 7 */('ffeeddccbbaa99887766554433221100',
  'Trollface & Rage Comics: Trolling Gets a Face',
  '<img src="uploads/1b7c22a214949975556626d7217e9a39.img"></img><p>Drawn in MS Paint on 19 Sep 2008 by Carlos Ramirez, Trollface quickly migrated from DeviantArt to 4chan, Reddit, and beyond, becoming shorthand for deliberate online provocation.</p><p>It led an entire cast of black-and-white "rage faces" that dominated early-2010s meme panels.</p>',
  1, TRUE),

/* 8 */('0f1e2d3c4b5a69788796a5b4c3d2e1f0',
  'Gangnam Style: YouTube Breaks a Billion',
  '<img src="uploads/64aa19b26f04babbaafaf27b5dccd20a.img"></img><p>PSY''s satirical K-pop single (July 2012) inspired a dance craze, parodies by world leaders, and on 21 Dec 2012 became the first YouTube video to pass one billion views.</p><p>Its success proved that algorithm-driven virality could rewrite music-industry records overnight.</p>',
  1, TRUE),

/* 9 */('abcdefabcdefabcdefabcdefabcdefab',
  'Doge: Wow. Much Impact. So Meme.',
  '<img src="uploads/dbce44312027ca7f16631937e62ff5e9.img"></img><p>An expressive Shiba Inu named Kabosu, captioned in multicolor Comic Sans, dominated 2013 timelines and later inspired the cryptocurrency Dogecoin.</p><p>Its playful broken-English interior monologue ("such wow") kept the image fresh through countless spinoffs and even a NASA "To the Moon" funding joke.</p>',
  1, TRUE),

/*10*/('00112233445566778899aabbccddeeff',
  'Distracted Boyfriend: Stock Photo, Infinite Templates',
  '<img src="uploads/2414af4242aa28a615c45c107972c30e.img"></img><p>Antonio Guillem''s 2015 royalty-free photo went viral in August 2017 as users relabeled the wandering boyfriend to illustrate every variety of temptation.</p><p>The meme''s plug-and-play flexibility showcased how commercial stock images could gain a surreal second life online.</p>',
  1, TRUE),

/*11*/('99aabbccddeeff001122334455667788',
  'Woman Yelling at a Cat (2019): Bravo Meets Smudge',
  '<img src="uploads/8c80ea242bd4fd440decbc2752172797.img"></img><p>A 2019 tweet paired Taylor Armstrong''s sobbing <em>Real Housewives</em> screenshot with Smudge the salad-hating cat. The juxtaposition captured universal exasperation and Smudge''s Instagram now tops one million followers.</p><p>The split-panel format revitalized reaction-image culture heading into the 2020s.</p>',
  1, TRUE),

/*12*/('fedcba98765432100123456789abcdef',
  '"Sus" & Among Us (2020): Trust No One',
  '<img src="uploads/646022e589a4bff3cc22122b381e68fe.img"></img><p>During the pandemic boom for indie game <em>Among Us</em>, players'' shorthand "sus" ("suspicious") leapt from in-game chat to every corner of the internet.</p><p>Its minimalism ("red sus") became the decade''s catch-all accusation and the word now appears in the Oxford English Dictionary.</p>',
  1, TRUE),

/*13*/('0123456789abcdeffedcba9876543210',
  'Skibidi Toilet: Gen-Alpha''s Surreal Saga',
  '<img src="uploads/b50a274d50211131794aca8d7875049b.img"></img><p>Russian-Georgian animator DaFuq!?Boom!''s Source Filmmaker series (2023) singing heads in killer toilets battling camera-headed soldiers racked up billions of TikTok and YouTube views.</p><p>The rapid-fire micro-episodes proved how algorithm-feeding serialization could mint a fresh mythos for the short-video age.</p>',
  1, TRUE),

/*14*/('aabbccddeeff00112233445566778899',
  'Tung Tung Tung Sahur: Indonesian Brain-Rot Goes Global',
  '<img src="uploads/c666276f3da2d6bded147d69d5037517.img"></img><p>An AI-rendered wooden stick creature chanting an on-beat Ramadan wake-up call spread from TikTok user @noxaasht to every platform in spring 2024, slotting into the Italian-Brainrot trend of bizarre mash-ups.</p><p>Its cross-cultural absurdity highlighted how local memes can now leap language barriers overnight.</p>',
  1, TRUE);