const express = require("express");
const puppeteer = require("puppeteer");

const app = express();
const PORT = process.env.PORT || 3001;
const BLOG_URL = process.env.BLOG_URL || "http://web";

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const visit = async (url) => {
  let browser;
  try {
    // Use unique user data directory to avoid profile conflicts when running multiple instances
    const uniqueUserDataDir = `/tmp/puppeteer-${Date.now()}-${Math.random()
      .toString(36)
      .substr(2, 9)}`;

    browser = await puppeteer.launch({
      headless: "new",
      pipe: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        '--js-flags="--jitless --noexpose_wasm"',
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-web-security",
        "--no-first-run",
        "--no-default-browser-check",
      ],
      dumpio: true,
      userDataDir: uniqueUserDataDir,
    });

    const context = await browser.createBrowserContext();
    let page = await context.newPage();

    await page.goto(`${BLOG_URL}/login.php`, {
      timeout: 10000,
      waitUntil: "domcontentloaded",
    });

    await page.waitForSelector("input[name=username]");
    await page.type("input[name=username]", "admin");
    await page.type("input[name=password]", "password");
    await page.click("button[type=submit]");

    await sleep(2000);

    await page.close();

    page = await context.newPage();
    console.log(`Visiting URL: ${url}`);

    await page.goto(url, {
      timeout: 10000,
      waitUntil: "domcontentloaded",
    });

    console.log(`Page loaded: ${url}`);

    const processImagesButton = await page.$(".process-images-btn");
    if (processImagesButton) {
      await page.click(".process-images-btn");
      console.log(`Clicked process images button on: ${url}`);
      await page.waitForSelector(".flash-confirm-yes", {
        timeout: 500,
      });
      await page.click(".flash-confirm-yes");
      console.log(`Flash confirmation clicked found on: ${url}`);
    }
    await sleep(10000);

    await browser.close();
    browser = null;

    return { success: true, message: "URL visited successfully" };
  } catch (err) {
    console.log("Error during visit:", err);
    return { success: false };
  } finally {
    if (browser) await browser.close();
  }
};

app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Admin Bot</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            form { background: #f5f5f5; padding: 20px; border-radius: 8px; }
            input[type=url] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
            button { background: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
            button:hover { background: #005a87; }
        </style>
    </head>
    <body>
        <h1>Admin Bot</h1>
        <p>Submit a URL for the admin to visit. The admin will be logged into the blog application.</p>
        <form method="POST" action="/visit">
            <label for="url">URL to visit:</label>
            <input type="url" id="url" name="url" required placeholder="https://example.com">
            <button type="submit">Submit</button>
        </form>
    </body>
    </html>
  `);
});

app.post("/visit", async (req, res) => {
  const { url } = req.body;

  if (!url) {
    return res.status(400).json({ error: "URL is required" });
  }

  try {
    new URL(url);
  } catch {
    return res.status(400).json({ error: "Invalid URL format" });
  }

  console.log(`Received request to visit: ${url}`);

  visit(url).then((result) => {
    console.log(`Visit result:`, result);
  });

  res.json({
    success: true,
    message: "URL submitted successfully. Admin will visit it shortly.",
  });
});

app.listen(PORT, () => {
  console.log(`Admin bot server running on port ${PORT}`);
  console.log(`Blog URL: ${BLOG_URL}`);
});
