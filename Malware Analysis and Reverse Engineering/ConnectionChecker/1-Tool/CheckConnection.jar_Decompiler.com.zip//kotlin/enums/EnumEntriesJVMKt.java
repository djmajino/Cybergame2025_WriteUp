package kotlin.enums;

import kotlin.Metadata;
import kotlin.NotImplementedError;
import kotlin.PublishedApi;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0010\n\u0000\u001a\u001f\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u000e\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u0003H\u0081\b¨\u0006\u0004"},
   d2 = {"enumEntriesIntrinsic", "Lkotlin/enums/EnumEntries;", "T", "", "kotlin-stdlib"}
)
public final class EnumEntriesJVMKt {
   @SinceKotlin(
      version = "1.9"
   )
   @PublishedApi
   @InlineOnly
   private static final <T extends Enum<T>> EnumEntries<T> enumEntriesIntrinsic() {
      throw new NotImplementedError((String)null, 1, (DefaultConstructorMarker)null);
   }
}
