package kotlin;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/StandardKt__StandardKt", "kotlin/StandardKt__SynchronizedKt"}
)
public final class StandardKt extends StandardKt__SynchronizedKt {
   private StandardKt() {
   }
}
