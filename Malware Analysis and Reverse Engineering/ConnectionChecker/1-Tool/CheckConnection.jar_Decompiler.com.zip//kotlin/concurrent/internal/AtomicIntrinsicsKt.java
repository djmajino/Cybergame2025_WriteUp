package kotlin.concurrent.internal;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceArray;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.SinceKotlin;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00008\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u001c\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0001H\u0001\u001a\u001c\u0010\u0000\u001a\u00020\u0005*\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005H\u0001\u001a\u001c\u0010\u0000\u001a\u00020\u0007*\u00020\b2\u0006\u0010\u0003\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u0007H\u0001\u001a-\u0010\u0000\u001a\u0002H\t\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\n2\u0006\u0010\u0003\u001a\u0002H\t2\u0006\u0010\u0004\u001a\u0002H\tH\u0001¢\u0006\u0002\u0010\u000b\u001a$\u0010\u0000\u001a\u00020\u0001*\u00020\f2\u0006\u0010\r\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0001H\u0001\u001a$\u0010\u0000\u001a\u00020\u0005*\u00020\u000e2\u0006\u0010\r\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005H\u0001\u001a5\u0010\u0000\u001a\u0002H\t\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\u000f2\u0006\u0010\r\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u0002H\t2\u0006\u0010\u0004\u001a\u0002H\tH\u0001¢\u0006\u0002\u0010\u0010¨\u0006\u0011"},
   d2 = {"compareAndExchange", "", "Ljava/util/concurrent/atomic/AtomicInteger;", "expected", "newValue", "", "Ljava/util/concurrent/atomic/AtomicLong;", "", "Ljava/util/concurrent/atomic/AtomicBoolean;", "T", "Ljava/util/concurrent/atomic/AtomicReference;", "(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "Ljava/util/concurrent/atomic/AtomicIntegerArray;", "index", "Ljava/util/concurrent/atomic/AtomicLongArray;", "Ljava/util/concurrent/atomic/AtomicReferenceArray;", "(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "kotlin-stdlib"}
)
public final class AtomicIntrinsicsKt {
   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final int compareAndExchange(@NotNull AtomicInteger $this$compareAndExchange, int expected, int newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         int currentValue = $this$compareAndExchange.get();
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(expected, newValue));

      return expected;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final long compareAndExchange(@NotNull AtomicLong $this$compareAndExchange, long expected, long newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         long currentValue = $this$compareAndExchange.get();
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(expected, newValue));

      return expected;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final boolean compareAndExchange(@NotNull AtomicBoolean $this$compareAndExchange, boolean expected, boolean newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         boolean currentValue = $this$compareAndExchange.get();
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(expected, newValue));

      return expected;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final <T> T compareAndExchange(@NotNull AtomicReference<T> $this$compareAndExchange, T expected, T newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         Object currentValue = $this$compareAndExchange.get();
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(expected, newValue));

      return expected;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final int compareAndExchange(@NotNull AtomicIntegerArray $this$compareAndExchange, int index, int expected, int newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         int currentValue = $this$compareAndExchange.get(index);
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(index, expected, newValue));

      return expected;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final long compareAndExchange(@NotNull AtomicLongArray $this$compareAndExchange, int index, long expected, long newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         long currentValue = $this$compareAndExchange.get(index);
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(index, expected, newValue));

      return expected;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @PublishedApi
   public static final <T> T compareAndExchange(@NotNull AtomicReferenceArray<T> $this$compareAndExchange, int index, T expected, T newValue) {
      Intrinsics.checkNotNullParameter($this$compareAndExchange, "<this>");

      do {
         Object currentValue = $this$compareAndExchange.get(index);
         if (expected != currentValue) {
            return currentValue;
         }
      } while(!$this$compareAndExchange.compareAndSet(index, expected, newValue));

      return expected;
   }
}
