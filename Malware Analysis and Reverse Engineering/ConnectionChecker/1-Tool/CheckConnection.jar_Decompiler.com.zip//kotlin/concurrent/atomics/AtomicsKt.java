package kotlin.concurrent.atomics;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/concurrent/atomics/AtomicsKt__Atomics_commonKt", "kotlin/concurrent/atomics/AtomicsKt__Atomics_jvmKt"}
)
public final class AtomicsKt extends AtomicsKt__Atomics_jvmKt {
   private AtomicsKt() {
   }
}
