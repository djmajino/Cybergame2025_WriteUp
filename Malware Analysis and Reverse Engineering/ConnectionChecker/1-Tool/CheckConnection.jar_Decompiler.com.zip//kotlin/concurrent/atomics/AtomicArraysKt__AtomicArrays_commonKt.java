package kotlin.concurrent.atomics;

import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicReferenceArray;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000*\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a-\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0005H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0006\u001a\u0019\u0010\u0007\u001a\u00020\u0003*\u00020\u00012\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\t\u001a\u0019\u0010\n\u001a\u00020\u0003*\u00020\u00012\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\t\u001a\u0019\u0010\u000b\u001a\u00020\u0003*\u00020\u00012\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\t\u001a\u0019\u0010\f\u001a\u00020\u0003*\u00020\u00012\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\t\u001a-\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0002\u001a\u00020\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u000f0\u0005H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0010\u001a\u0019\u0010\u0007\u001a\u00020\u000f*\u00020\u000e2\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0011\u001a\u0019\u0010\n\u001a\u00020\u000f*\u00020\u000e2\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0011\u001a\u0019\u0010\u000b\u001a\u00020\u000f*\u00020\u000e2\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0011\u001a\u0019\u0010\f\u001a\u00020\u000f*\u00020\u000e2\u0006\u0010\b\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0011\u001a;\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\u00140\u0013\"\u0006\b\u0000\u0010\u0014\u0018\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u0002H\u00140\u0005H\u0087\bø\u0001\u0000¢\u0006\u0002\u0010\u0015\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u0016"},
   d2 = {"AtomicIntArray", "Lkotlin/concurrent/atomics/AtomicIntArray;", "size", "", "init", "Lkotlin/Function1;", "(ILkotlin/jvm/functions/Function1;)Ljava/util/concurrent/atomic/AtomicIntegerArray;", "fetchAndIncrementAt", "index", "(Ljava/util/concurrent/atomic/AtomicIntegerArray;I)I", "incrementAndFetchAt", "decrementAndFetchAt", "fetchAndDecrementAt", "AtomicLongArray", "Lkotlin/concurrent/atomics/AtomicLongArray;", "", "(ILkotlin/jvm/functions/Function1;)Ljava/util/concurrent/atomic/AtomicLongArray;", "(Ljava/util/concurrent/atomic/AtomicLongArray;I)J", "AtomicArray", "Lkotlin/concurrent/atomics/AtomicArray;", "T", "(ILkotlin/jvm/functions/Function1;)Ljava/util/concurrent/atomic/AtomicReferenceArray;", "kotlin-stdlib"},
   xs = "kotlin/concurrent/atomics/AtomicArraysKt"
)
class AtomicArraysKt__AtomicArrays_commonKt {
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final AtomicIntegerArray AtomicIntArray(int size, @NotNull Function1<? super Integer, Integer> init) {
      Intrinsics.checkNotNullParameter(init, "init");
      int $i$f$AtomicIntArray = false;
      int var3 = 0;

      int[] var4;
      for(var4 = new int[size]; var3 < size; ++var3) {
         var4[var3] = ((Number)init.invoke(var3)).intValue();
      }

      return new AtomicIntegerArray(var4);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final int fetchAndIncrementAt(@NotNull AtomicIntegerArray $this$fetchAndIncrementAt, int index) {
      Intrinsics.checkNotNullParameter($this$fetchAndIncrementAt, "<this>");
      return $this$fetchAndIncrementAt.getAndAdd(index, 1);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final int incrementAndFetchAt(@NotNull AtomicIntegerArray $this$incrementAndFetchAt, int index) {
      Intrinsics.checkNotNullParameter($this$incrementAndFetchAt, "<this>");
      return $this$incrementAndFetchAt.addAndGet(index, 1);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final int decrementAndFetchAt(@NotNull AtomicIntegerArray $this$decrementAndFetchAt, int index) {
      Intrinsics.checkNotNullParameter($this$decrementAndFetchAt, "<this>");
      return $this$decrementAndFetchAt.addAndGet(index, -1);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final int fetchAndDecrementAt(@NotNull AtomicIntegerArray $this$fetchAndDecrementAt, int index) {
      Intrinsics.checkNotNullParameter($this$fetchAndDecrementAt, "<this>");
      return $this$fetchAndDecrementAt.getAndAdd(index, -1);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final AtomicLongArray AtomicLongArray(int size, @NotNull Function1<? super Integer, Long> init) {
      Intrinsics.checkNotNullParameter(init, "init");
      int $i$f$AtomicLongArray = false;
      int var3 = 0;

      long[] var4;
      for(var4 = new long[size]; var3 < size; ++var3) {
         var4[var3] = ((Number)init.invoke(var3)).longValue();
      }

      return new AtomicLongArray(var4);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final long fetchAndIncrementAt(@NotNull AtomicLongArray $this$fetchAndIncrementAt, int index) {
      Intrinsics.checkNotNullParameter($this$fetchAndIncrementAt, "<this>");
      return $this$fetchAndIncrementAt.getAndAdd(index, 1L);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final long incrementAndFetchAt(@NotNull AtomicLongArray $this$incrementAndFetchAt, int index) {
      Intrinsics.checkNotNullParameter($this$incrementAndFetchAt, "<this>");
      return $this$incrementAndFetchAt.addAndGet(index, 1L);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final long decrementAndFetchAt(@NotNull AtomicLongArray $this$decrementAndFetchAt, int index) {
      Intrinsics.checkNotNullParameter($this$decrementAndFetchAt, "<this>");
      return $this$decrementAndFetchAt.addAndGet(index, -1L);
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final long fetchAndDecrementAt(@NotNull AtomicLongArray $this$fetchAndDecrementAt, int index) {
      Intrinsics.checkNotNullParameter($this$fetchAndDecrementAt, "<this>");
      return $this$fetchAndDecrementAt.getAndAdd(index, -1L);
   }

   // $FF: synthetic method
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   public static final <T> AtomicReferenceArray<T> AtomicArray(int size, Function1<? super Integer, ? extends T> init) {
      Intrinsics.checkNotNullParameter(init, "init");
      int $i$f$AtomicArray = false;
      int var3 = 0;
      Intrinsics.reifiedOperationMarker(0, "T");

      Object[] var4;
      for(var4 = new Object[size]; var3 < size; ++var3) {
         var4[var3] = init.invoke(var3);
      }

      return new AtomicReferenceArray(var4);
   }

   public AtomicArraysKt__AtomicArrays_commonKt() {
   }
}
