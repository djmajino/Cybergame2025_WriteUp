package kotlin.text;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/text/CharsKt__CharJVMKt", "kotlin/text/CharsKt__CharKt"}
)
public final class CharsKt extends CharsKt__CharKt {
   private CharsKt() {
   }
}
