package kotlin.text;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000V\n\u0000\n\u0002\u0010\u000e\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\b\n\u0002\u0010\n\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\f\n\u0002\b\u000e\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00052\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u000f\u0010\u0007\u001a\u00020\b*\u0004\u0018\u00010\u0001H\u0087\b\u001a\r\u0010\t\u001a\u00020\u0002*\u00020\u0001H\u0087\b\u001a\u0015\u0010\t\u001a\u00020\u0002*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\n\u001a\u00020\u0005*\u00020\u0001H\u0087\b\u001a\u0015\u0010\n\u001a\u00020\u0005*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\u000b\u001a\u00020\u0004*\u00020\u0001H\u0087\b\u001a\u0015\u0010\u000b\u001a\u00020\u0004*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\f\u001a\u00020\u0006*\u00020\u0001H\u0087\b\u001a\u0015\u0010\f\u001a\u00020\u0006*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\r\u001a\u00020\u000e*\u00020\u0001H\u0087\b\u001a\r\u0010\u000f\u001a\u00020\u0010*\u00020\u0001H\u0087\b\u001a\u0013\u0010\u0011\u001a\u0004\u0018\u00010\u000e*\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0012\u001a\u0013\u0010\u0013\u001a\u0004\u0018\u00010\u0010*\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0014\u001a\r\u0010\u0015\u001a\u00020\u0016*\u00020\u0001H\u0087\b\u001a\u0015\u0010\u0015\u001a\u00020\u0016*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u000e\u0010\u0017\u001a\u0004\u0018\u00010\u0016*\u00020\u0001H\u0007\u001a\u0016\u0010\u0017\u001a\u0004\u0018\u00010\u0016*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0007\u001a\r\u0010\u0018\u001a\u00020\u0019*\u00020\u0001H\u0087\b\u001a\u0015\u0010\u0018\u001a\u00020\u0019*\u00020\u00012\u0006\u0010\u001a\u001a\u00020\u001bH\u0087\b\u001a\u000e\u0010\u001c\u001a\u0004\u0018\u00010\u0019*\u00020\u0001H\u0007\u001a\u0016\u0010\u001c\u001a\u0004\u0018\u00010\u0019*\u00020\u00012\u0006\u0010\u001a\u001a\u00020\u001bH\u0007\u001a4\u0010\u001d\u001a\u0004\u0018\u0001H\u001e\"\u0004\b\u0000\u0010\u001e2\u0006\u0010\u001f\u001a\u00020\u00012\u0012\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u0002H\u001e0!H\u0082\b¢\u0006\u0004\b\"\u0010#\u001a\u0015\u0010$\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u0001H\u0002¢\u0006\u0002\b&\u001a \u0010'\u001a\u0004\u0018\u00010\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u0004H\u0083\b¢\u0006\u0002\b*\u001a\u0012\u0010+\u001a\u00020\b*\u00020,H\u0083\b¢\u0006\u0002\b-\u001a\u0012\u0010.\u001a\u00020\b*\u00020,H\u0083\b¢\u0006\u0002\b/\u001a\u0012\u00100\u001a\u00020\u0004*\u00020,H\u0083\b¢\u0006\u0002\b1\u001a6\u00102\u001a\u00020\u0004*\u00020\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u00020,\u0012\u0004\u0012\u00020\b0!H\u0083\b¢\u0006\u0002\b4\u001a6\u00105\u001a\u00020\u0004*\u00020\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u00020,\u0012\u0004\u0012\u00020\b0!H\u0083\b¢\u0006\u0002\b6\u001a>\u00107\u001a\u00020\u0004*\u00020\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0006\u00108\u001a\u00020\b2\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u00020,\u0012\u0004\u0012\u00020\b0!H\u0083\b¢\u0006\u0002\b9¨\u0006:"},
   d2 = {"toString", "", "", "radix", "", "", "", "toBoolean", "", "toByte", "toShort", "toInt", "toLong", "toFloat", "", "toDouble", "", "toFloatOrNull", "(Ljava/lang/String;)Ljava/lang/Float;", "toDoubleOrNull", "(Ljava/lang/String;)Ljava/lang/Double;", "toBigInteger", "Ljava/math/BigInteger;", "toBigIntegerOrNull", "toBigDecimal", "Ljava/math/BigDecimal;", "mathContext", "Ljava/math/MathContext;", "toBigDecimalOrNull", "screenFloatValue", "T", "str", "parse", "Lkotlin/Function1;", "screenFloatValue$StringsKt__StringNumberConversionsJVMKt", "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "isValidFloat", "s", "isValidFloat$StringsKt__StringNumberConversionsJVMKt", "guessNamedFloatConstant", "start", "endInclusive", "guessNamedFloatConstant$StringsKt__StringNumberConversionsJVMKt", "isAsciiDigit", "", "isAsciiDigit$StringsKt__StringNumberConversionsJVMKt", "isHexLetter", "isHexLetter$StringsKt__StringNumberConversionsJVMKt", "asciiLetterToLowerCaseCode", "asciiLetterToLowerCaseCode$StringsKt__StringNumberConversionsJVMKt", "advanceWhile", "predicate", "advanceWhile$StringsKt__StringNumberConversionsJVMKt", "backtrackWhile", "backtrackWhile$StringsKt__StringNumberConversionsJVMKt", "advanceAndValidateMantissa", "hexFormat", "advanceAndValidateMantissa$StringsKt__StringNumberConversionsJVMKt", "kotlin-stdlib"},
   xs = "kotlin/text/StringsKt"
)
@SourceDebugExtension({"SMAP\nStringNumberConversionsJVM.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StringNumberConversionsJVM.kt\nkotlin/text/StringsKt__StringNumberConversionsJVMKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,512:1\n267#1,7:513\n267#1,7:520\n267#1,7:527\n267#1,7:534\n1#2:541\n*S KotlinDebug\n*F\n+ 1 StringNumberConversionsJVM.kt\nkotlin/text/StringsKt__StringNumberConversionsJVMKt\n*L\n166#1:513,7\n173#1:520,7\n253#1:527,7\n264#1:534,7\n*E\n"})
class StringsKt__StringNumberConversionsJVMKt extends StringsKt__StringBuilderKt {
   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(byte $this$toString, int radix) {
      String var10000 = Integer.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(short $this$toString, int radix) {
      String var10000 = Integer.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(int $this$toString, int radix) {
      String var10000 = Integer.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(long $this$toString, int radix) {
      String var10000 = Long.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @InlineOnly
   private static final boolean toBoolean(String $this$toBoolean) {
      return Boolean.parseBoolean($this$toBoolean);
   }

   @InlineOnly
   private static final byte toByte(String $this$toByte) {
      Intrinsics.checkNotNullParameter($this$toByte, "<this>");
      return Byte.parseByte($this$toByte);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final byte toByte(String $this$toByte, int radix) {
      Intrinsics.checkNotNullParameter($this$toByte, "<this>");
      return Byte.parseByte($this$toByte, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final short toShort(String $this$toShort) {
      Intrinsics.checkNotNullParameter($this$toShort, "<this>");
      return Short.parseShort($this$toShort);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final short toShort(String $this$toShort, int radix) {
      Intrinsics.checkNotNullParameter($this$toShort, "<this>");
      return Short.parseShort($this$toShort, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final int toInt(String $this$toInt) {
      Intrinsics.checkNotNullParameter($this$toInt, "<this>");
      return Integer.parseInt($this$toInt);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final int toInt(String $this$toInt, int radix) {
      Intrinsics.checkNotNullParameter($this$toInt, "<this>");
      return Integer.parseInt($this$toInt, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final long toLong(String $this$toLong) {
      Intrinsics.checkNotNullParameter($this$toLong, "<this>");
      return Long.parseLong($this$toLong);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final long toLong(String $this$toLong, int radix) {
      Intrinsics.checkNotNullParameter($this$toLong, "<this>");
      return Long.parseLong($this$toLong, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final float toFloat(String $this$toFloat) {
      Intrinsics.checkNotNullParameter($this$toFloat, "<this>");
      return Float.parseFloat($this$toFloat);
   }

   @InlineOnly
   private static final double toDouble(String $this$toDouble) {
      Intrinsics.checkNotNullParameter($this$toDouble, "<this>");
      return Double.parseDouble($this$toDouble);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @Nullable
   public static final Float toFloatOrNull(@NotNull String $this$toFloatOrNull) {
      Intrinsics.checkNotNullParameter($this$toFloatOrNull, "<this>");
      boolean var1 = false;

      Float var2;
      try {
         Float var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt($this$toFloatOrNull)) {
            int var3 = false;
            var10000 = Float.parseFloat($this$toFloatOrNull);
         } else {
            var10000 = null;
         }

         var2 = var10000;
      } catch (NumberFormatException var4) {
         var2 = null;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @Nullable
   public static final Double toDoubleOrNull(@NotNull String $this$toDoubleOrNull) {
      Intrinsics.checkNotNullParameter($this$toDoubleOrNull, "<this>");
      boolean var1 = false;

      Double var2;
      try {
         Double var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt($this$toDoubleOrNull)) {
            int var3 = false;
            var10000 = Double.parseDouble($this$toDoubleOrNull);
         } else {
            var10000 = null;
         }

         var2 = var10000;
      } catch (NumberFormatException var4) {
         var2 = null;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigInteger toBigInteger(String $this$toBigInteger) {
      Intrinsics.checkNotNullParameter($this$toBigInteger, "<this>");
      return new BigInteger($this$toBigInteger);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigInteger toBigInteger(String $this$toBigInteger, int radix) {
      Intrinsics.checkNotNullParameter($this$toBigInteger, "<this>");
      return new BigInteger($this$toBigInteger, CharsKt.checkRadix(radix));
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigInteger toBigIntegerOrNull(@NotNull String $this$toBigIntegerOrNull) {
      Intrinsics.checkNotNullParameter($this$toBigIntegerOrNull, "<this>");
      return StringsKt.toBigIntegerOrNull($this$toBigIntegerOrNull, 10);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigInteger toBigIntegerOrNull(@NotNull String $this$toBigIntegerOrNull, int radix) {
      Intrinsics.checkNotNullParameter($this$toBigIntegerOrNull, "<this>");
      CharsKt.checkRadix(radix);
      int length = $this$toBigIntegerOrNull.length();
      switch(length) {
      case 0:
         return null;
      case 1:
         if (CharsKt.digitOf($this$toBigIntegerOrNull.charAt(0), radix) < 0) {
            return null;
         }
         break;
      default:
         int start = $this$toBigIntegerOrNull.charAt(0) == '-' ? 1 : 0;

         for(int index = start; index < length; ++index) {
            if (CharsKt.digitOf($this$toBigIntegerOrNull.charAt(index), radix) < 0) {
               return null;
            }
         }
      }

      return new BigInteger($this$toBigIntegerOrNull, CharsKt.checkRadix(radix));
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigDecimal toBigDecimal(String $this$toBigDecimal) {
      Intrinsics.checkNotNullParameter($this$toBigDecimal, "<this>");
      return new BigDecimal($this$toBigDecimal);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigDecimal toBigDecimal(String $this$toBigDecimal, MathContext mathContext) {
      Intrinsics.checkNotNullParameter($this$toBigDecimal, "<this>");
      Intrinsics.checkNotNullParameter(mathContext, "mathContext");
      return new BigDecimal($this$toBigDecimal, mathContext);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigDecimal toBigDecimalOrNull(@NotNull String $this$toBigDecimalOrNull) {
      Intrinsics.checkNotNullParameter($this$toBigDecimalOrNull, "<this>");
      boolean var1 = false;

      BigDecimal var2;
      try {
         BigDecimal var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt($this$toBigDecimalOrNull)) {
            int var3 = false;
            var10000 = new BigDecimal($this$toBigDecimalOrNull);
         } else {
            var10000 = null;
         }

         var2 = var10000;
      } catch (NumberFormatException var4) {
         var2 = null;
      }

      return var2;
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigDecimal toBigDecimalOrNull(@NotNull String $this$toBigDecimalOrNull, @NotNull MathContext mathContext) {
      Intrinsics.checkNotNullParameter($this$toBigDecimalOrNull, "<this>");
      Intrinsics.checkNotNullParameter(mathContext, "mathContext");
      boolean var2 = false;

      BigDecimal var5;
      try {
         BigDecimal var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt($this$toBigDecimalOrNull)) {
            int var4 = false;
            var10000 = new BigDecimal($this$toBigDecimalOrNull, mathContext);
         } else {
            var10000 = null;
         }

         var5 = var10000;
      } catch (NumberFormatException var6) {
         var5 = null;
      }

      return var5;
   }

   private static final <T> T screenFloatValue$StringsKt__StringNumberConversionsJVMKt(String str, Function1<? super String, ? extends T> parse) {
      boolean var2 = false;

      Object var3;
      try {
         var3 = isValidFloat$StringsKt__StringNumberConversionsJVMKt(str) ? parse.invoke(str) : null;
      } catch (NumberFormatException var5) {
         var3 = null;
      }

      return var3;
   }

   private static final boolean isValidFloat$StringsKt__StringNumberConversionsJVMKt(String s) {
      int start = 0;
      int endInclusive = s.length() - 1;
      String var3 = s;

      int l;
      char it;
      boolean var6;
      for(l = start; l <= endInclusive; ++l) {
         it = var3.charAt(l);
         var6 = false;
         if (it > ' ') {
            break;
         }
      }

      int start = l;
      if (l > endInclusive) {
         return false;
      } else {
         var3 = s;

         for(l = endInclusive; l > start; --l) {
            it = var3.charAt(l);
            var6 = false;
            if (it > ' ') {
               break;
            }
         }

         endInclusive = l;
         if (s.charAt(start) == '+' || s.charAt(start) == '-') {
            ++start;
         }

         if (start > l) {
            return false;
         } else {
            boolean isHex = false;
            int var7;
            String var8;
            int var9;
            char it;
            boolean var11;
            char it;
            boolean var13;
            int var10000;
            int var17;
            boolean var19;
            boolean var20;
            String var21;
            int var22;
            if (s.charAt(start) == '0') {
               ++start;
               if (start > l) {
                  return true;
               }

               if ((s.charAt(start) | 32) == 120) {
                  ++start;
                  var8 = s;

                  for(var9 = start; var9 <= endInclusive; ++var9) {
                     it = var8.charAt(var9);
                     var11 = false;
                     if ((it - 48 & '\uffff') >= 10 && ((it | 32) - 97 & '\uffff') >= 6) {
                        break;
                     }
                  }

                  var17 = var9;
                  var19 = start != var9;
                  if (var9 > endInclusive) {
                     var10000 = -1;
                  } else {
                     var20 = false;
                     if (s.charAt(var9) == '.') {
                        ++var17;
                        var7 = var17;
                        var21 = s;

                        for(var22 = var17; var22 <= endInclusive; ++var22) {
                           it = var21.charAt(var22);
                           var13 = false;
                           if ((it - 48 & '\uffff') >= 10 && ((it | 32) - 97 & '\uffff') >= 6) {
                              break;
                           }
                        }

                        var17 = var22;
                        var20 = var7 != var22;
                     }

                     var10000 = !var19 && !var20 ? -1 : var17;
                  }

                  start = var10000;
                  if (start == -1 || start > endInclusive) {
                     return false;
                  }

                  isHex = true;
               } else {
                  --start;
               }
            }

            if (!isHex) {
               var8 = s;

               for(var9 = start; var9 <= endInclusive; ++var9) {
                  it = var8.charAt(var9);
                  var11 = false;
                  if ((it - 48 & '\uffff') >= 10) {
                     break;
                  }
               }

               var17 = var9;
               var19 = start != var9;
               if (var9 > endInclusive) {
                  var10000 = var9;
               } else {
                  var20 = false;
                  if (s.charAt(var9) == '.') {
                     ++var17;
                     var7 = var17;
                     var21 = s;

                     for(var22 = var17; var22 <= endInclusive; ++var22) {
                        it = var21.charAt(var22);
                        var13 = false;
                        if ((it - 48 & '\uffff') >= 10) {
                           break;
                        }
                     }

                     var17 = var22;
                     var20 = var7 != var22;
                  }

                  if (!var19 && !var20) {
                     var21 = endInclusive == var17 + 3 - 1 ? "NaN" : (endInclusive == var17 + 8 - 1 ? "Infinity" : null);
                     var10000 = var21 == null ? -1 : (StringsKt.indexOf((CharSequence)s, var21, var17, false) == var17 ? endInclusive + 1 : -1);
                  } else {
                     var10000 = var17;
                  }
               }

               start = var10000;
               if (start == -1) {
                  return false;
               }

               if (start > endInclusive) {
                  return true;
               }
            }

            l = s.charAt(start++) | 32;
            if (l != (isHex ? 112 : 101)) {
               return !isHex && (l == 102 || l == 100) && start > endInclusive;
            } else if (start > endInclusive) {
               return false;
            } else {
               if (s.charAt(start) == '+' || s.charAt(start) == '-') {
                  ++start;
                  if (start > endInclusive) {
                     return false;
                  }
               }

               String var16 = s;

               for(var17 = start; var17 <= endInclusive; ++var17) {
                  char it = var16.charAt(var17);
                  var19 = false;
                  if ((it - 48 & '\uffff') >= 10) {
                     break;
                  }
               }

               if (var17 > endInclusive) {
                  return true;
               } else if (var17 != endInclusive) {
                  return false;
               } else {
                  l = s.charAt(var17) | 32;
                  return l == 102 || l == 100;
               }
            }
         }
      }
   }

   @InlineOnly
   private static final String guessNamedFloatConstant$StringsKt__StringNumberConversionsJVMKt(int start, int endInclusive) {
      return endInclusive == start + 3 - 1 ? "NaN" : (endInclusive == start + 8 - 1 ? "Infinity" : null);
   }

   @InlineOnly
   private static final boolean isAsciiDigit$StringsKt__StringNumberConversionsJVMKt(char $this$isAsciiDigit) {
      return ($this$isAsciiDigit - 48 & '\uffff') < 10;
   }

   @InlineOnly
   private static final boolean isHexLetter$StringsKt__StringNumberConversionsJVMKt(char $this$isHexLetter) {
      return (($this$isHexLetter | 32) - 97 & '\uffff') < 6;
   }

   @InlineOnly
   private static final int asciiLetterToLowerCaseCode$StringsKt__StringNumberConversionsJVMKt(char $this$asciiLetterToLowerCaseCode) {
      return $this$asciiLetterToLowerCaseCode | 32;
   }

   @InlineOnly
   private static final int advanceWhile$StringsKt__StringNumberConversionsJVMKt(String $this$advanceWhile, int start, int endInclusive, Function1<? super Character, Boolean> predicate) {
      int start;
      for(start = start; start <= endInclusive && (Boolean)predicate.invoke($this$advanceWhile.charAt(start)); ++start) {
      }

      return start;
   }

   @InlineOnly
   private static final int backtrackWhile$StringsKt__StringNumberConversionsJVMKt(String $this$backtrackWhile, int start, int endInclusive, Function1<? super Character, Boolean> predicate) {
      int endInclusive;
      for(endInclusive = endInclusive; endInclusive > start && (Boolean)predicate.invoke($this$backtrackWhile.charAt(endInclusive)); --endInclusive) {
      }

      return endInclusive;
   }

   @InlineOnly
   private static final int advanceAndValidateMantissa$StringsKt__StringNumberConversionsJVMKt(String $this$advanceAndValidateMantissa, int start, int endInclusive, boolean hexFormat, Function1<? super Character, Boolean> predicate) {
      String var7 = $this$advanceAndValidateMantissa;

      int var8;
      for(var8 = start; var8 <= endInclusive && (Boolean)predicate.invoke(var7.charAt(var8)); ++var8) {
      }

      int start = var8;
      boolean hasIntegerPart = start != var8;
      if (var8 > endInclusive) {
         return hexFormat ? -1 : var8;
      } else {
         boolean hasFractionalPart = false;
         String constant;
         if ($this$advanceAndValidateMantissa.charAt(var8) == '.') {
            ++start;
            int checkpoint = start;
            constant = $this$advanceAndValidateMantissa;

            int var10;
            for(var10 = start; var10 <= endInclusive && (Boolean)predicate.invoke(constant.charAt(var10)); ++var10) {
            }

            start = var10;
            hasFractionalPart = checkpoint != var10;
         }

         if (!hasIntegerPart && !hasFractionalPart) {
            if (hexFormat) {
               return -1;
            } else {
               constant = endInclusive == start + 3 - 1 ? "NaN" : (endInclusive == start + 8 - 1 ? "Infinity" : null);
               if (constant == null) {
                  return -1;
               } else {
                  return StringsKt.indexOf((CharSequence)$this$advanceAndValidateMantissa, constant, start, false) == start ? endInclusive + 1 : -1;
               }
            }
         } else {
            return start;
         }
      }
   }

   public StringsKt__StringNumberConversionsJVMKt() {
   }
}
