package kotlin.text;

import kotlin.Metadata;
import kotlin.SinceKotlin;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0005\"\u00020\u00062\u00020\u0006B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0007\"\u00020\b2\u00020\bB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\t¨\u0006\n"},
   d2 = {"Appendable", "Ljava/lang/Appendable;", "Lkotlin/SinceKotlin;", "version", "1.1", "StringBuilder", "Ljava/lang/StringBuilder;", "CharacterCodingException", "Ljava/nio/charset/CharacterCodingException;", "1.4", "kotlin-stdlib"}
)
public final class TypeAliasesKt {
   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void Appendable$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void StringBuilder$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.4"
   )
   public static void CharacterCodingException$annotations() {
   }
}
