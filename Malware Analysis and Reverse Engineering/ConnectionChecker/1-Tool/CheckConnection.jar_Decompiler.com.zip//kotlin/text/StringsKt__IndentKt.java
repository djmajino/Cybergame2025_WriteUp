package kotlin.text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.internal.IntrinsicConstEvaluation;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0005\u001a\u0016\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0001H\u0007\u001a\u001e\u0010\u0003\u001a\u00020\u0001*\u00020\u00012\b\b\u0002\u0010\u0004\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0001\u001a\f\u0010\u0005\u001a\u00020\u0001*\u00020\u0001H\u0007\u001a\u0014\u0010\u0006\u001a\u00020\u0001*\u00020\u00012\b\b\u0002\u0010\u0004\u001a\u00020\u0001\u001a\u0014\u0010\u0007\u001a\u00020\u0001*\u00020\u00012\b\b\u0002\u0010\b\u001a\u00020\u0001\u001a\u0011\u0010\t\u001a\u00020\n*\u00020\u0001H\u0002¢\u0006\u0002\b\u000b\u001a!\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00010\r2\u0006\u0010\b\u001a\u00020\u0001H\u0002¢\u0006\u0002\b\u000e\u001aJ\u0010\u000f\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00010\u00102\u0006\u0010\u0011\u001a\u00020\n2\u0012\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00010\r2\u0014\u0010\u0013\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u00010\rH\u0082\b¢\u0006\u0002\b\u0014¨\u0006\u0015"},
   d2 = {"trimMargin", "", "marginPrefix", "replaceIndentByMargin", "newIndent", "trimIndent", "replaceIndent", "prependIndent", "indent", "indentWidth", "", "indentWidth$StringsKt__IndentKt", "getIndentFunction", "Lkotlin/Function1;", "getIndentFunction$StringsKt__IndentKt", "reindent", "", "resultSizeEstimate", "indentAddFunction", "indentCutFunction", "reindent$StringsKt__IndentKt", "kotlin-stdlib"},
   xs = "kotlin/text/StringsKt"
)
@SourceDebugExtension({"SMAP\nIndent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Indent.kt\nkotlin/text/StringsKt__IndentKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,129:1\n119#1,2:131\n121#1,4:146\n126#1,2:159\n119#1,2:168\n121#1,4:183\n126#1,2:190\n1#2:130\n1#2:156\n1#2:187\n1#2:211\n1583#3,11:133\n1878#3,2:144\n1880#3:157\n1594#3:158\n774#3:161\n865#3,2:162\n1563#3:164\n1634#3,3:165\n1583#3,11:170\n1878#3,2:181\n1880#3:188\n1594#3:189\n1583#3,11:198\n1878#3,2:209\n1880#3:212\n1594#3:213\n158#4,6:150\n158#4,6:192\n*S KotlinDebug\n*F\n+ 1 Indent.kt\nkotlin/text/StringsKt__IndentKt\n*L\n42#1:131,2\n42#1:146,4\n42#1:159,2\n83#1:168,2\n83#1:183,4\n83#1:190,2\n42#1:156\n83#1:187\n120#1:211\n42#1:133,11\n42#1:144,2\n42#1:157\n42#1:158\n79#1:161\n79#1:162,2\n80#1:164\n80#1:165,3\n83#1:170,11\n83#1:181,2\n83#1:188\n83#1:189\n120#1:198,11\n120#1:209,2\n120#1:212\n120#1:213\n43#1:150,6\n107#1:192,6\n*E\n"})
class StringsKt__IndentKt extends StringsKt__AppendableKt {
   @IntrinsicConstEvaluation
   @NotNull
   public static final String trimMargin(@NotNull String $this$trimMargin, @NotNull String marginPrefix) {
      Intrinsics.checkNotNullParameter($this$trimMargin, "<this>");
      Intrinsics.checkNotNullParameter(marginPrefix, "marginPrefix");
      return StringsKt.replaceIndentByMargin($this$trimMargin, "", marginPrefix);
   }

   // $FF: synthetic method
   public static String trimMargin$default(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "|";
      }

      return StringsKt.trimMargin(var0, var1);
   }

   @NotNull
   public static final String replaceIndentByMargin(@NotNull String $this$replaceIndentByMargin, @NotNull String newIndent, @NotNull String marginPrefix) {
      Intrinsics.checkNotNullParameter($this$replaceIndentByMargin, "<this>");
      Intrinsics.checkNotNullParameter(newIndent, "newIndent");
      Intrinsics.checkNotNullParameter(marginPrefix, "marginPrefix");
      if (StringsKt.isBlank((CharSequence)marginPrefix)) {
         int var4 = false;
         String var37 = "marginPrefix must be non-blank string.";
         throw new IllegalArgumentException(var37.toString());
      } else {
         List lines = StringsKt.lines((CharSequence)$this$replaceIndentByMargin);
         int resultSizeEstimate$iv = $this$replaceIndentByMargin.length() + newIndent.length() * lines.size();
         Function1 indentAddFunction$iv = getIndentFunction$StringsKt__IndentKt(newIndent);
         int $i$f$reindent = false;
         int lastIndex$iv = CollectionsKt.getLastIndex(lines);
         Iterable $this$mapIndexedNotNull$iv$iv = (Iterable)lines;
         int $i$f$mapIndexedNotNull = false;
         Collection destination$iv$iv$iv = (Collection)(new ArrayList());
         int $i$f$mapIndexedNotNullTo = false;
         int $i$f$forEachIndexed = false;
         int index$iv$iv$iv$iv = 0;
         Iterator var17 = $this$mapIndexedNotNull$iv$iv.iterator();

         while(var17.hasNext()) {
            Object item$iv$iv$iv$iv = var17.next();
            int var19 = index$iv$iv$iv$iv++;
            if (var19 < 0) {
               CollectionsKt.throwIndexOverflow();
            }

            int var22 = false;
            String value$iv = (String)item$iv$iv$iv$iv;
            int var25 = false;
            String var38;
            if ((var19 == 0 || var19 == lastIndex$iv) && StringsKt.isBlank((CharSequence)value$iv)) {
               var38 = null;
            } else {
               label86: {
                  int var27 = false;
                  CharSequence $this$indexOfFirst$iv = (CharSequence)value$iv;
                  int $i$f$indexOfFirst = false;
                  int index$iv = 0;
                  int var31 = $this$indexOfFirst$iv.length();

                  int var10000;
                  while(true) {
                     if (index$iv >= var31) {
                        var10000 = -1;
                        break;
                     }

                     char it = $this$indexOfFirst$iv.charAt(index$iv);
                     int var33 = false;
                     if (!CharsKt.isWhitespace(it)) {
                        var10000 = index$iv;
                        break;
                     }

                     ++index$iv;
                  }

                  int firstNonWhitespaceIndex = var10000;
                  if (firstNonWhitespaceIndex == -1) {
                     var38 = null;
                  } else if (StringsKt.startsWith$default(value$iv, marginPrefix, firstNonWhitespaceIndex, false, 4, (Object)null)) {
                     int var39 = firstNonWhitespaceIndex + marginPrefix.length();
                     Intrinsics.checkNotNull(value$iv, "null cannot be cast to non-null type java.lang.String");
                     var38 = value$iv.substring(var39);
                     Intrinsics.checkNotNullExpressionValue(var38, "substring(...)");
                  } else {
                     var38 = null;
                  }

                  if (var38 != null) {
                     var38 = (String)indentAddFunction$iv.invoke(var38);
                     if (var38 != null) {
                        break label86;
                     }
                  }

                  var38 = value$iv;
               }
            }

            if (var38 != null) {
               Object it$iv$iv$iv = var38;
               int var36 = false;
               destination$iv$iv$iv.add(it$iv$iv$iv);
            }
         }

         return ((StringBuilder)CollectionsKt.joinTo$default((Iterable)((List)destination$iv$iv$iv), (Appendable)(new StringBuilder(resultSizeEstimate$iv)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 124, (Object)null)).toString();
      }
   }

   // $FF: synthetic method
   public static String replaceIndentByMargin$default(String var0, String var1, String var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = "";
      }

      if ((var3 & 2) != 0) {
         var2 = "|";
      }

      return StringsKt.replaceIndentByMargin(var0, var1, var2);
   }

   @IntrinsicConstEvaluation
   @NotNull
   public static final String trimIndent(@NotNull String $this$trimIndent) {
      Intrinsics.checkNotNullParameter($this$trimIndent, "<this>");
      return StringsKt.replaceIndent($this$trimIndent, "");
   }

   @NotNull
   public static final String replaceIndent(@NotNull String $this$replaceIndent, @NotNull String newIndent) {
      Intrinsics.checkNotNullParameter($this$replaceIndent, "<this>");
      Intrinsics.checkNotNullParameter(newIndent, "newIndent");
      List lines = StringsKt.lines((CharSequence)$this$replaceIndent);
      Iterable $this$map$iv = (Iterable)lines;
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$mapTo = false;
      Iterator var10 = $this$map$iv.iterator();

      Object item$iv$iv;
      String p0;
      boolean $i$f$mapIndexedNotNullTo;
      while(var10.hasNext()) {
         item$iv$iv = var10.next();
         p0 = (String)item$iv$iv;
         $i$f$mapIndexedNotNullTo = false;
         if (!StringsKt.isBlank((CharSequence)p0)) {
            destination$iv$iv.add(item$iv$iv);
         }
      }

      $this$map$iv = (Iterable)((List)destination$iv$iv);
      $i$f$map = false;
      destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      $i$f$mapTo = false;
      var10 = $this$map$iv.iterator();

      while(var10.hasNext()) {
         item$iv$iv = var10.next();
         p0 = (String)item$iv$iv;
         $i$f$mapIndexedNotNullTo = false;
         destination$iv$iv.add(indentWidth$StringsKt__IndentKt(p0));
      }

      Integer var10000 = (Integer)CollectionsKt.minOrNull((Iterable)((List)destination$iv$iv));
      int minCommonIndent = var10000 != null ? var10000 : 0;
      int resultSizeEstimate$iv = $this$replaceIndent.length() + newIndent.length() * lines.size();
      Function1 indentAddFunction$iv = getIndentFunction$StringsKt__IndentKt(newIndent);
      int $i$f$reindent = false;
      int lastIndex$iv = CollectionsKt.getLastIndex(lines);
      Iterable $this$mapIndexedNotNull$iv$iv = (Iterable)lines;
      int $i$f$mapIndexedNotNull = false;
      Collection destination$iv$iv$iv = (Collection)(new ArrayList());
      $i$f$mapIndexedNotNullTo = false;
      int $i$f$forEachIndexed = false;
      int index$iv$iv$iv$iv = 0;
      Iterator var17 = $this$mapIndexedNotNull$iv$iv.iterator();

      while(var17.hasNext()) {
         Object item$iv$iv$iv$iv = var17.next();
         int var19 = index$iv$iv$iv$iv++;
         if (var19 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         int var22 = false;
         String value$iv = (String)item$iv$iv$iv$iv;
         int var25 = false;
         String var38;
         if ((var19 == 0 || var19 == lastIndex$iv) && StringsKt.isBlank((CharSequence)value$iv)) {
            var38 = null;
         } else {
            label78: {
               int var27 = false;
               var38 = StringsKt.drop(value$iv, minCommonIndent);
               if (var38 != null) {
                  var38 = (String)indentAddFunction$iv.invoke(var38);
                  if (var38 != null) {
                     break label78;
                  }
               }

               var38 = value$iv;
            }
         }

         if (var38 != null) {
            Object it$iv$iv$iv = var38;
            int var29 = false;
            destination$iv$iv$iv.add(it$iv$iv$iv);
         }
      }

      return ((StringBuilder)CollectionsKt.joinTo$default((Iterable)((List)destination$iv$iv$iv), (Appendable)(new StringBuilder(resultSizeEstimate$iv)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 124, (Object)null)).toString();
   }

   // $FF: synthetic method
   public static String replaceIndent$default(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "";
      }

      return StringsKt.replaceIndent(var0, var1);
   }

   @NotNull
   public static final String prependIndent(@NotNull String $this$prependIndent, @NotNull String indent) {
      Intrinsics.checkNotNullParameter($this$prependIndent, "<this>");
      Intrinsics.checkNotNullParameter(indent, "indent");
      return SequencesKt.joinToString$default(SequencesKt.map(StringsKt.lineSequence((CharSequence)$this$prependIndent), StringsKt__IndentKt::prependIndent$lambda$5$StringsKt__IndentKt), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null);
   }

   // $FF: synthetic method
   public static String prependIndent$default(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "    ";
      }

      return StringsKt.prependIndent(var0, var1);
   }

   private static final int indentWidth$StringsKt__IndentKt(String $this$indentWidth) {
      CharSequence $this$indexOfFirst$iv = (CharSequence)$this$indentWidth;
      int $i$f$indexOfFirst = false;
      int index$iv = 0;
      int var4 = $this$indexOfFirst$iv.length();

      int var10000;
      while(true) {
         if (index$iv >= var4) {
            var10000 = -1;
            break;
         }

         char it = $this$indexOfFirst$iv.charAt(index$iv);
         int var6 = false;
         if (!CharsKt.isWhitespace(it)) {
            var10000 = index$iv;
            break;
         }

         ++index$iv;
      }

      int it = var10000;
      int var8 = false;
      return it == -1 ? $this$indentWidth.length() : it;
   }

   private static final Function1<String, String> getIndentFunction$StringsKt__IndentKt(String indent) {
      return ((CharSequence)indent).length() == 0 ? StringsKt__IndentKt::getIndentFunction$lambda$8$StringsKt__IndentKt : StringsKt__IndentKt::getIndentFunction$lambda$9$StringsKt__IndentKt;
   }

   private static final String reindent$StringsKt__IndentKt(List<String> $this$reindent, int resultSizeEstimate, Function1<? super String, String> indentAddFunction, Function1<? super String, String> indentCutFunction) {
      int $i$f$reindent = false;
      int lastIndex = CollectionsKt.getLastIndex($this$reindent);
      Iterable $this$mapIndexedNotNull$iv = (Iterable)$this$reindent;
      int $i$f$mapIndexedNotNull = false;
      Collection destination$iv$iv = (Collection)(new ArrayList());
      int $i$f$mapIndexedNotNullTo = false;
      int $i$f$forEachIndexed = false;
      int index$iv$iv$iv = 0;
      Iterator var14 = $this$mapIndexedNotNull$iv.iterator();

      while(var14.hasNext()) {
         Object item$iv$iv$iv = var14.next();
         int var16 = index$iv$iv$iv++;
         if (var16 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         int var19 = false;
         String value = (String)item$iv$iv$iv;
         int var22 = false;
         String var25;
         if ((var16 == 0 || var16 == lastIndex) && StringsKt.isBlank((CharSequence)value)) {
            var25 = null;
         } else {
            label42: {
               var25 = (String)indentCutFunction.invoke(value);
               if (var25 != null) {
                  var25 = (String)indentAddFunction.invoke(var25);
                  if (var25 != null) {
                     break label42;
                  }
               }

               var25 = value;
            }
         }

         if (var25 != null) {
            Object it$iv$iv = var25;
            int var24 = false;
            destination$iv$iv.add(it$iv$iv);
         }
      }

      return ((StringBuilder)CollectionsKt.joinTo$default((Iterable)((List)destination$iv$iv), (Appendable)(new StringBuilder(resultSizeEstimate)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 124, (Object)null)).toString();
   }

   private static final String prependIndent$lambda$5$StringsKt__IndentKt(String $indent, String it) {
      Intrinsics.checkNotNullParameter(it, "it");
      return StringsKt.isBlank((CharSequence)it) ? (it.length() < $indent.length() ? $indent : it) : $indent + it;
   }

   private static final String getIndentFunction$lambda$8$StringsKt__IndentKt(String line) {
      Intrinsics.checkNotNullParameter(line, "line");
      return line;
   }

   private static final String getIndentFunction$lambda$9$StringsKt__IndentKt(String $indent, String line) {
      Intrinsics.checkNotNullParameter(line, "line");
      return $indent + line;
   }

   public StringsKt__IndentKt() {
   }
}
