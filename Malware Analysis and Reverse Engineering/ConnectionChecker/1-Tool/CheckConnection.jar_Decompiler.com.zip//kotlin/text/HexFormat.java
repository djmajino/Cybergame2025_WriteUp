package kotlin.text;

import kotlin.ExperimentalStdlibApi;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.SinceKotlin;
import kotlin.Unit;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u0005\b\u0007\u0018\u0000 \u00152\u00020\u0001:\u0004\u0012\u0013\u0014\u0015B!\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\b\u0010\u0010\u001a\u00020\u0011H\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0016"},
   d2 = {"Lkotlin/text/HexFormat;", "", "upperCase", "", "bytes", "Lkotlin/text/HexFormat$BytesHexFormat;", "number", "Lkotlin/text/HexFormat$NumberHexFormat;", "<init>", "(ZLkotlin/text/HexFormat$BytesHexFormat;Lkotlin/text/HexFormat$NumberHexFormat;)V", "getUpperCase", "()Z", "getBytes", "()Lkotlin/text/HexFormat$BytesHexFormat;", "getNumber", "()Lkotlin/text/HexFormat$NumberHexFormat;", "toString", "", "BytesHexFormat", "NumberHexFormat", "Builder", "Companion", "kotlin-stdlib"}
)
@ExperimentalStdlibApi
@SinceKotlin(
   version = "1.9"
)
public final class HexFormat {
   @NotNull
   public static final HexFormat.Companion Companion = new HexFormat.Companion((DefaultConstructorMarker)null);
   private final boolean upperCase;
   @NotNull
   private final HexFormat.BytesHexFormat bytes;
   @NotNull
   private final HexFormat.NumberHexFormat number;
   @NotNull
   private static final HexFormat Default;
   @NotNull
   private static final HexFormat UpperCase;

   public HexFormat(boolean upperCase, @NotNull HexFormat.BytesHexFormat bytes, @NotNull HexFormat.NumberHexFormat number) {
      Intrinsics.checkNotNullParameter(bytes, "bytes");
      Intrinsics.checkNotNullParameter(number, "number");
      super();
      this.upperCase = upperCase;
      this.bytes = bytes;
      this.number = number;
   }

   public final boolean getUpperCase() {
      return this.upperCase;
   }

   @NotNull
   public final HexFormat.BytesHexFormat getBytes() {
      return this.bytes;
   }

   @NotNull
   public final HexFormat.NumberHexFormat getNumber() {
      return this.number;
   }

   @NotNull
   public String toString() {
      StringBuilder var1 = new StringBuilder();
      int var3 = false;
      var1.append("HexFormat(").append('\n');
      StringBuilder var4 = var1.append("    upperCase = ").append(this.upperCase);
      var4.append(",").append('\n');
      var1.append("    bytes = BytesHexFormat(").append('\n');
      this.bytes.appendOptionsTo$kotlin_stdlib(var1, "        ").append('\n');
      var1.append("    ),").append('\n');
      var1.append("    number = NumberHexFormat(").append('\n');
      this.number.appendOptionsTo$kotlin_stdlib(var1, "        ").append('\n');
      var1.append("    )").append('\n');
      var1.append(")");
      return var1.toString();
   }

   static {
      Default = new HexFormat(false, HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib(), HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib());
      UpperCase = new HexFormat(true, HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib(), HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib());
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\t\b\u0001¢\u0006\u0004\b\u0002\u0010\u0003J%\u0010\n\u001a\u00020\u00142\u0017\u0010\u0015\u001a\u0013\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00140\u0016¢\u0006\u0002\b\u0017H\u0087\bø\u0001\u0000J%\u0010\u000f\u001a\u00020\u00142\u0017\u0010\u0015\u001a\u0013\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00140\u0016¢\u0006\u0002\b\u0017H\u0087\bø\u0001\u0000J\b\u0010\u0018\u001a\u00020\u0019H\u0001R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u0011\u0010\n\u001a\u00020\u000b8F¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u000f\u001a\u00020\u00108F¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u001a"},
      d2 = {"Lkotlin/text/HexFormat$Builder;", "", "<init>", "()V", "upperCase", "", "getUpperCase", "()Z", "setUpperCase", "(Z)V", "bytes", "Lkotlin/text/HexFormat$BytesHexFormat$Builder;", "getBytes", "()Lkotlin/text/HexFormat$BytesHexFormat$Builder;", "_bytes", "number", "Lkotlin/text/HexFormat$NumberHexFormat$Builder;", "getNumber", "()Lkotlin/text/HexFormat$NumberHexFormat$Builder;", "_number", "", "builderAction", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "build", "Lkotlin/text/HexFormat;", "kotlin-stdlib"}
   )
   public static final class Builder {
      private boolean upperCase;
      @Nullable
      private HexFormat.BytesHexFormat.Builder _bytes;
      @Nullable
      private HexFormat.NumberHexFormat.Builder _number;

      @PublishedApi
      public Builder() {
         this.upperCase = HexFormat.Companion.getDefault().getUpperCase();
      }

      public final boolean getUpperCase() {
         return this.upperCase;
      }

      public final void setUpperCase(boolean var1) {
         this.upperCase = var1;
      }

      @NotNull
      public final HexFormat.BytesHexFormat.Builder getBytes() {
         if (this._bytes == null) {
            this._bytes = new HexFormat.BytesHexFormat.Builder();
         }

         HexFormat.BytesHexFormat.Builder var10000 = this._bytes;
         Intrinsics.checkNotNull(var10000);
         return var10000;
      }

      @NotNull
      public final HexFormat.NumberHexFormat.Builder getNumber() {
         if (this._number == null) {
            this._number = new HexFormat.NumberHexFormat.Builder();
         }

         HexFormat.NumberHexFormat.Builder var10000 = this._number;
         Intrinsics.checkNotNull(var10000);
         return var10000;
      }

      @InlineOnly
      private final void bytes(Function1<? super HexFormat.BytesHexFormat.Builder, Unit> builderAction) {
         Intrinsics.checkNotNullParameter(builderAction, "builderAction");
         builderAction.invoke(this.getBytes());
      }

      @InlineOnly
      private final void number(Function1<? super HexFormat.NumberHexFormat.Builder, Unit> builderAction) {
         Intrinsics.checkNotNullParameter(builderAction, "builderAction");
         builderAction.invoke(this.getNumber());
      }

      @PublishedApi
      @NotNull
      public final HexFormat build() {
         HexFormat var10000;
         HexFormat.BytesHexFormat var1;
         boolean var10002;
         label19: {
            var10000 = new HexFormat;
            var10002 = this.upperCase;
            HexFormat.BytesHexFormat.Builder var10003 = this._bytes;
            if (var10003 != null) {
               var1 = var10003.build$kotlin_stdlib();
               if (var1 != null) {
                  break label19;
               }
            }

            var1 = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib();
         }

         HexFormat.NumberHexFormat var2;
         label14: {
            HexFormat.NumberHexFormat.Builder var10004 = this._number;
            if (var10004 != null) {
               var2 = var10004.build$kotlin_stdlib();
               if (var2 != null) {
                  break label14;
               }
            }

            var2 = HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib();
         }

         var10000.<init>(var10002, var1, var2);
         return var10000;
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 %2\u00020\u0001:\u0002$%B9\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\u0006¢\u0006\u0004\b\n\u0010\u000bJ\b\u0010\u001c\u001a\u00020\u0006H\u0016J'\u0010\u001d\u001a\u00060\u001ej\u0002`\u001f2\n\u0010 \u001a\u00060\u001ej\u0002`\u001f2\u0006\u0010!\u001a\u00020\u0006H\u0000¢\u0006\u0004\b\"\u0010#R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0010R\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0014\u0010\u0014\u001a\u00020\u0015X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\u00020\u0015X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0017R\u0014\u0010\u001a\u001a\u00020\u0015X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0017¨\u0006&"},
      d2 = {"Lkotlin/text/HexFormat$BytesHexFormat;", "", "bytesPerLine", "", "bytesPerGroup", "groupSeparator", "", "byteSeparator", "bytePrefix", "byteSuffix", "<init>", "(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getBytesPerLine", "()I", "getBytesPerGroup", "getGroupSeparator", "()Ljava/lang/String;", "getByteSeparator", "getBytePrefix", "getByteSuffix", "noLineAndGroupSeparator", "", "getNoLineAndGroupSeparator$kotlin_stdlib", "()Z", "shortByteSeparatorNoPrefixAndSuffix", "getShortByteSeparatorNoPrefixAndSuffix$kotlin_stdlib", "ignoreCase", "getIgnoreCase$kotlin_stdlib", "toString", "appendOptionsTo", "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "sb", "indent", "appendOptionsTo$kotlin_stdlib", "(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;", "Builder", "Companion", "kotlin-stdlib"}
   )
   public static final class BytesHexFormat {
      @NotNull
      public static final HexFormat.BytesHexFormat.Companion Companion = new HexFormat.BytesHexFormat.Companion((DefaultConstructorMarker)null);
      private final int bytesPerLine;
      private final int bytesPerGroup;
      @NotNull
      private final String groupSeparator;
      @NotNull
      private final String byteSeparator;
      @NotNull
      private final String bytePrefix;
      @NotNull
      private final String byteSuffix;
      private final boolean noLineAndGroupSeparator;
      private final boolean shortByteSeparatorNoPrefixAndSuffix;
      private final boolean ignoreCase;
      @NotNull
      private static final HexFormat.BytesHexFormat Default = new HexFormat.BytesHexFormat(Integer.MAX_VALUE, Integer.MAX_VALUE, "  ", "", "", "");

      public BytesHexFormat(int bytesPerLine, int bytesPerGroup, @NotNull String groupSeparator, @NotNull String byteSeparator, @NotNull String bytePrefix, @NotNull String byteSuffix) {
         Intrinsics.checkNotNullParameter(groupSeparator, "groupSeparator");
         Intrinsics.checkNotNullParameter(byteSeparator, "byteSeparator");
         Intrinsics.checkNotNullParameter(bytePrefix, "bytePrefix");
         Intrinsics.checkNotNullParameter(byteSuffix, "byteSuffix");
         super();
         this.bytesPerLine = bytesPerLine;
         this.bytesPerGroup = bytesPerGroup;
         this.groupSeparator = groupSeparator;
         this.byteSeparator = byteSeparator;
         this.bytePrefix = bytePrefix;
         this.byteSuffix = byteSuffix;
         this.noLineAndGroupSeparator = this.bytesPerLine == Integer.MAX_VALUE && this.bytesPerGroup == Integer.MAX_VALUE;
         this.shortByteSeparatorNoPrefixAndSuffix = ((CharSequence)this.bytePrefix).length() == 0 && ((CharSequence)this.byteSuffix).length() == 0 && this.byteSeparator.length() <= 1;
         this.ignoreCase = HexFormatKt.access$isCaseSensitive(this.groupSeparator) || HexFormatKt.access$isCaseSensitive(this.byteSeparator) || HexFormatKt.access$isCaseSensitive(this.bytePrefix) || HexFormatKt.access$isCaseSensitive(this.byteSuffix);
      }

      public final int getBytesPerLine() {
         return this.bytesPerLine;
      }

      public final int getBytesPerGroup() {
         return this.bytesPerGroup;
      }

      @NotNull
      public final String getGroupSeparator() {
         return this.groupSeparator;
      }

      @NotNull
      public final String getByteSeparator() {
         return this.byteSeparator;
      }

      @NotNull
      public final String getBytePrefix() {
         return this.bytePrefix;
      }

      @NotNull
      public final String getByteSuffix() {
         return this.byteSuffix;
      }

      public final boolean getNoLineAndGroupSeparator$kotlin_stdlib() {
         return this.noLineAndGroupSeparator;
      }

      public final boolean getShortByteSeparatorNoPrefixAndSuffix$kotlin_stdlib() {
         return this.shortByteSeparatorNoPrefixAndSuffix;
      }

      public final boolean getIgnoreCase$kotlin_stdlib() {
         return this.ignoreCase;
      }

      @NotNull
      public String toString() {
         StringBuilder var1 = new StringBuilder();
         int var3 = false;
         var1.append("BytesHexFormat(").append('\n');
         this.appendOptionsTo$kotlin_stdlib(var1, "    ").append('\n');
         var1.append(")");
         return var1.toString();
      }

      @NotNull
      public final StringBuilder appendOptionsTo$kotlin_stdlib(@NotNull StringBuilder sb, @NotNull String indent) {
         Intrinsics.checkNotNullParameter(sb, "sb");
         Intrinsics.checkNotNullParameter(indent, "indent");
         StringBuilder var3 = sb.append(indent).append("bytesPerLine = ").append(this.bytesPerLine);
         var3.append(",").append('\n');
         var3 = sb.append(indent).append("bytesPerGroup = ").append(this.bytesPerGroup);
         var3.append(",").append('\n');
         var3 = sb.append(indent).append("groupSeparator = \"").append(this.groupSeparator);
         var3.append("\",").append('\n');
         var3 = sb.append(indent).append("byteSeparator = \"").append(this.byteSeparator);
         var3.append("\",").append('\n');
         var3 = sb.append(indent).append("bytePrefix = \"").append(this.bytePrefix);
         var3.append("\",").append('\n');
         sb.append(indent).append("byteSuffix = \"").append(this.byteSuffix).append("\"");
         return sb;
      }

      @Metadata(
         mv = {2, 1, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\t\b\u0000¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u001d\u001a\u00020\u001eH\u0000¢\u0006\u0002\b\u001fR$\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR$\u0010\u000b\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\b\"\u0004\b\r\u0010\nR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R$\u0010\u0014\u001a\u00020\u000f2\u0006\u0010\u0004\u001a\u00020\u000f@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0011\"\u0004\b\u0016\u0010\u0013R$\u0010\u0017\u001a\u00020\u000f2\u0006\u0010\u0004\u001a\u00020\u000f@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0011\"\u0004\b\u0019\u0010\u0013R$\u0010\u001a\u001a\u00020\u000f2\u0006\u0010\u0004\u001a\u00020\u000f@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u0011\"\u0004\b\u001c\u0010\u0013¨\u0006 "},
         d2 = {"Lkotlin/text/HexFormat$BytesHexFormat$Builder;", "", "<init>", "()V", "value", "", "bytesPerLine", "getBytesPerLine", "()I", "setBytesPerLine", "(I)V", "bytesPerGroup", "getBytesPerGroup", "setBytesPerGroup", "groupSeparator", "", "getGroupSeparator", "()Ljava/lang/String;", "setGroupSeparator", "(Ljava/lang/String;)V", "byteSeparator", "getByteSeparator", "setByteSeparator", "bytePrefix", "getBytePrefix", "setBytePrefix", "byteSuffix", "getByteSuffix", "setByteSuffix", "build", "Lkotlin/text/HexFormat$BytesHexFormat;", "build$kotlin_stdlib", "kotlin-stdlib"}
      )
      public static final class Builder {
         private int bytesPerLine;
         private int bytesPerGroup;
         @NotNull
         private String groupSeparator;
         @NotNull
         private String byteSeparator;
         @NotNull
         private String bytePrefix;
         @NotNull
         private String byteSuffix;

         public Builder() {
            this.bytesPerLine = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib().getBytesPerLine();
            this.bytesPerGroup = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib().getBytesPerGroup();
            this.groupSeparator = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib().getGroupSeparator();
            this.byteSeparator = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib().getByteSeparator();
            this.bytePrefix = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib().getBytePrefix();
            this.byteSuffix = HexFormat.BytesHexFormat.Companion.getDefault$kotlin_stdlib().getByteSuffix();
         }

         public final int getBytesPerLine() {
            return this.bytesPerLine;
         }

         public final void setBytesPerLine(int value) {
            if (value <= 0) {
               throw new IllegalArgumentException("Non-positive values are prohibited for bytesPerLine, but was " + value);
            } else {
               this.bytesPerLine = value;
            }
         }

         public final int getBytesPerGroup() {
            return this.bytesPerGroup;
         }

         public final void setBytesPerGroup(int value) {
            if (value <= 0) {
               throw new IllegalArgumentException("Non-positive values are prohibited for bytesPerGroup, but was " + value);
            } else {
               this.bytesPerGroup = value;
            }
         }

         @NotNull
         public final String getGroupSeparator() {
            return this.groupSeparator;
         }

         public final void setGroupSeparator(@NotNull String var1) {
            Intrinsics.checkNotNullParameter(var1, "<set-?>");
            this.groupSeparator = var1;
         }

         @NotNull
         public final String getByteSeparator() {
            return this.byteSeparator;
         }

         public final void setByteSeparator(@NotNull String value) {
            Intrinsics.checkNotNullParameter(value, "value");
            if (!StringsKt.contains$default((CharSequence)value, '\n', false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)value, '\r', false, 2, (Object)null)) {
               this.byteSeparator = value;
            } else {
               throw new IllegalArgumentException("LF and CR characters are prohibited in byteSeparator, but was " + value);
            }
         }

         @NotNull
         public final String getBytePrefix() {
            return this.bytePrefix;
         }

         public final void setBytePrefix(@NotNull String value) {
            Intrinsics.checkNotNullParameter(value, "value");
            if (!StringsKt.contains$default((CharSequence)value, '\n', false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)value, '\r', false, 2, (Object)null)) {
               this.bytePrefix = value;
            } else {
               throw new IllegalArgumentException("LF and CR characters are prohibited in bytePrefix, but was " + value);
            }
         }

         @NotNull
         public final String getByteSuffix() {
            return this.byteSuffix;
         }

         public final void setByteSuffix(@NotNull String value) {
            Intrinsics.checkNotNullParameter(value, "value");
            if (!StringsKt.contains$default((CharSequence)value, '\n', false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)value, '\r', false, 2, (Object)null)) {
               this.byteSuffix = value;
            } else {
               throw new IllegalArgumentException("LF and CR characters are prohibited in byteSuffix, but was " + value);
            }
         }

         @NotNull
         public final HexFormat.BytesHexFormat build$kotlin_stdlib() {
            return new HexFormat.BytesHexFormat(this.bytesPerLine, this.bytesPerGroup, this.groupSeparator, this.byteSeparator, this.bytePrefix, this.byteSuffix);
         }
      }

      @Metadata(
         mv = {2, 1, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0080\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0004\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"},
         d2 = {"Lkotlin/text/HexFormat$BytesHexFormat$Companion;", "", "<init>", "()V", "Default", "Lkotlin/text/HexFormat$BytesHexFormat;", "getDefault$kotlin_stdlib", "()Lkotlin/text/HexFormat$BytesHexFormat;", "kotlin-stdlib"}
      )
      public static final class Companion {
         private Companion() {
         }

         @NotNull
         public final HexFormat.BytesHexFormat getDefault$kotlin_stdlib() {
            return HexFormat.BytesHexFormat.Default;
         }

         // $FF: synthetic method
         public Companion(DefaultConstructorMarker $constructor_marker) {
            this();
         }
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007¨\u0006\n"},
      d2 = {"Lkotlin/text/HexFormat$Companion;", "", "<init>", "()V", "Default", "Lkotlin/text/HexFormat;", "getDefault", "()Lkotlin/text/HexFormat;", "UpperCase", "getUpperCase", "kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final HexFormat getDefault() {
         return HexFormat.Default;
      }

      @NotNull
      public final HexFormat getUpperCase() {
         return HexFormat.UpperCase;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 #2\u00020\u0001:\u0002\"#B)\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\b\u0010\u001a\u001a\u00020\u0003H\u0016J'\u0010\u001b\u001a\u00060\u001cj\u0002`\u001d2\n\u0010\u001e\u001a\u00060\u001cj\u0002`\u001d2\u0006\u0010\u001f\u001a\u00020\u0003H\u0000¢\u0006\u0004\b \u0010!R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0007\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0014\u001a\u00020\u0006X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000fR\u0014\u0010\u0016\u001a\u00020\u0006X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u000fR\u0014\u0010\u0018\u001a\u00020\u0006X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u000f¨\u0006$"},
      d2 = {"Lkotlin/text/HexFormat$NumberHexFormat;", "", "prefix", "", "suffix", "removeLeadingZeros", "", "minLength", "", "<init>", "(Ljava/lang/String;Ljava/lang/String;ZI)V", "getPrefix", "()Ljava/lang/String;", "getSuffix", "getRemoveLeadingZeros", "()Z", "getMinLength$annotations", "()V", "getMinLength", "()I", "isDigitsOnly", "isDigitsOnly$kotlin_stdlib", "isDigitsOnlyAndNoPadding", "isDigitsOnlyAndNoPadding$kotlin_stdlib", "ignoreCase", "getIgnoreCase$kotlin_stdlib", "toString", "appendOptionsTo", "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "sb", "indent", "appendOptionsTo$kotlin_stdlib", "(Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;", "Builder", "Companion", "kotlin-stdlib"}
   )
   public static final class NumberHexFormat {
      @NotNull
      public static final HexFormat.NumberHexFormat.Companion Companion = new HexFormat.NumberHexFormat.Companion((DefaultConstructorMarker)null);
      @NotNull
      private final String prefix;
      @NotNull
      private final String suffix;
      private final boolean removeLeadingZeros;
      private final int minLength;
      private final boolean isDigitsOnly;
      private final boolean isDigitsOnlyAndNoPadding;
      private final boolean ignoreCase;
      @NotNull
      private static final HexFormat.NumberHexFormat Default = new HexFormat.NumberHexFormat("", "", false, 1);

      public NumberHexFormat(@NotNull String prefix, @NotNull String suffix, boolean removeLeadingZeros, int minLength) {
         Intrinsics.checkNotNullParameter(prefix, "prefix");
         Intrinsics.checkNotNullParameter(suffix, "suffix");
         super();
         this.prefix = prefix;
         this.suffix = suffix;
         this.removeLeadingZeros = removeLeadingZeros;
         this.minLength = minLength;
         this.isDigitsOnly = ((CharSequence)this.prefix).length() == 0 && ((CharSequence)this.suffix).length() == 0;
         this.isDigitsOnlyAndNoPadding = this.isDigitsOnly && this.minLength == 1;
         this.ignoreCase = HexFormatKt.access$isCaseSensitive(this.prefix) || HexFormatKt.access$isCaseSensitive(this.suffix);
      }

      @NotNull
      public final String getPrefix() {
         return this.prefix;
      }

      @NotNull
      public final String getSuffix() {
         return this.suffix;
      }

      public final boolean getRemoveLeadingZeros() {
         return this.removeLeadingZeros;
      }

      public final int getMinLength() {
         return this.minLength;
      }

      /** @deprecated */
      // $FF: synthetic method
      @SinceKotlin(
         version = "2.0"
      )
      public static void getMinLength$annotations() {
      }

      public final boolean isDigitsOnly$kotlin_stdlib() {
         return this.isDigitsOnly;
      }

      public final boolean isDigitsOnlyAndNoPadding$kotlin_stdlib() {
         return this.isDigitsOnlyAndNoPadding;
      }

      public final boolean getIgnoreCase$kotlin_stdlib() {
         return this.ignoreCase;
      }

      @NotNull
      public String toString() {
         StringBuilder var1 = new StringBuilder();
         int var3 = false;
         var1.append("NumberHexFormat(").append('\n');
         this.appendOptionsTo$kotlin_stdlib(var1, "    ").append('\n');
         var1.append(")");
         return var1.toString();
      }

      @NotNull
      public final StringBuilder appendOptionsTo$kotlin_stdlib(@NotNull StringBuilder sb, @NotNull String indent) {
         Intrinsics.checkNotNullParameter(sb, "sb");
         Intrinsics.checkNotNullParameter(indent, "indent");
         StringBuilder var3 = sb.append(indent).append("prefix = \"").append(this.prefix);
         var3.append("\",").append('\n');
         var3 = sb.append(indent).append("suffix = \"").append(this.suffix);
         var3.append("\",").append('\n');
         var3 = sb.append(indent).append("removeLeadingZeros = ").append(this.removeLeadingZeros);
         char var4 = ',';
         var3.append(var4).append('\n');
         sb.append(indent).append("minLength = ").append(this.minLength);
         return sb;
      }

      @Metadata(
         mv = {2, 1, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\t\b\u0000¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u001b\u001a\u00020\u001cH\u0000¢\u0006\u0002\b\u001dR$\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR$\u0010\u000b\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\b\"\u0004\b\r\u0010\nR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R,\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0004\u001a\u00020\u00148\u0006@FX\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\u0016\u0010\u0003\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001a¨\u0006\u001e"},
         d2 = {"Lkotlin/text/HexFormat$NumberHexFormat$Builder;", "", "<init>", "()V", "value", "", "prefix", "getPrefix", "()Ljava/lang/String;", "setPrefix", "(Ljava/lang/String;)V", "suffix", "getSuffix", "setSuffix", "removeLeadingZeros", "", "getRemoveLeadingZeros", "()Z", "setRemoveLeadingZeros", "(Z)V", "", "minLength", "getMinLength$annotations", "getMinLength", "()I", "setMinLength", "(I)V", "build", "Lkotlin/text/HexFormat$NumberHexFormat;", "build$kotlin_stdlib", "kotlin-stdlib"}
      )
      @SourceDebugExtension({"SMAP\nHexFormat.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HexFormat.kt\nkotlin/text/HexFormat$NumberHexFormat$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,844:1\n1#2:845\n*E\n"})
      public static final class Builder {
         @NotNull
         private String prefix;
         @NotNull
         private String suffix;
         private boolean removeLeadingZeros;
         private int minLength;

         public Builder() {
            this.prefix = HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib().getPrefix();
            this.suffix = HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib().getSuffix();
            this.removeLeadingZeros = HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib().getRemoveLeadingZeros();
            this.minLength = HexFormat.NumberHexFormat.Companion.getDefault$kotlin_stdlib().getMinLength();
         }

         @NotNull
         public final String getPrefix() {
            return this.prefix;
         }

         public final void setPrefix(@NotNull String value) {
            Intrinsics.checkNotNullParameter(value, "value");
            if (!StringsKt.contains$default((CharSequence)value, '\n', false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)value, '\r', false, 2, (Object)null)) {
               this.prefix = value;
            } else {
               throw new IllegalArgumentException("LF and CR characters are prohibited in prefix, but was " + value);
            }
         }

         @NotNull
         public final String getSuffix() {
            return this.suffix;
         }

         public final void setSuffix(@NotNull String value) {
            Intrinsics.checkNotNullParameter(value, "value");
            if (!StringsKt.contains$default((CharSequence)value, '\n', false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)value, '\r', false, 2, (Object)null)) {
               this.suffix = value;
            } else {
               throw new IllegalArgumentException("LF and CR characters are prohibited in suffix, but was " + value);
            }
         }

         public final boolean getRemoveLeadingZeros() {
            return this.removeLeadingZeros;
         }

         public final void setRemoveLeadingZeros(boolean var1) {
            this.removeLeadingZeros = var1;
         }

         public final int getMinLength() {
            return this.minLength;
         }

         public final void setMinLength(int value) {
            if (value <= 0) {
               int var2 = false;
               String var3 = "Non-positive values are prohibited for minLength, but was " + value;
               throw new IllegalArgumentException(var3.toString());
            } else {
               this.minLength = value;
            }
         }

         /** @deprecated */
         // $FF: synthetic method
         @SinceKotlin(
            version = "2.0"
         )
         public static void getMinLength$annotations() {
         }

         @NotNull
         public final HexFormat.NumberHexFormat build$kotlin_stdlib() {
            return new HexFormat.NumberHexFormat(this.prefix, this.suffix, this.removeLeadingZeros, this.minLength);
         }
      }

      @Metadata(
         mv = {2, 1, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0080\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0004\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"},
         d2 = {"Lkotlin/text/HexFormat$NumberHexFormat$Companion;", "", "<init>", "()V", "Default", "Lkotlin/text/HexFormat$NumberHexFormat;", "getDefault$kotlin_stdlib", "()Lkotlin/text/HexFormat$NumberHexFormat;", "kotlin-stdlib"}
      )
      public static final class Companion {
         private Companion() {
         }

         @NotNull
         public final HexFormat.NumberHexFormat getDefault$kotlin_stdlib() {
            return HexFormat.NumberHexFormat.Default;
         }

         // $FF: synthetic method
         public Companion(DefaultConstructorMarker $constructor_marker) {
            this();
         }
      }
   }
}
