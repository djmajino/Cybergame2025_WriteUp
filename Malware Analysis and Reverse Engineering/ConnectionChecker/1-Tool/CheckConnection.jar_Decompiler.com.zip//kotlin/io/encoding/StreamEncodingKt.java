package kotlin.io.encoding;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/io/encoding/StreamEncodingKt__Base64IOStreamKt"}
)
public final class StreamEncodingKt extends StreamEncodingKt__Base64IOStreamKt {
   private StreamEncodingKt() {
   }
}
