package kotlin.io.path;

import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.ArrayDeque;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\n0\u000e2\u0006\u0010\t\u001a\u00020\nJ\u0018\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u0018\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0015\u001a\u00020\u00022\u0006\u0010\u0012\u001a\u00020\u0013H\u0016R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0016"},
   d2 = {"Lkotlin/io/path/DirectoryEntriesReader;", "Ljava/nio/file/SimpleFileVisitor;", "Ljava/nio/file/Path;", "followLinks", "", "<init>", "(Z)V", "getFollowLinks", "()Z", "directoryNode", "Lkotlin/io/path/PathNode;", "entries", "Lkotlin/collections/ArrayDeque;", "readEntries", "", "preVisitDirectory", "Ljava/nio/file/FileVisitResult;", "dir", "attrs", "Ljava/nio/file/attribute/BasicFileAttributes;", "visitFile", "file", "kotlin-stdlib-jdk7"}
)
@SourceDebugExtension({"SMAP\nPathTreeWalk.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PathTreeWalk.kt\nkotlin/io/path/DirectoryEntriesReader\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,180:1\n1#2:181\n*E\n"})
final class DirectoryEntriesReader extends SimpleFileVisitor<Path> {
   private final boolean followLinks;
   @Nullable
   private PathNode directoryNode;
   @NotNull
   private ArrayDeque<PathNode> entries;

   public DirectoryEntriesReader(boolean followLinks) {
      this.followLinks = followLinks;
      this.entries = new ArrayDeque();
   }

   public final boolean getFollowLinks() {
      return this.followLinks;
   }

   @NotNull
   public final List<PathNode> readEntries(@NotNull PathNode directoryNode) {
      Intrinsics.checkNotNullParameter(directoryNode, "directoryNode");
      this.directoryNode = directoryNode;
      Files.walkFileTree(directoryNode.getPath(), LinkFollowing.INSTANCE.toVisitOptions(this.followLinks), 1, (FileVisitor)this);
      this.entries.removeFirst();
      ArrayDeque var2 = this.entries;
      int var4 = false;
      this.entries = new ArrayDeque();
      return (List)var2;
   }

   @NotNull
   public FileVisitResult preVisitDirectory(@NotNull Path dir, @NotNull BasicFileAttributes attrs) {
      Intrinsics.checkNotNullParameter(dir, "dir");
      Intrinsics.checkNotNullParameter(attrs, "attrs");
      PathNode directoryEntry = new PathNode(dir, attrs.fileKey(), this.directoryNode);
      this.entries.add(directoryEntry);
      FileVisitResult var10000 = super.preVisitDirectory(dir, attrs);
      Intrinsics.checkNotNullExpressionValue(var10000, "preVisitDirectory(...)");
      return var10000;
   }

   @NotNull
   public FileVisitResult visitFile(@NotNull Path file, @NotNull BasicFileAttributes attrs) {
      Intrinsics.checkNotNullParameter(file, "file");
      Intrinsics.checkNotNullParameter(attrs, "attrs");
      PathNode fileEntry = new PathNode(file, (Object)null, this.directoryNode);
      this.entries.add(fileEntry);
      FileVisitResult var10000 = super.visitFile(file, attrs);
      Intrinsics.checkNotNullExpressionValue(var10000, "visitFile(...)");
      return var10000;
   }
}
