package kotlin.io.path;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/io/path/PathsKt__PathReadWriteKt", "kotlin/io/path/PathsKt__PathRecursiveFunctionsKt", "kotlin/io/path/PathsKt__PathUtilsKt"}
)
public final class PathsKt extends PathsKt__PathUtilsKt {
   private PathsKt() {
   }
}
