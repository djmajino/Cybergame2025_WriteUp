package kotlin.io.path;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.Unit;
import kotlin.WasExperimental;
import kotlin.internal.InlineOnly;
import kotlin.io.CloseableKt;
import kotlin.io.FilesKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\u008e\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u001c\n\u0002\b\u0004\u001a0\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010\b\u001a:\u0010\t\u001a\u00020\n*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\f2\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010\r\u001a0\u0010\u000e\u001a\u00020\u000f*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010\u0010\u001a:\u0010\u0011\u001a\u00020\u0012*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\f2\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010\u0013\u001a\r\u0010\u0014\u001a\u00020\u0015*\u00020\u0002H\u0087\b\u001a.\u0010\u0016\u001a\u00020\u0017*\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u00152\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010\u0019\u001a\u0015\u0010\u001a\u001a\u00020\u0017*\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u0015H\u0087\b\u001a\u0016\u0010\u001b\u001a\u00020\u001c*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0007\u001a7\u0010\u001d\u001a\u00020\u0017*\u00020\u00022\u0006\u0010\u001e\u001a\u00020\u001f2\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0007¢\u0006\u0002\u0010 \u001a\u001e\u0010!\u001a\u00020\u0017*\u00020\u00022\u0006\u0010\u001e\u001a\u00020\u001f2\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0007\u001a=\u0010\"\u001a\u00020\u0017*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042!\u0010#\u001a\u001d\u0012\u0013\u0012\u00110\u001c¢\u0006\f\b%\u0012\b\b&\u0012\u0004\b\b('\u0012\u0004\u0012\u00020\u00170$H\u0087\bø\u0001\u0000\u001a&\u0010(\u001a\u00020)*\u00020\u00022\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010*\u001a&\u0010+\u001a\u00020,*\u00020\u00022\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u0010-\u001a\u001d\u0010.\u001a\b\u0012\u0004\u0012\u00020\u001c0/*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001aL\u00100\u001a\u0002H1\"\u0004\b\u0000\u00101*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0018\u00102\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001c03\u0012\u0004\u0012\u0002H10$H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0002\u00104\u001a>\u00105\u001a\u00020\u0002*\u00020\u00022\f\u00106\u001a\b\u0012\u0004\u0012\u00020\u001f072\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u00108\u001a>\u00105\u001a\u00020\u0002*\u00020\u00022\f\u00106\u001a\b\u0012\u0004\u0012\u00020\u001f032\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0012\u0010\u0005\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00070\u0006\"\u00020\u0007H\u0087\b¢\u0006\u0002\u00109\u001a%\u0010:\u001a\u00020\u0002*\u00020\u00022\f\u00106\u001a\b\u0012\u0004\u0012\u00020\u001f072\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a%\u0010:\u001a\u00020\u0002*\u00020\u00022\f\u00106\u001a\b\u0012\u0004\u0012\u00020\u001f032\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0087\b\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006;"},
   d2 = {"reader", "Ljava/io/InputStreamReader;", "Ljava/nio/file/Path;", "charset", "Ljava/nio/charset/Charset;", "options", "", "Ljava/nio/file/OpenOption;", "(Ljava/nio/file/Path;Ljava/nio/charset/Charset;[Ljava/nio/file/OpenOption;)Ljava/io/InputStreamReader;", "bufferedReader", "Ljava/io/BufferedReader;", "bufferSize", "", "(Ljava/nio/file/Path;Ljava/nio/charset/Charset;I[Ljava/nio/file/OpenOption;)Ljava/io/BufferedReader;", "writer", "Ljava/io/OutputStreamWriter;", "(Ljava/nio/file/Path;Ljava/nio/charset/Charset;[Ljava/nio/file/OpenOption;)Ljava/io/OutputStreamWriter;", "bufferedWriter", "Ljava/io/BufferedWriter;", "(Ljava/nio/file/Path;Ljava/nio/charset/Charset;I[Ljava/nio/file/OpenOption;)Ljava/io/BufferedWriter;", "readBytes", "", "writeBytes", "", "array", "(Ljava/nio/file/Path;[B[Ljava/nio/file/OpenOption;)V", "appendBytes", "readText", "", "writeText", "text", "", "(Ljava/nio/file/Path;Ljava/lang/CharSequence;Ljava/nio/charset/Charset;[Ljava/nio/file/OpenOption;)V", "appendText", "forEachLine", "action", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "line", "inputStream", "Ljava/io/InputStream;", "(Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Ljava/io/InputStream;", "outputStream", "Ljava/io/OutputStream;", "(Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Ljava/io/OutputStream;", "readLines", "", "useLines", "T", "block", "Lkotlin/sequences/Sequence;", "(Ljava/nio/file/Path;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "writeLines", "lines", "", "(Ljava/nio/file/Path;Ljava/lang/Iterable;Ljava/nio/charset/Charset;[Ljava/nio/file/OpenOption;)Ljava/nio/file/Path;", "(Ljava/nio/file/Path;Lkotlin/sequences/Sequence;Ljava/nio/charset/Charset;[Ljava/nio/file/OpenOption;)Ljava/nio/file/Path;", "appendLines", "kotlin-stdlib-jdk7"},
   xs = "kotlin/io/path/PathsKt"
)
@SourceDebugExtension({"SMAP\nPathReadWrite.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PathReadWrite.kt\nkotlin/io/path/PathsKt__PathReadWriteKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 ReadWrite.kt\nkotlin/io/TextStreamsKt\n+ 4 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n*L\n1#1,346:1\n1#2:347\n1#2:349\n57#3:348\n1321#4,2:350\n*S KotlinDebug\n*F\n+ 1 PathReadWrite.kt\nkotlin/io/path/PathsKt__PathReadWriteKt\n*L\n219#1:349\n219#1:348\n219#1:350,2\n*E\n"})
class PathsKt__PathReadWriteKt {
   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final InputStreamReader reader(Path $this$reader, Charset charset, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$reader, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new InputStreamReader(Files.newInputStream($this$reader, (OpenOption[])Arrays.copyOf(options, options.length)), charset);
   }

   // $FF: synthetic method
   static InputStreamReader reader$default(Path $this$reader_u24default, Charset charset, OpenOption[] options, int var3, Object var4) throws IOException {
      if ((var3 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$reader_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new InputStreamReader(Files.newInputStream($this$reader_u24default, (OpenOption[])Arrays.copyOf(options, options.length)), charset);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final BufferedReader bufferedReader(Path $this$bufferedReader, Charset charset, int bufferSize, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$bufferedReader, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new BufferedReader((Reader)(new InputStreamReader(Files.newInputStream($this$bufferedReader, (OpenOption[])Arrays.copyOf(options, options.length)), charset)), bufferSize);
   }

   // $FF: synthetic method
   static BufferedReader bufferedReader$default(Path $this$bufferedReader_u24default, Charset charset, int bufferSize, OpenOption[] options, int var4, Object var5) throws IOException {
      if ((var4 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      if ((var4 & 2) != 0) {
         bufferSize = 8192;
      }

      Intrinsics.checkNotNullParameter($this$bufferedReader_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new BufferedReader((Reader)(new InputStreamReader(Files.newInputStream($this$bufferedReader_u24default, (OpenOption[])Arrays.copyOf(options, options.length)), charset)), bufferSize);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final OutputStreamWriter writer(Path $this$writer, Charset charset, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$writer, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new OutputStreamWriter(Files.newOutputStream($this$writer, (OpenOption[])Arrays.copyOf(options, options.length)), charset);
   }

   // $FF: synthetic method
   static OutputStreamWriter writer$default(Path $this$writer_u24default, Charset charset, OpenOption[] options, int var3, Object var4) throws IOException {
      if ((var3 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$writer_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new OutputStreamWriter(Files.newOutputStream($this$writer_u24default, (OpenOption[])Arrays.copyOf(options, options.length)), charset);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final BufferedWriter bufferedWriter(Path $this$bufferedWriter, Charset charset, int bufferSize, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$bufferedWriter, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new BufferedWriter((Writer)(new OutputStreamWriter(Files.newOutputStream($this$bufferedWriter, (OpenOption[])Arrays.copyOf(options, options.length)), charset)), bufferSize);
   }

   // $FF: synthetic method
   static BufferedWriter bufferedWriter$default(Path $this$bufferedWriter_u24default, Charset charset, int bufferSize, OpenOption[] options, int var4, Object var5) throws IOException {
      if ((var4 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      if ((var4 & 2) != 0) {
         bufferSize = 8192;
      }

      Intrinsics.checkNotNullParameter($this$bufferedWriter_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      return new BufferedWriter((Writer)(new OutputStreamWriter(Files.newOutputStream($this$bufferedWriter_u24default, (OpenOption[])Arrays.copyOf(options, options.length)), charset)), bufferSize);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final byte[] readBytes(Path $this$readBytes) throws IOException {
      Intrinsics.checkNotNullParameter($this$readBytes, "<this>");
      byte[] var10000 = Files.readAllBytes($this$readBytes);
      Intrinsics.checkNotNullExpressionValue(var10000, "readAllBytes(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final void writeBytes(Path $this$writeBytes, byte[] array, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$writeBytes, "<this>");
      Intrinsics.checkNotNullParameter(array, "array");
      Intrinsics.checkNotNullParameter(options, "options");
      Files.write($this$writeBytes, array, (OpenOption[])Arrays.copyOf(options, options.length));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final void appendBytes(Path $this$appendBytes, byte[] array) throws IOException {
      Intrinsics.checkNotNullParameter($this$appendBytes, "<this>");
      Intrinsics.checkNotNullParameter(array, "array");
      OpenOption[] var2 = new OpenOption[]{StandardOpenOption.APPEND};
      Files.write($this$appendBytes, array, var2);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @NotNull
   public static final String readText(@NotNull Path $this$readText, @NotNull Charset charset) throws IOException {
      Intrinsics.checkNotNullParameter($this$readText, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      OpenOption[] var3 = new OpenOption[0];
      Closeable var2 = (Closeable)(new InputStreamReader(Files.newInputStream($this$readText, (OpenOption[])Arrays.copyOf(var3, var3.length)), charset));
      Throwable var10 = null;

      String var11;
      try {
         InputStreamReader it = (InputStreamReader)var2;
         int var5 = false;
         var11 = TextStreamsKt.readText((Reader)it);
      } catch (Throwable var8) {
         var10 = var8;
         throw var8;
      } finally {
         CloseableKt.closeFinally(var2, var10);
      }

      return var11;
   }

   // $FF: synthetic method
   public static String readText$default(Path var0, Charset var1, int var2, Object var3) throws IOException {
      if ((var2 & 1) != 0) {
         var1 = Charsets.UTF_8;
      }

      return PathsKt.readText(var0, var1);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   public static final void writeText(@NotNull Path $this$writeText, @NotNull CharSequence text, @NotNull Charset charset, @NotNull OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$writeText, "<this>");
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      Closeable var4 = (Closeable)Files.newOutputStream($this$writeText, (OpenOption[])Arrays.copyOf(options, options.length));
      Throwable var5 = null;

      try {
         OutputStream out = (OutputStream)var4;
         int var7 = false;
         if (text instanceof String) {
            Intrinsics.checkNotNull(out);
            FilesKt.writeTextImpl(out, (String)text, charset);
         } else {
            CharsetEncoder encoder = FilesKt.newReplaceEncoder(charset);
            CharBuffer charBuffer = text instanceof CharBuffer ? ((CharBuffer)text).asReadOnlyBuffer() : CharBuffer.wrap(text);
            int var10000 = Math.min(text.length(), 8192);
            Intrinsics.checkNotNull(encoder);
            ByteBuffer byteBuffer = FilesKt.byteBufferForEncoding(var10000, encoder);

            while(charBuffer.hasRemaining()) {
               CoderResult var11 = encoder.encode(charBuffer, byteBuffer, true);
               int var13 = false;
               if (var11.isError()) {
                  throw new IllegalStateException("Check failed.");
               }

               out.write(byteBuffer.array(), 0, byteBuffer.position());
               byteBuffer.clear();
            }
         }

         Unit var18 = Unit.INSTANCE;
      } catch (Throwable var16) {
         var5 = var16;
         throw var16;
      } finally {
         CloseableKt.closeFinally(var4, var5);
      }

   }

   // $FF: synthetic method
   public static void writeText$default(Path var0, CharSequence var1, Charset var2, OpenOption[] var3, int var4, Object var5) throws IOException {
      if ((var4 & 2) != 0) {
         var2 = Charsets.UTF_8;
      }

      PathsKt.writeText(var0, var1, var2, var3);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   public static final void appendText(@NotNull Path $this$appendText, @NotNull CharSequence text, @NotNull Charset charset) throws IOException {
      Intrinsics.checkNotNullParameter($this$appendText, "<this>");
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(charset, "charset");
      OpenOption[] var3 = new OpenOption[]{StandardOpenOption.APPEND};
      PathsKt.writeText($this$appendText, text, charset, var3);
   }

   // $FF: synthetic method
   public static void appendText$default(Path var0, CharSequence var1, Charset var2, int var3, Object var4) throws IOException {
      if ((var3 & 2) != 0) {
         var2 = Charsets.UTF_8;
      }

      PathsKt.appendText(var0, var1, var2);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final void forEachLine(Path $this$forEachLine, Charset charset, Function1<? super String, Unit> action) throws IOException {
      Intrinsics.checkNotNullParameter($this$forEachLine, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(action, "action");
      BufferedReader var10000 = Files.newBufferedReader($this$forEachLine, charset);
      Intrinsics.checkNotNullExpressionValue(var10000, "newBufferedReader(...)");
      Reader $this$useLines$iv = (Reader)var10000;
      int $i$f$useLines = false;
      Closeable var5 = (Closeable)((BufferedReader)$this$useLines$iv);
      Throwable var6 = null;

      try {
         BufferedReader it$iv = (BufferedReader)var5;
         int var8 = false;
         Sequence it = TextStreamsKt.lineSequence(it$iv);
         int var10 = false;
         int $i$f$forEach = false;
         Iterator var13 = it.iterator();

         while(var13.hasNext()) {
            Object element$iv = var13.next();
            action.invoke(element$iv);
         }

         Unit var19 = Unit.INSTANCE;
      } catch (Throwable var17) {
         var6 = var17;
         throw var17;
      } finally {
         InlineMarker.finallyStart(1);
         CloseableKt.closeFinally(var5, var6);
         InlineMarker.finallyEnd(1);
      }
   }

   // $FF: synthetic method
   static void forEachLine$default(Path $this$forEachLine_u24default, Charset charset, Function1 action, int var3, Object var4) throws IOException {
      if ((var3 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$forEachLine_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(action, "action");
      BufferedReader var10000 = Files.newBufferedReader($this$forEachLine_u24default, charset);
      Intrinsics.checkNotNullExpressionValue(var10000, "newBufferedReader(...)");
      Reader $this$useLines$iv = (Reader)var10000;
      int $i$f$useLines = false;
      Closeable var5 = (Closeable)((BufferedReader)$this$useLines$iv);
      Throwable var6 = null;

      try {
         BufferedReader it$iv = (BufferedReader)var5;
         int var8 = false;
         Sequence it = TextStreamsKt.lineSequence(it$iv);
         int var10 = false;
         int $i$f$forEach = false;
         Iterator var13 = it.iterator();

         while(var13.hasNext()) {
            Object element$iv = var13.next();
            action.invoke(element$iv);
         }

         Unit var21 = Unit.INSTANCE;
      } catch (Throwable var17) {
         var6 = var17;
         throw var17;
      } finally {
         InlineMarker.finallyStart(1);
         CloseableKt.closeFinally(var5, var6);
         InlineMarker.finallyEnd(1);
      }
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final InputStream inputStream(Path $this$inputStream, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$inputStream, "<this>");
      Intrinsics.checkNotNullParameter(options, "options");
      InputStream var10000 = Files.newInputStream($this$inputStream, (OpenOption[])Arrays.copyOf(options, options.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "newInputStream(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final OutputStream outputStream(Path $this$outputStream, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$outputStream, "<this>");
      Intrinsics.checkNotNullParameter(options, "options");
      OutputStream var10000 = Files.newOutputStream($this$outputStream, (OpenOption[])Arrays.copyOf(options, options.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "newOutputStream(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final List<String> readLines(Path $this$readLines, Charset charset) throws IOException {
      Intrinsics.checkNotNullParameter($this$readLines, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      List var10000 = Files.readAllLines($this$readLines, charset);
      Intrinsics.checkNotNullExpressionValue(var10000, "readAllLines(...)");
      return var10000;
   }

   // $FF: synthetic method
   static List readLines$default(Path $this$readLines_u24default, Charset charset, int var2, Object var3) throws IOException {
      if ((var2 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$readLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      List var10000 = Files.readAllLines($this$readLines_u24default, charset);
      Intrinsics.checkNotNullExpressionValue(var10000, "readAllLines(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final <T> T useLines(Path $this$useLines, Charset charset, Function1<? super Sequence<String>, ? extends T> block) throws IOException {
      Intrinsics.checkNotNullParameter($this$useLines, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(block, "block");
      Closeable var3 = (Closeable)Files.newBufferedReader($this$useLines, charset);
      Throwable var4 = null;

      Object var11;
      try {
         BufferedReader it = (BufferedReader)var3;
         int var6 = false;
         Intrinsics.checkNotNull(it);
         var11 = block.invoke(TextStreamsKt.lineSequence(it));
      } catch (Throwable var9) {
         var4 = var9;
         throw var9;
      } finally {
         InlineMarker.finallyStart(1);
         CloseableKt.closeFinally(var3, var4);
         InlineMarker.finallyEnd(1);
      }

      return var11;
   }

   // $FF: synthetic method
   static Object useLines$default(Path $this$useLines_u24default, Charset charset, Function1 block, int var3, Object var4) throws IOException {
      if ((var3 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$useLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(block, "block");
      Closeable var11 = (Closeable)Files.newBufferedReader($this$useLines_u24default, charset);
      Throwable var12 = null;

      Object var13;
      try {
         BufferedReader it = (BufferedReader)var11;
         int var6 = false;
         Intrinsics.checkNotNull(it);
         var13 = block.invoke(TextStreamsKt.lineSequence(it));
      } catch (Throwable var9) {
         var12 = var9;
         throw var9;
      } finally {
         InlineMarker.finallyStart(1);
         CloseableKt.closeFinally(var11, var12);
         InlineMarker.finallyEnd(1);
      }

      return var13;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final Path writeLines(Path $this$writeLines, Iterable<? extends CharSequence> lines, Charset charset, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$writeLines, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      Path var10000 = Files.write($this$writeLines, lines, charset, (OpenOption[])Arrays.copyOf(options, options.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   // $FF: synthetic method
   static Path writeLines$default(Path $this$writeLines_u24default, Iterable lines, Charset charset, OpenOption[] options, int var4, Object var5) throws IOException {
      if ((var4 & 2) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$writeLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      Path var10000 = Files.write($this$writeLines_u24default, lines, charset, (OpenOption[])Arrays.copyOf(options, options.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final Path writeLines(Path $this$writeLines, Sequence<? extends CharSequence> lines, Charset charset, OpenOption... options) throws IOException {
      Intrinsics.checkNotNullParameter($this$writeLines, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      Path var10000 = Files.write($this$writeLines, SequencesKt.asIterable(lines), charset, (OpenOption[])Arrays.copyOf(options, options.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   // $FF: synthetic method
   static Path writeLines$default(Path $this$writeLines_u24default, Sequence lines, Charset charset, OpenOption[] options, int var4, Object var5) throws IOException {
      if ((var4 & 2) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$writeLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(options, "options");
      Path var10000 = Files.write($this$writeLines_u24default, SequencesKt.asIterable(lines), charset, (OpenOption[])Arrays.copyOf(options, options.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final Path appendLines(Path $this$appendLines, Iterable<? extends CharSequence> lines, Charset charset) throws IOException {
      Intrinsics.checkNotNullParameter($this$appendLines, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      OpenOption[] var3 = new OpenOption[]{StandardOpenOption.APPEND};
      Path var10000 = Files.write($this$appendLines, lines, charset, var3);
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   // $FF: synthetic method
   static Path appendLines$default(Path $this$appendLines_u24default, Iterable lines, Charset charset, int var3, Object var4) throws IOException {
      if ((var3 & 2) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$appendLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      OpenOption[] var5 = new OpenOption[]{StandardOpenOption.APPEND};
      Path var10000 = Files.write($this$appendLines_u24default, lines, charset, var5);
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @WasExperimental(
      markerClass = {ExperimentalPathApi.class}
   )
   @InlineOnly
   private static final Path appendLines(Path $this$appendLines, Sequence<? extends CharSequence> lines, Charset charset) throws IOException {
      Intrinsics.checkNotNullParameter($this$appendLines, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Iterable var10001 = SequencesKt.asIterable(lines);
      OpenOption[] var3 = new OpenOption[]{StandardOpenOption.APPEND};
      Path var10000 = Files.write($this$appendLines, var10001, charset, var3);
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   // $FF: synthetic method
   static Path appendLines$default(Path $this$appendLines_u24default, Sequence lines, Charset charset, int var3, Object var4) throws IOException {
      if ((var3 & 2) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$appendLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(lines, "lines");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Iterable var10001 = SequencesKt.asIterable(lines);
      OpenOption[] var5 = new OpenOption[]{StandardOpenOption.APPEND};
      Path var10000 = Files.write($this$appendLines_u24default, var10001, charset, var5);
      Intrinsics.checkNotNullExpressionValue(var10000, "write(...)");
      return var10000;
   }

   public PathsKt__PathReadWriteKt() {
   }
}
