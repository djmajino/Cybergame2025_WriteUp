package kotlin;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/LazyKt__LazyJVMKt", "kotlin/LazyKt__LazyKt"}
)
public final class LazyKt extends LazyKt__LazyKt {
   private LazyKt() {
   }
}
