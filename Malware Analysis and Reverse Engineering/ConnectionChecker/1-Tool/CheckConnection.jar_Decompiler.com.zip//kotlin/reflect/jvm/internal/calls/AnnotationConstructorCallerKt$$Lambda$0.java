package kotlin.reflect.jvm.internal.calls;

import java.util.Map;
import kotlin.jvm.functions.Function0;

class AnnotationConstructorCallerKt$$Lambda$0 implements Function0 {
   private final Map arg$0;

   public AnnotationConstructorCallerKt$$Lambda$0(Map var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return AnnotationConstructorCallerKt.accessor$AnnotationConstructorCallerKt$lambda0(this.arg$0);
   }
}
