package kotlin.reflect.jvm.internal.calls;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bf\u0018\u00002\u00020\u0001¨\u0006\u0002"},
   d2 = {"Lkotlin/reflect/jvm/internal/calls/BoundCaller;", "", "kotlin-reflection"}
)
public interface BoundCaller {
}
