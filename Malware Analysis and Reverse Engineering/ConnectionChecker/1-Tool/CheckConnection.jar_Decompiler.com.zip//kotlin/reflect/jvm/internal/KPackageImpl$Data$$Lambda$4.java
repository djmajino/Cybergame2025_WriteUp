package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KPackageImpl$Data$$Lambda$4 implements Function0 {
   private final KPackageImpl arg$0;
   private final KPackageImpl.Data arg$1;

   public KPackageImpl$Data$$Lambda$4(KPackageImpl var1, KPackageImpl.Data var2) {
      this.arg$0 = var1;
      this.arg$1 = var2;
   }

   public Object invoke() {
      return KPackageImpl.Data.accessor$KPackageImpl$Data$lambda4(this.arg$0, this.arg$1);
   }
}
