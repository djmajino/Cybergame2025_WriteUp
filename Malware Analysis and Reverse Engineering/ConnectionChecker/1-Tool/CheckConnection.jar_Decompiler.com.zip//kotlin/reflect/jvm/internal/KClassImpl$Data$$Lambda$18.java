package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;

class KClassImpl$Data$$Lambda$18 implements Function0 {
   private final KotlinType arg$0;
   private final KClassImpl.Data arg$1;
   private final KClassImpl arg$2;

   public KClassImpl$Data$$Lambda$18(KotlinType var1, KClassImpl.Data var2, KClassImpl var3) {
      this.arg$0 = var1;
      this.arg$1 = var2;
      this.arg$2 = var3;
   }

   public Object invoke() {
      return KClassImpl.Data.accessor$KClassImpl$Data$lambda18(this.arg$0, this.arg$1, this.arg$2);
   }
}
