package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KParameterImpl$$Lambda$1 implements Function0 {
   private final KParameterImpl arg$0;

   public KParameterImpl$$Lambda$1(KParameterImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KParameterImpl.accessor$KParameterImpl$lambda1(this.arg$0);
   }
}
