package kotlin.reflect.jvm.internal;

import java.lang.annotation.Annotation;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.NotImplementedError;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.KTypeBase;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.KClassifier;
import kotlin.reflect.KProperty;
import kotlin.reflect.KType;
import kotlin.reflect.KTypeProjection;
import kotlin.reflect.jvm.KTypesJvm;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassifierDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.TypeAliasDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.TypeParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotated;
import kotlin.reflect.jvm.internal.impl.descriptors.runtime.structure.ReflectClassUtilKt;
import kotlin.reflect.jvm.internal.impl.types.FlexibleTypesKt;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;
import kotlin.reflect.jvm.internal.impl.types.TypeProjection;
import kotlin.reflect.jvm.internal.impl.types.TypeUtils;
import kotlin.reflect.jvm.internal.impl.types.Variance;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u001b\n\u0002\b\u0006\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0012\u0010\u0015\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u0002\u001a\u00020\u0003H\u0002J\u0015\u0010\"\u001a\u00020\u00002\u0006\u0010#\u001a\u00020\u001dH\u0000¢\u0006\u0002\b$J\u0013\u0010%\u001a\u00020\u001d2\b\u0010&\u001a\u0004\u0018\u00010'H\u0096\u0002J\b\u0010(\u001a\u00020)H\u0016J\b\u0010*\u001a\u00020+H\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0016\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\u0004\u0018\u00010\u00068VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u001d\u0010\u000f\u001a\u0004\u0018\u00010\u00108VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0011\u0010\u0012R!\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00180\u00178VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u001b\u0010\u0014\u001a\u0004\b\u0019\u0010\u001aR\u0014\u0010\u001c\u001a\u00020\u001d8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u001eR\u001a\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020 0\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b!\u0010\u001a¨\u0006,²\u0006\u0010\u0010-\u001a\b\u0012\u0004\u0012\u00020\u00060\u0017X\u008a\u0084\u0002"},
   d2 = {"Lkotlin/reflect/jvm/internal/KTypeImpl;", "Lkotlin/jvm/internal/KTypeBase;", "type", "Lkotlin/reflect/jvm/internal/impl/types/KotlinType;", "computeJavaType", "Lkotlin/Function0;", "Ljava/lang/reflect/Type;", "<init>", "(Lorg/jetbrains/kotlin/types/KotlinType;Lkotlin/jvm/functions/Function0;)V", "getType", "()Lorg/jetbrains/kotlin/types/KotlinType;", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "javaType", "getJavaType", "()Ljava/lang/reflect/Type;", "classifier", "Lkotlin/reflect/KClassifier;", "getClassifier", "()Lkotlin/reflect/KClassifier;", "classifier$delegate", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "convert", "arguments", "", "Lkotlin/reflect/KTypeProjection;", "getArguments", "()Ljava/util/List;", "arguments$delegate", "isMarkedNullable", "", "()Z", "annotations", "", "getAnnotations", "makeNullableAsSpecified", "nullable", "makeNullableAsSpecified$kotlin_reflection", "equals", "other", "", "hashCode", "", "toString", "", "kotlin-reflection", "parameterizedTypeArguments"}
)
@SourceDebugExtension({"SMAP\nKTypeImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KTypeImpl.kt\nkotlin/reflect/jvm/internal/KTypeImpl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,136:1\n1#2:137\n1573#3:138\n1604#3,4:139\n*S KotlinDebug\n*F\n+ 1 KTypeImpl.kt\nkotlin/reflect/jvm/internal/KTypeImpl\n*L\n81#1:138\n81#1:139,4\n*E\n"})
public final class KTypeImpl implements KTypeBase {
   // $FF: synthetic field
   static final KProperty<Object>[] $$delegatedProperties;
   @NotNull
   private final KotlinType type;
   @Nullable
   private final ReflectProperties.LazySoftVal<Type> computeJavaType;
   @NotNull
   private final ReflectProperties.LazySoftVal classifier$delegate;
   @NotNull
   private final ReflectProperties.LazySoftVal arguments$delegate;

   public KTypeImpl(@NotNull KotlinType type, @Nullable Function0<? extends Type> computeJavaType) {
      Intrinsics.checkNotNullParameter(type, "type");
      super();
      this.type = type;
      KTypeImpl var10000 = this;
      ReflectProperties.LazySoftVal var10001 = computeJavaType instanceof ReflectProperties.LazySoftVal ? (ReflectProperties.LazySoftVal)computeJavaType : null;
      if ((computeJavaType instanceof ReflectProperties.LazySoftVal ? (ReflectProperties.LazySoftVal)computeJavaType : null) == null) {
         if (computeJavaType != null) {
            int var4 = false;
            var10001 = ReflectProperties.lazySoft(computeJavaType);
            var10000 = this;
         } else {
            var10001 = null;
         }
      }

      var10000.computeJavaType = var10001;
      this.classifier$delegate = ReflectProperties.lazySoft(new KTypeImpl$$Lambda$0(this));
      this.arguments$delegate = ReflectProperties.lazySoft(new KTypeImpl$$Lambda$1(this, computeJavaType));
   }

   // $FF: synthetic method
   public KTypeImpl(KotlinType var1, Function0 var2, int var3, DefaultConstructorMarker var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      this(var1, var2);
   }

   @NotNull
   public final KotlinType getType() {
      return this.type;
   }

   @Nullable
   public Type getJavaType() {
      ReflectProperties.LazySoftVal var10000 = this.computeJavaType;
      return var10000 != null ? (Type)var10000.invoke() : null;
   }

   @Nullable
   public KClassifier getClassifier() {
      return (KClassifier)this.classifier$delegate.getValue(this, $$delegatedProperties[0]);
   }

   private final KClassifier convert(KotlinType type) {
      ClassifierDescriptor descriptor = type.getConstructor().getDeclarationDescriptor();
      if (descriptor instanceof ClassDescriptor) {
         Class var10000 = UtilKt.toJavaClass((ClassDescriptor)descriptor);
         if (var10000 == null) {
            return null;
         } else {
            Class jClass = var10000;
            if (jClass.isArray()) {
               TypeProjection var8 = (TypeProjection)CollectionsKt.singleOrNull(type.getArguments());
               if (var8 != null) {
                  KotlinType var9 = var8.getType();
                  if (var9 != null) {
                     KotlinType argument = var9;
                     KClassifier var10 = this.convert(argument);
                     if (var10 == null) {
                        throw new KotlinReflectionInternalError("Cannot determine classifier for array element type: " + this);
                     }

                     KClassifier elementClassifier = var10;
                     return (KClassifier)(new KClassImpl(UtilKt.createArrayType(JvmClassMappingKt.getJavaClass(KTypesJvm.getJvmErasure(elementClassifier)))));
                  }
               }

               return (KClassifier)(new KClassImpl(jClass));
            } else if (!TypeUtils.isNullableType(type)) {
               KClassImpl var7 = new KClassImpl;
               Class var10002 = ReflectClassUtilKt.getPrimitiveByWrapper(jClass);
               if (var10002 == null) {
                  var10002 = jClass;
               }

               var7.<init>(var10002);
               return (KClassifier)var7;
            } else {
               return (KClassifier)(new KClassImpl(jClass));
            }
         }
      } else if (descriptor instanceof TypeParameterDescriptor) {
         return (KClassifier)(new KTypeParameterImpl((KTypeParameterOwnerImpl)null, (TypeParameterDescriptor)descriptor));
      } else if (descriptor instanceof TypeAliasDescriptor) {
         String var3 = "Type alias classifiers are not yet supported";
         throw new NotImplementedError("An operation is not implemented: " + var3);
      } else {
         return null;
      }
   }

   @NotNull
   public List<KTypeProjection> getArguments() {
      Object var10000 = this.arguments$delegate.getValue(this, $$delegatedProperties[1]);
      Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
      return (List)var10000;
   }

   public boolean isMarkedNullable() {
      return this.type.isMarkedNullable();
   }

   @NotNull
   public List<Annotation> getAnnotations() {
      return UtilKt.computeAnnotations((Annotated)this.type);
   }

   @NotNull
   public final KTypeImpl makeNullableAsSpecified$kotlin_reflection(boolean nullable) {
      if (!FlexibleTypesKt.isFlexible(this.type) && this.isMarkedNullable() == nullable) {
         return this;
      } else {
         KotlinType var10002 = TypeUtils.makeNullableAsSpecified(this.type, nullable);
         Intrinsics.checkNotNullExpressionValue(var10002, "makeNullableAsSpecified(...)");
         return new KTypeImpl(var10002, (Function0)this.computeJavaType);
      }
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof KTypeImpl && Intrinsics.areEqual((Object)this.type, (Object)((KTypeImpl)other).type) && Intrinsics.areEqual((Object)this.getClassifier(), (Object)((KTypeImpl)other).getClassifier()) && Intrinsics.areEqual((Object)this.getArguments(), (Object)((KTypeImpl)other).getArguments());
   }

   public int hashCode() {
      int var10001 = 31 * this.type.hashCode();
      KClassifier var10002 = this.getClassifier();
      return 31 * (var10001 + (var10002 != null ? var10002.hashCode() : 0)) + this.getArguments().hashCode();
   }

   @NotNull
   public String toString() {
      return ReflectionObjectRenderer.INSTANCE.renderType(this.type);
   }

   private static final KClassifier classifier_delegate$lambda$0(KTypeImpl this$0) {
      return this$0.convert(this$0.type);
   }

   private static final List arguments_delegate$lambda$5$lambda$1(KTypeImpl this$0) {
      Type var10000 = this$0.getJavaType();
      Intrinsics.checkNotNull(var10000);
      return ReflectClassUtilKt.getParameterizedTypeArguments(var10000);
   }

   private static final List<Type> arguments_delegate$lambda$5$lambda$2(Lazy<? extends List<? extends Type>> $parameterizedTypeArguments$delegate) {
      return (List)$parameterizedTypeArguments$delegate.getValue();
   }

   private static final Type arguments_delegate$lambda$5$lambda$4$lambda$3(KTypeImpl this$0, int $i, Lazy<? extends List<? extends Type>> parameterizedTypeArguments$delegate) {
      Type javaType = this$0.getJavaType();
      Type var10000;
      if (javaType instanceof Class) {
         Class var4 = ((Class)javaType).isArray() ? ((Class)javaType).getComponentType() : Object.class;
         Intrinsics.checkNotNull(var4);
         var10000 = (Type)var4;
      } else {
         Type argument;
         if (javaType instanceof GenericArrayType) {
            if ($i != 0) {
               throw new KotlinReflectionInternalError("Array type has been queried for a non-0th argument: " + this$0);
            }

            argument = ((GenericArrayType)javaType).getGenericComponentType();
            Intrinsics.checkNotNull(argument);
            var10000 = argument;
         } else {
            if (!(javaType instanceof ParameterizedType)) {
               throw new KotlinReflectionInternalError("Non-generic type has been queried for arguments: " + this$0);
            }

            argument = (Type)arguments_delegate$lambda$5$lambda$2(parameterizedTypeArguments$delegate).get($i);
            if (!(argument instanceof WildcardType)) {
               var10000 = argument;
            } else {
               Type[] var7 = ((WildcardType)argument).getLowerBounds();
               Intrinsics.checkNotNullExpressionValue(var7, "getLowerBounds(...)");
               var10000 = (Type)ArraysKt.firstOrNull((Object[])var7);
               if (var10000 == null) {
                  var7 = ((WildcardType)argument).getUpperBounds();
                  Intrinsics.checkNotNullExpressionValue(var7, "getUpperBounds(...)");
                  var10000 = (Type)ArraysKt.first((Object[])var7);
               }

               Type var5 = var10000;
               Intrinsics.checkNotNull(var5);
               var10000 = var5;
            }
         }
      }

      return var10000;
   }

   private static final List arguments_delegate$lambda$5(KTypeImpl this$0, Function0 $computeJavaType) {
      List typeArguments = this$0.type.getArguments();
      if (typeArguments.isEmpty()) {
         return CollectionsKt.emptyList();
      } else {
         Lazy parameterizedTypeArguments$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KTypeImpl$$Lambda$2(this$0));
         Iterable $this$mapIndexed$iv = (Iterable)typeArguments;
         int $i$f$mapIndexed = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$mapIndexed$iv, 10)));
         int $i$f$mapIndexedTo = false;
         int index$iv$iv = 0;

         KTypeProjection var10000;
         for(Iterator var10 = $this$mapIndexed$iv.iterator(); var10.hasNext(); destination$iv$iv.add(var10000)) {
            Object item$iv$iv = var10.next();
            int var12 = index$iv$iv++;
            if (var12 < 0) {
               CollectionsKt.throwIndexOverflow();
            }

            TypeProjection typeProjection = (TypeProjection)item$iv$iv;
            int var15 = false;
            if (typeProjection.isStarProjection()) {
               var10000 = KTypeProjection.Companion.getSTAR();
            } else {
               KotlinType var10002 = typeProjection.getType();
               Intrinsics.checkNotNullExpressionValue(var10002, "getType(...)");
               KTypeImpl type = new KTypeImpl(var10002, $computeJavaType == null ? null : new KTypeImpl$$Lambda$3(this$0, var12, parameterizedTypeArguments$delegate));
               switch(KTypeImpl.WhenMappings.$EnumSwitchMapping$0[typeProjection.getProjectionKind().ordinal()]) {
               case 1:
                  var10000 = KTypeProjection.Companion.invariant((KType)type);
                  break;
               case 2:
                  var10000 = KTypeProjection.Companion.contravariant((KType)type);
                  break;
               case 3:
                  var10000 = KTypeProjection.Companion.covariant((KType)type);
                  break;
               default:
                  throw new NoWhenBranchMatchedException();
               }
            }
         }

         return (List)destination$iv$iv;
      }
   }

   static {
      KProperty[] var0 = new KProperty[]{Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KTypeImpl.class, "classifier", "getClassifier()Lkotlin/reflect/KClassifier;", 0))), Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KTypeImpl.class, "arguments", "getArguments()Ljava/util/List;", 0)))};
      $$delegatedProperties = var0;
   }

   // $FF: synthetic method
   static KClassifier accessor$KTypeImpl$lambda0(KTypeImpl var0) {
      return classifier_delegate$lambda$0(var0);
   }

   // $FF: synthetic method
   static List accessor$KTypeImpl$lambda1(KTypeImpl var0, Function0 var1) {
      return arguments_delegate$lambda$5(var0, var1);
   }

   // $FF: synthetic method
   static List accessor$KTypeImpl$lambda2(KTypeImpl var0) {
      return arguments_delegate$lambda$5$lambda$1(var0);
   }

   // $FF: synthetic method
   static Type accessor$KTypeImpl$lambda3(KTypeImpl var0, int var1, Lazy var2) {
      return arguments_delegate$lambda$5$lambda$4$lambda$3(var0, var1, var2);
   }

   // $FF: synthetic class
   @Metadata(
      mv = {2, 1, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[Variance.values().length];

         try {
            var0[Variance.INVARIANT.ordinal()] = 1;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[Variance.IN_VARIANCE.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[Variance.OUT_VARIANCE.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$0 = var0;
      }
   }
}
