package kotlin.reflect.jvm.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.CallableReference;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.FunctionBase;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.KFunction;
import kotlin.reflect.KParameter;
import kotlin.reflect.KProperty;
import kotlin.reflect.jvm.internal.calls.AnnotationConstructorCaller;
import kotlin.reflect.jvm.internal.calls.Caller;
import kotlin.reflect.jvm.internal.calls.CallerImpl;
import kotlin.reflect.jvm.internal.calls.CallerKt;
import kotlin.reflect.jvm.internal.calls.ValueClassAwareCaller;
import kotlin.reflect.jvm.internal.calls.ValueClassAwareCallerKt;
import kotlin.reflect.jvm.internal.impl.descriptors.CallableMemberDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ConstructorDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ReceiverParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ValueParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.resolve.InlineClassesUtilsKt;
import kotlin.reflect.jvm.internal.impl.resolve.descriptorUtil.DescriptorUtilsKt;
import kotlin.reflect.jvm.internal.impl.resolve.jvm.InlineClassManglingRulesKt;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;
import kotlin.sequences.Sequence;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\f\b\u0000\u0018\u00002\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00032\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00042\u00020\u0005B7\b\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u000e\u0010\u000fB+\b\u0016\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\b\u0010\u0010\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u000e\u0010\u0011B\u0019\b\u0016\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\u0012\u001a\u00020\f¢\u0006\u0004\b\u000e\u0010\u0013J\u0012\u0010(\u001a\u0004\u0018\u00010\f2\u0006\u0010\u0012\u001a\u00020\fH\u0002J\u0010\u0010+\u001a\u00020\u00172\u0006\u0010,\u001a\u00020-H\u0002J\u001c\u0010.\u001a\u0006\u0012\u0002\b\u00030 2\u0006\u0010,\u001a\u00020-2\u0006\u0010/\u001a\u00020\u0017H\u0002J\u0010\u00100\u001a\u0002012\u0006\u0010,\u001a\u00020-H\u0002J\u0010\u00102\u001a\u0002012\u0006\u0010,\u001a\u00020-H\u0002J.\u00103\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u000305042\n\u0010,\u001a\u0006\u0012\u0002\b\u0003052\u0006\u0010\u0012\u001a\u00020\f2\u0006\u00106\u001a\u00020\u0017H\u0002J\u0013\u0010@\u001a\u00020\u00172\b\u0010A\u001a\u0004\u0018\u00010\u0002H\u0096\u0002J\b\u0010B\u001a\u000208H\u0016J\b\u0010C\u001a\u00020\tH\u0016R\u0014\u0010\u0006\u001a\u00020\u0007X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u000e\u0010\n\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u0002X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\u00020\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0018R\u001b\u0010\u0012\u001a\u00020\f8VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u0019\u0010\u001aR\u0014\u0010\b\u001a\u00020\t8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u001eR\u001f\u0010\u001f\u001a\u0006\u0012\u0002\b\u00030 8VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b#\u0010$\u001a\u0004\b!\u0010\"R!\u0010%\u001a\b\u0012\u0002\b\u0003\u0018\u00010 8VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b'\u0010$\u001a\u0004\b&\u0010\"R\u0016\u0010\u0010\u001a\u0004\u0018\u00010\u00028BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b)\u0010*R\u0014\u00107\u001a\u0002088VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b9\u0010:R\u0014\u0010;\u001a\u00020\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b;\u0010\u0018R\u0014\u0010<\u001a\u00020\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b<\u0010\u0018R\u0014\u0010=\u001a\u00020\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b=\u0010\u0018R\u0014\u0010>\u001a\u00020\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b>\u0010\u0018R\u0014\u0010?\u001a\u00020\u00178VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b?\u0010\u0018¨\u0006D"},
   d2 = {"Lkotlin/reflect/jvm/internal/KFunctionImpl;", "Lkotlin/reflect/jvm/internal/KCallableImpl;", "", "Lkotlin/reflect/KFunction;", "Lkotlin/jvm/internal/FunctionBase;", "Lkotlin/reflect/jvm/internal/FunctionWithAllInvokes;", "container", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "name", "", "signature", "descriptorInitialValue", "Lkotlin/reflect/jvm/internal/impl/descriptors/FunctionDescriptor;", "rawBoundReceiver", "<init>", "(Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Ljava/lang/String;Ljava/lang/String;Lorg/jetbrains/kotlin/descriptors/FunctionDescriptor;Ljava/lang/Object;)V", "boundReceiver", "(Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", "descriptor", "(Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Lorg/jetbrains/kotlin/descriptors/FunctionDescriptor;)V", "getContainer", "()Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "isBound", "", "()Z", "getDescriptor", "()Lorg/jetbrains/kotlin/descriptors/FunctionDescriptor;", "descriptor$delegate", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "getName", "()Ljava/lang/String;", "caller", "Lkotlin/reflect/jvm/internal/calls/Caller;", "getCaller", "()Lkotlin/reflect/jvm/internal/calls/Caller;", "caller$delegate", "Lkotlin/Lazy;", "defaultCaller", "getDefaultCaller", "defaultCaller$delegate", "getFunctionWithDefaultParametersForValueClassOverride", "getBoundReceiver", "()Ljava/lang/Object;", "useBoxedBoundReceiver", "member", "Ljava/lang/reflect/Method;", "createStaticMethodCaller", "isCallByToValueClassMangledMethod", "createJvmStaticInObjectCaller", "Lkotlin/reflect/jvm/internal/calls/CallerImpl$Method;", "createInstanceMethodCaller", "createConstructorCaller", "Lkotlin/reflect/jvm/internal/calls/CallerImpl;", "Ljava/lang/reflect/Constructor;", "isDefault", "arity", "", "getArity", "()I", "isInline", "isExternal", "isOperator", "isInfix", "isSuspend", "equals", "other", "hashCode", "toString", "kotlin-reflection"}
)
@SourceDebugExtension({"SMAP\nKFunctionImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KFunctionImpl.kt\nkotlin/reflect/jvm/internal/KFunctionImpl\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,235:1\n2746#2,3:236\n1761#2,3:240\n1563#2:244\n1634#2,3:245\n1563#2:249\n1634#2,3:250\n1563#2:253\n1634#2,3:254\n1563#2:257\n1634#2,3:258\n183#3:239\n184#3:243\n1#4:248\n*S KotlinDebug\n*F\n+ 1 KFunctionImpl.kt\nkotlin/reflect/jvm/internal/KFunctionImpl\n*L\n157#1:236,3\n164#1:240,3\n72#1:244\n72#1:245,3\n87#1:249\n87#1:250,3\n123#1:253\n123#1:254,3\n128#1:257\n128#1:258,3\n164#1:239\n164#1:243\n*E\n"})
public final class KFunctionImpl extends KCallableImpl<Object> implements FunctionBase<Object>, KFunction<Object>, FunctionWithAllInvokes {
   // $FF: synthetic field
   static final KProperty<Object>[] $$delegatedProperties;
   @NotNull
   private final KDeclarationContainerImpl container;
   @NotNull
   private final String signature;
   @Nullable
   private final Object rawBoundReceiver;
   @NotNull
   private final ReflectProperties.LazySoftVal descriptor$delegate;
   @NotNull
   private final Lazy caller$delegate;
   @NotNull
   private final Lazy defaultCaller$delegate;

   private KFunctionImpl(KDeclarationContainerImpl container, String name, String signature, FunctionDescriptor descriptorInitialValue, Object rawBoundReceiver) {
      this.container = container;
      this.signature = signature;
      this.rawBoundReceiver = rawBoundReceiver;
      this.descriptor$delegate = ReflectProperties.lazySoft(descriptorInitialValue, new KFunctionImpl$$Lambda$0(this, name));
      this.caller$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KFunctionImpl$$Lambda$1(this));
      this.defaultCaller$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KFunctionImpl$$Lambda$2(this));
   }

   // $FF: synthetic method
   KFunctionImpl(KDeclarationContainerImpl var1, String var2, String var3, FunctionDescriptor var4, Object var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 16) != 0) {
         var5 = CallableReference.NO_RECEIVER;
      }

      this(var1, var2, var3, var4, var5);
   }

   @NotNull
   public KDeclarationContainerImpl getContainer() {
      return this.container;
   }

   public KFunctionImpl(@NotNull KDeclarationContainerImpl container, @NotNull String name, @NotNull String signature, @Nullable Object boundReceiver) {
      Intrinsics.checkNotNullParameter(container, "container");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(signature, "signature");
      this(container, name, signature, (FunctionDescriptor)null, boundReceiver);
   }

   public KFunctionImpl(@NotNull KDeclarationContainerImpl container, @NotNull FunctionDescriptor descriptor) {
      Intrinsics.checkNotNullParameter(container, "container");
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      String var10002 = descriptor.getName().asString();
      Intrinsics.checkNotNullExpressionValue(var10002, "asString(...)");
      this(container, var10002, RuntimeTypeMapper.INSTANCE.mapSignature(descriptor).asString(), descriptor, (Object)null, 16, (DefaultConstructorMarker)null);
   }

   public boolean isBound() {
      return this.rawBoundReceiver != CallableReference.NO_RECEIVER;
   }

   @NotNull
   public FunctionDescriptor getDescriptor() {
      Object var10000 = this.descriptor$delegate.getValue(this, $$delegatedProperties[0]);
      Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
      return (FunctionDescriptor)var10000;
   }

   @NotNull
   public String getName() {
      String var10000 = this.getDescriptor().getName().asString();
      Intrinsics.checkNotNullExpressionValue(var10000, "asString(...)");
      return var10000;
   }

   @NotNull
   public Caller<?> getCaller() {
      Lazy var1 = this.caller$delegate;
      return (Caller)var1.getValue();
   }

   @Nullable
   public Caller<?> getDefaultCaller() {
      Lazy var1 = this.defaultCaller$delegate;
      return (Caller)var1.getValue();
   }

   private final FunctionDescriptor getFunctionWithDefaultParametersForValueClassOverride(FunctionDescriptor descriptor) {
      List var10000 = descriptor.getValueParameters();
      Intrinsics.checkNotNullExpressionValue(var10000, "getValueParameters(...)");
      Iterable $this$none$iv = (Iterable)var10000;
      int $i$f$none = false;
      boolean var21;
      if ($this$none$iv instanceof Collection && ((Collection)$this$none$iv).isEmpty()) {
         var21 = true;
      } else {
         Iterator var4 = $this$none$iv.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var21 = true;
               break;
            }

            Object element$iv = var4.next();
            ValueParameterDescriptor it = (ValueParameterDescriptor)element$iv;
            int var7 = false;
            if (it.declaresDefaultValue()) {
               var21 = false;
               break;
            }
         }
      }

      if (var21) {
         DeclarationDescriptor var22 = descriptor.getContainingDeclaration();
         Intrinsics.checkNotNullExpressionValue(var22, "getContainingDeclaration(...)");
         if (InlineClassesUtilsKt.isValueClass(var22)) {
            Member var23 = this.getCaller().getMember();
            Intrinsics.checkNotNull(var23);
            if (Modifier.isStatic(var23.getModifiers())) {
               Sequence $this$firstOrNull$iv = DescriptorUtilsKt.overriddenTreeAsSequence((CallableMemberDescriptor)descriptor, false);
               int $i$f$firstOrNull = false;
               Iterator var18 = $this$firstOrNull$iv.iterator();

               Object var24;
               while(true) {
                  if (!var18.hasNext()) {
                     var24 = null;
                     break;
                  }

                  Object element$iv = var18.next();
                  CallableMemberDescriptor function = (CallableMemberDescriptor)element$iv;
                  int var8 = false;
                  var10000 = function.getValueParameters();
                  Intrinsics.checkNotNullExpressionValue(var10000, "getValueParameters(...)");
                  Iterable $this$any$iv = (Iterable)var10000;
                  int $i$f$any = false;
                  if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                     var21 = false;
                  } else {
                     Iterator var11 = $this$any$iv.iterator();

                     while(true) {
                        if (!var11.hasNext()) {
                           var21 = false;
                           break;
                        }

                        Object element$iv = var11.next();
                        ValueParameterDescriptor it = (ValueParameterDescriptor)element$iv;
                        int var14 = false;
                        if (it.declaresDefaultValue()) {
                           var21 = true;
                           break;
                        }
                     }
                  }

                  if (var21) {
                     var24 = element$iv;
                     break;
                  }
               }

               Object var15 = var24;
               return var15 instanceof FunctionDescriptor ? (FunctionDescriptor)var15 : null;
            }
         }
      }

      return null;
   }

   private final Object getBoundReceiver() {
      return ValueClassAwareCallerKt.coerceToExpectedReceiverType(this.rawBoundReceiver, (CallableMemberDescriptor)this.getDescriptor());
   }

   private final boolean useBoxedBoundReceiver(Method member) {
      boolean var3;
      label32: {
         ReceiverParameterDescriptor var10000 = this.getDescriptor().getDispatchReceiverParameter();
         if (var10000 != null) {
            KotlinType var2 = var10000.getType();
            if (var2 != null) {
               var3 = InlineClassesUtilsKt.isInlineClassType(var2);
               break label32;
            }
         }

         var3 = false;
      }

      if (var3) {
         Class[] var4 = member.getParameterTypes();
         Intrinsics.checkNotNullExpressionValue(var4, "getParameterTypes(...)");
         Class var5 = (Class)ArraysKt.firstOrNull((Object[])var4);
         if (var5 != null ? var5.isInterface() : false) {
            var3 = true;
            return var3;
         }
      }

      var3 = false;
      return var3;
   }

   private final Caller<?> createStaticMethodCaller(Method member, boolean isCallByToValueClassMangledMethod) {
      return this.isBound() ? (Caller)(new CallerImpl.Method.BoundStatic(member, isCallByToValueClassMangledMethod, this.useBoxedBoundReceiver(member) ? this.rawBoundReceiver : this.getBoundReceiver())) : (Caller)(new CallerImpl.Method.Static(member));
   }

   private final CallerImpl.Method createJvmStaticInObjectCaller(Method member) {
      return this.isBound() ? (CallerImpl.Method)(new CallerImpl.Method.BoundJvmStaticInObject(member)) : (CallerImpl.Method)(new CallerImpl.Method.JvmStaticInObject(member));
   }

   private final CallerImpl.Method createInstanceMethodCaller(Method member) {
      return this.isBound() ? (CallerImpl.Method)(new CallerImpl.Method.BoundInstance(member, this.getBoundReceiver())) : (CallerImpl.Method)(new CallerImpl.Method.Instance(member));
   }

   private final CallerImpl<Constructor<?>> createConstructorCaller(Constructor<?> member, FunctionDescriptor descriptor, boolean isDefault) {
      return !isDefault && InlineClassManglingRulesKt.shouldHideConstructorDueToValueClassTypeValueParameters((CallableMemberDescriptor)descriptor) ? (this.isBound() ? (CallerImpl)(new CallerImpl.AccessorForHiddenBoundConstructor(member, this.getBoundReceiver())) : (CallerImpl)(new CallerImpl.AccessorForHiddenConstructor(member))) : (this.isBound() ? (CallerImpl)(new CallerImpl.BoundConstructor(member, this.getBoundReceiver())) : (CallerImpl)(new CallerImpl.Constructor(member)));
   }

   public int getArity() {
      return CallerKt.getArity(this.getCaller());
   }

   public boolean isInline() {
      return this.getDescriptor().isInline();
   }

   public boolean isExternal() {
      return this.getDescriptor().isExternal();
   }

   public boolean isOperator() {
      return this.getDescriptor().isOperator();
   }

   public boolean isInfix() {
      return this.getDescriptor().isInfix();
   }

   public boolean isSuspend() {
      return this.getDescriptor().isSuspend();
   }

   public boolean equals(@Nullable Object other) {
      KFunctionImpl var10000 = UtilKt.asKFunctionImpl(other);
      if (var10000 == null) {
         return false;
      } else {
         KFunctionImpl that = var10000;
         return Intrinsics.areEqual((Object)this.getContainer(), (Object)that.getContainer()) && Intrinsics.areEqual((Object)this.getName(), (Object)that.getName()) && Intrinsics.areEqual((Object)this.signature, (Object)that.signature) && Intrinsics.areEqual(this.rawBoundReceiver, that.rawBoundReceiver);
      }
   }

   public int hashCode() {
      return (this.getContainer().hashCode() * 31 + this.getName().hashCode()) * 31 + this.signature.hashCode();
   }

   @NotNull
   public String toString() {
      return ReflectionObjectRenderer.INSTANCE.renderFunction(this.getDescriptor());
   }

   @Nullable
   public Object invoke() {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this);
   }

   @Nullable
   public Object invoke(@Nullable Object p1) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16, @Nullable Object p17) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16, @Nullable Object p17, @Nullable Object p18) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16, @Nullable Object p17, @Nullable Object p18, @Nullable Object p19) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16, @Nullable Object p17, @Nullable Object p18, @Nullable Object p19, @Nullable Object p20) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16, @Nullable Object p17, @Nullable Object p18, @Nullable Object p19, @Nullable Object p20, @Nullable Object p21) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21);
   }

   @Nullable
   public Object invoke(@Nullable Object p1, @Nullable Object p2, @Nullable Object p3, @Nullable Object p4, @Nullable Object p5, @Nullable Object p6, @Nullable Object p7, @Nullable Object p8, @Nullable Object p9, @Nullable Object p10, @Nullable Object p11, @Nullable Object p12, @Nullable Object p13, @Nullable Object p14, @Nullable Object p15, @Nullable Object p16, @Nullable Object p17, @Nullable Object p18, @Nullable Object p19, @Nullable Object p20, @Nullable Object p21, @Nullable Object p22) {
      return FunctionWithAllInvokes.DefaultImpls.invoke(this, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22);
   }

   private static final FunctionDescriptor descriptor_delegate$lambda$0(KFunctionImpl this$0, String $name) {
      return this$0.getContainer().findFunctionDescriptor($name, this$0.signature);
   }

   private static final Caller caller_delegate$lambda$4(KFunctionImpl this$0) {
      JvmFunctionSignature jvmSignature = RuntimeTypeMapper.INSTANCE.mapSignature(this$0.getDescriptor());
      Class var13;
      Member var10000;
      List var10001;
      Class var35;
      if (jvmSignature instanceof JvmFunctionSignature.KotlinConstructor) {
         if (this$0.isAnnotationConstructor()) {
            var35 = this$0.getContainer().getJClass();
            Iterable $this$map$iv = (Iterable)this$0.getParameters();
            var13 = var35;
            int $i$f$map = false;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
            int $i$f$mapTo = false;
            Iterator var8 = $this$map$iv.iterator();

            while(var8.hasNext()) {
               Object item$iv$iv = var8.next();
               KParameter it = (KParameter)item$iv$iv;
               int var11 = false;
               String var36 = it.getName();
               Intrinsics.checkNotNull(var36);
               destination$iv$iv.add(var36);
            }

            var10001 = (List)destination$iv$iv;
            Object var15 = null;
            byte var16 = 16;
            Object var17 = null;
            AnnotationConstructorCaller.Origin var18 = AnnotationConstructorCaller.Origin.KOTLIN;
            AnnotationConstructorCaller.CallMode var19 = AnnotationConstructorCaller.CallMode.POSITIONAL_CALL;
            List var20 = var10001;
            return (Caller)(new AnnotationConstructorCaller(var13, var20, var19, var18, (List)var17, var16, (DefaultConstructorMarker)var15));
         }

         var10000 = (Member)this$0.getContainer().findConstructorBySignature(((JvmFunctionSignature.KotlinConstructor)jvmSignature).getConstructorDesc());
      } else {
         boolean $i$f$map;
         if (jvmSignature instanceof JvmFunctionSignature.KotlinFunction) {
            FunctionDescriptor it = this$0.getDescriptor();
            $i$f$map = false;
            DeclarationDescriptor var37 = it.getContainingDeclaration();
            Intrinsics.checkNotNullExpressionValue(var37, "getContainingDeclaration(...)");
            if (InlineClassesUtilsKt.isMultiFieldValueClass(var37) && it instanceof ConstructorDescriptor && ((ConstructorDescriptor)it).isPrimary()) {
               FunctionDescriptor var10002 = this$0.getDescriptor();
               KDeclarationContainerImpl var10003 = this$0.getContainer();
               String var10004 = ((JvmFunctionSignature.KotlinFunction)jvmSignature).getMethodDesc();
               List var10005 = this$0.getDescriptor().getValueParameters();
               Intrinsics.checkNotNullExpressionValue(var10005, "getValueParameters(...)");
               return (Caller)(new ValueClassAwareCaller.MultiFieldValueClassPrimaryConstructorCaller(var10002, var10003, var10004, var10005));
            }

            var10000 = (Member)this$0.getContainer().findMethodBySignature(((JvmFunctionSignature.KotlinFunction)jvmSignature).getMethodName(), ((JvmFunctionSignature.KotlinFunction)jvmSignature).getMethodDesc());
         } else if (jvmSignature instanceof JvmFunctionSignature.JavaMethod) {
            Method var38 = ((JvmFunctionSignature.JavaMethod)jvmSignature).getMethod();
            Intrinsics.checkNotNull(var38, "null cannot be cast to non-null type java.lang.reflect.Member");
            var10000 = (Member)var38;
         } else {
            if (!(jvmSignature instanceof JvmFunctionSignature.JavaConstructor)) {
               if (!(jvmSignature instanceof JvmFunctionSignature.FakeJavaAnnotationConstructor)) {
                  throw new NoWhenBranchMatchedException();
               }

               List methods = ((JvmFunctionSignature.FakeJavaAnnotationConstructor)jvmSignature).getMethods();
               var35 = this$0.getContainer().getJClass();
               Iterable $this$map$iv = (Iterable)methods;
               var13 = var35;
               $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               int $i$f$mapTo = false;
               Iterator var32 = $this$map$iv.iterator();

               while(var32.hasNext()) {
                  Object item$iv$iv = var32.next();
                  Method it = (Method)item$iv$iv;
                  int var12 = false;
                  destination$iv$iv.add(it.getName());
               }

               var10001 = (List)destination$iv$iv;
               AnnotationConstructorCaller.Origin var23 = AnnotationConstructorCaller.Origin.JAVA;
               AnnotationConstructorCaller.CallMode var24 = AnnotationConstructorCaller.CallMode.POSITIONAL_CALL;
               List var25 = var10001;
               return (Caller)(new AnnotationConstructorCaller(var13, var25, var24, var23, methods));
            }

            Constructor var39 = ((JvmFunctionSignature.JavaConstructor)jvmSignature).getConstructor();
            Intrinsics.checkNotNull(var39, "null cannot be cast to non-null type java.lang.reflect.Member");
            var10000 = (Member)var39;
         }
      }

      Member member = var10000;
      Caller var40;
      if (member instanceof Constructor) {
         var40 = (Caller)this$0.createConstructorCaller((Constructor)member, this$0.getDescriptor(), false);
      } else {
         if (!(member instanceof Method)) {
            throw new KotlinReflectionInternalError("Could not compute caller for function: " + this$0.getDescriptor() + " (member = " + member + ')');
         }

         var40 = !Modifier.isStatic(((Method)member).getModifiers()) ? (Caller)this$0.createInstanceMethodCaller((Method)member) : (this$0.getDescriptor().getAnnotations().findAnnotation(UtilKt.getJVM_STATIC()) != null ? (Caller)this$0.createJvmStaticInObjectCaller((Method)member) : this$0.createStaticMethodCaller((Method)member, false));
      }

      return ValueClassAwareCallerKt.createValueClassAwareCallerIfNeeded$default(var40, (CallableMemberDescriptor)this$0.getDescriptor(), false, 2, (Object)null);
   }

   private static final Caller defaultCaller_delegate$lambda$10(KFunctionImpl this$0) {
      JvmFunctionSignature jvmSignature = RuntimeTypeMapper.INSTANCE.mapSignature(this$0.getDescriptor());
      boolean $i$f$map;
      boolean $i$f$mapTo;
      boolean $i$f$mapTo;
      DeclarationDescriptor var10000;
      Member var40;
      if (jvmSignature instanceof JvmFunctionSignature.KotlinFunction) {
         $i$f$map = false;
         FunctionDescriptor it = this$0.getDescriptor();
         $i$f$mapTo = false;
         var10000 = it.getContainingDeclaration();
         Intrinsics.checkNotNullExpressionValue(var10000, "getContainingDeclaration(...)");
         if (InlineClassesUtilsKt.isMultiFieldValueClass(var10000) && it instanceof ConstructorDescriptor && ((ConstructorDescriptor)it).isPrimary()) {
            throw new KotlinReflectionInternalError(this$0.getDescriptor().getContainingDeclaration() + " cannot have default arguments");
         }

         FunctionDescriptor var38 = this$0.getFunctionWithDefaultParametersForValueClassOverride(this$0.getDescriptor());
         if (var38 != null) {
            FunctionDescriptor defaultImplsFunction = var38;
            $i$f$mapTo = false;
            JvmFunctionSignature var39 = RuntimeTypeMapper.INSTANCE.mapSignature(defaultImplsFunction);
            Intrinsics.checkNotNull(var39, "null cannot be cast to non-null type kotlin.reflect.jvm.internal.JvmFunctionSignature.KotlinFunction");
            JvmFunctionSignature.KotlinFunction replacingJvmSignature = (JvmFunctionSignature.KotlinFunction)var39;
            var40 = (Member)this$0.getContainer().findDefaultMethod(replacingJvmSignature.getMethodName(), replacingJvmSignature.getMethodDesc(), true);
         } else {
            KDeclarationContainerImpl var41 = this$0.getContainer();
            String var10001 = ((JvmFunctionSignature.KotlinFunction)jvmSignature).getMethodName();
            String var10002 = ((JvmFunctionSignature.KotlinFunction)jvmSignature).getMethodDesc();
            Member var10003 = this$0.getCaller().getMember();
            Intrinsics.checkNotNull(var10003);
            var40 = (Member)var41.findDefaultMethod(var10001, var10002, !Modifier.isStatic(var10003.getModifiers()));
         }
      } else {
         Class var13;
         List var42;
         Class var43;
         if (jvmSignature instanceof JvmFunctionSignature.KotlinConstructor) {
            if (this$0.isAnnotationConstructor()) {
               var43 = this$0.getContainer().getJClass();
               Iterable $this$map$iv = (Iterable)this$0.getParameters();
               var13 = var43;
               int $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               $i$f$mapTo = false;
               Iterator var33 = $this$map$iv.iterator();

               while(var33.hasNext()) {
                  Object item$iv$iv = var33.next();
                  KParameter it = (KParameter)item$iv$iv;
                  int var11 = false;
                  String var44 = it.getName();
                  Intrinsics.checkNotNull(var44);
                  destination$iv$iv.add(var44);
               }

               var42 = (List)destination$iv$iv;
               Object var15 = null;
               byte var16 = 16;
               Object var17 = null;
               AnnotationConstructorCaller.Origin var18 = AnnotationConstructorCaller.Origin.KOTLIN;
               AnnotationConstructorCaller.CallMode var19 = AnnotationConstructorCaller.CallMode.CALL_BY_NAME;
               List var20 = var42;
               return (Caller)(new AnnotationConstructorCaller(var13, var20, var19, var18, (List)var17, var16, (DefaultConstructorMarker)var15));
            }

            var40 = (Member)this$0.getContainer().findDefaultConstructor(((JvmFunctionSignature.KotlinConstructor)jvmSignature).getConstructorDesc());
         } else {
            if (jvmSignature instanceof JvmFunctionSignature.FakeJavaAnnotationConstructor) {
               List methods = ((JvmFunctionSignature.FakeJavaAnnotationConstructor)jvmSignature).getMethods();
               var43 = this$0.getContainer().getJClass();
               Iterable $this$map$iv = (Iterable)methods;
               var13 = var43;
               $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               $i$f$mapTo = false;
               Iterator var35 = $this$map$iv.iterator();

               while(var35.hasNext()) {
                  Object item$iv$iv = var35.next();
                  Method it = (Method)item$iv$iv;
                  int var12 = false;
                  destination$iv$iv.add(it.getName());
               }

               var42 = (List)destination$iv$iv;
               AnnotationConstructorCaller.Origin var23 = AnnotationConstructorCaller.Origin.JAVA;
               AnnotationConstructorCaller.CallMode var24 = AnnotationConstructorCaller.CallMode.CALL_BY_NAME;
               List var25 = var42;
               return (Caller)(new AnnotationConstructorCaller(var13, var25, var24, var23, methods));
            }

            var40 = null;
         }
      }

      Member member = var40;
      Caller var45;
      if (member instanceof Constructor) {
         var45 = (Caller)this$0.createConstructorCaller((Constructor)member, this$0.getDescriptor(), true);
      } else if (member instanceof Method) {
         label71: {
            if (this$0.getDescriptor().getAnnotations().findAnnotation(UtilKt.getJVM_STATIC()) != null) {
               var10000 = this$0.getDescriptor().getContainingDeclaration();
               Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor");
               if (!((ClassDescriptor)var10000).isCompanionObject()) {
                  var45 = (Caller)this$0.createJvmStaticInObjectCaller((Method)member);
                  break label71;
               }
            }

            var45 = this$0.createStaticMethodCaller((Method)member, this$0.getCaller().isBoundInstanceCallWithValueClasses());
         }
      } else {
         var45 = null;
      }

      Caller var27 = var45;
      return var27 != null ? ValueClassAwareCallerKt.createValueClassAwareCallerIfNeeded(var27, (CallableMemberDescriptor)this$0.getDescriptor(), true) : null;
   }

   static {
      KProperty[] var0 = new KProperty[]{Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KFunctionImpl.class, "descriptor", "getDescriptor()Lorg/jetbrains/kotlin/descriptors/FunctionDescriptor;", 0)))};
      $$delegatedProperties = var0;
   }

   // $FF: synthetic method
   static FunctionDescriptor accessor$KFunctionImpl$lambda0(KFunctionImpl var0, String var1) {
      return descriptor_delegate$lambda$0(var0, var1);
   }

   // $FF: synthetic method
   static Caller accessor$KFunctionImpl$lambda1(KFunctionImpl var0) {
      return caller_delegate$lambda$4(var0);
   }

   // $FF: synthetic method
   static Caller accessor$KFunctionImpl$lambda2(KFunctionImpl var0) {
      return defaultCaller_delegate$lambda$10(var0);
   }
}
