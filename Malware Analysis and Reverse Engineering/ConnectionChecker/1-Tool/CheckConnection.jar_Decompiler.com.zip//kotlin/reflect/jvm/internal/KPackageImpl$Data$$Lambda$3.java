package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KPackageImpl$Data$$Lambda$3 implements Function0 {
   private final KPackageImpl.Data arg$0;

   public KPackageImpl$Data$$Lambda$3(KPackageImpl.Data var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KPackageImpl.Data.accessor$KPackageImpl$Data$lambda3(this.arg$0);
   }
}
