package kotlin.reflect.jvm.internal.calls;

import java.util.Map.Entry;
import kotlin.jvm.functions.Function1;

class AnnotationConstructorCallerKt$$Lambda$3 implements Function1 {
   public static final AnnotationConstructorCallerKt$$Lambda$3 INSTANCE = new AnnotationConstructorCallerKt$$Lambda$3();

   public AnnotationConstructorCallerKt$$Lambda$3() {
   }

   public Object invoke(Object var1) {
      return AnnotationConstructorCallerKt.accessor$AnnotationConstructorCallerKt$lambda3((Entry)var1);
   }
}
