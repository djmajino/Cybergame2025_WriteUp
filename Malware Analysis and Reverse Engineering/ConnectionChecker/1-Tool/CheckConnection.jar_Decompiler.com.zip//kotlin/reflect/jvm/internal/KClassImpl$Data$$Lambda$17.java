package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KClassImpl$Data$$Lambda$17 implements Function0 {
   private final KClassImpl.Data arg$0;

   public KClassImpl$Data$$Lambda$17(KClassImpl.Data var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KClassImpl.Data.accessor$KClassImpl$Data$lambda17(this.arg$0);
   }
}
