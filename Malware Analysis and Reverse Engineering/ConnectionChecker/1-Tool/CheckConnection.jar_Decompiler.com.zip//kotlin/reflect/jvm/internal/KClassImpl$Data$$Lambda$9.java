package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KClassImpl$Data$$Lambda$9 implements Function0 {
   private final KClassImpl.Data arg$0;

   public KClassImpl$Data$$Lambda$9(KClassImpl.Data var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KClassImpl.Data.accessor$KClassImpl$Data$lambda9(this.arg$0);
   }
}
