package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function1;

class CachesKt$$Lambda$4 implements Function1 {
   public static final CachesKt$$Lambda$4 INSTANCE = new CachesKt$$Lambda$4();

   public CachesKt$$Lambda$4() {
   }

   public Object invoke(Object var1) {
      return CachesKt.accessor$CachesKt$lambda4((Class)var1);
   }
}
