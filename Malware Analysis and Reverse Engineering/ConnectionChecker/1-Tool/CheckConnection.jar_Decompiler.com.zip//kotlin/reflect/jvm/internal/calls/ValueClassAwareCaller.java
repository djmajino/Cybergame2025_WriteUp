package kotlin.reflect.jvm.internal.calls;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;
import kotlin.reflect.jvm.internal.KDeclarationContainerImpl;
import kotlin.reflect.jvm.internal.UtilKt;
import kotlin.reflect.jvm.internal.impl.builtins.KotlinBuiltIns;
import kotlin.reflect.jvm.internal.impl.descriptors.CallableDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.CallableMemberDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassifierDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ConstructorDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ReceiverParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ValueParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.runtime.structure.ReflectClassUtilKt;
import kotlin.reflect.jvm.internal.impl.resolve.InlineClassesUtilsKt;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;
import kotlin.reflect.jvm.internal.impl.types.TypeSubstitutionKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\b\u0000\u0018\u0000*\f\b\u0000\u0010\u0001 \u0001*\u0004\u0018\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003:\u0002()B%\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\u000e\u0010 \u001a\u00020\u001e2\u0006\u0010!\u001a\u00020\"J\u001b\u0010$\u001a\u0004\u0018\u00010%2\n\u0010&\u001a\u0006\u0012\u0002\b\u00030\u001dH\u0016¢\u0006\u0002\u0010'R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\u00028\u0000X\u0096\u0004¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u0010\u001a\u00020\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00110\u00158VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\u00020\b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u0019R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u001fR\u000e\u0010#\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006*"},
   d2 = {"Lkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller;", "M", "Ljava/lang/reflect/Member;", "Lkotlin/reflect/jvm/internal/calls/Caller;", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/CallableMemberDescriptor;", "oldCaller", "isDefault", "", "<init>", "(Lorg/jetbrains/kotlin/descriptors/CallableMemberDescriptor;Lkotlin/reflect/jvm/internal/calls/Caller;Z)V", "caller", "member", "getMember", "()Ljava/lang/reflect/Member;", "Ljava/lang/reflect/Member;", "returnType", "Ljava/lang/reflect/Type;", "getReturnType", "()Ljava/lang/reflect/Type;", "parameterTypes", "", "getParameterTypes", "()Ljava/util/List;", "isBoundInstanceCallWithValueClasses", "()Z", "data", "Lkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller$BoxUnboxData;", "slices", "", "Lkotlin/ranges/IntRange;", "[Lkotlin/ranges/IntRange;", "getRealSlicesOfParameters", "index", "", "hasMfvcParameters", "call", "", "args", "([Ljava/lang/Object;)Ljava/lang/Object;", "BoxUnboxData", "MultiFieldValueClassPrimaryConstructorCaller", "kotlin-reflection"}
)
@SourceDebugExtension({"SMAP\nValueClassAwareCaller.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ValueClassAwareCaller.kt\nkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,392:1\n1761#2,3:393\n1563#2:396\n1634#2,3:397\n1761#2,3:409\n1634#2,3:412\n37#3:400\n36#3,3:401\n37#3:405\n36#3,3:406\n37#3:415\n36#3,3:416\n1#4:404\n*S KotlinDebug\n*F\n+ 1 ValueClassAwareCaller.kt\nkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller\n*L\n45#1:393,3\n48#1:396\n48#1:397,3\n166#1:409,3\n184#1:412,3\n48#1:400\n48#1:401,3\n155#1:405\n155#1:406,3\n192#1:415\n192#1:416,3\n*E\n"})
public final class ValueClassAwareCaller<M extends Member> implements Caller<M> {
   private final boolean isDefault;
   @NotNull
   private final Caller<M> caller;
   private final M member;
   @NotNull
   private final ValueClassAwareCaller.BoxUnboxData data;
   @NotNull
   private final IntRange[] slices;
   private final boolean hasMfvcParameters;

   public ValueClassAwareCaller(@NotNull CallableMemberDescriptor descriptor, @NotNull Caller<? extends M> oldCaller, boolean isDefault) {
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      Intrinsics.checkNotNullParameter(oldCaller, "oldCaller");
      super();
      this.isDefault = isDefault;
      ValueClassAwareCaller var10000 = this;
      boolean $i$f$any;
      boolean var24;
      List $this$slices_u24lambda_u246;
      boolean var56;
      Caller var59;
      if (oldCaller instanceof CallerImpl.Method.BoundStatic) {
         label262: {
            ReceiverParameterDescriptor var10001 = descriptor.getExtensionReceiverParameter();
            if (var10001 == null) {
               var10001 = descriptor.getDispatchReceiverParameter();
            }

            KotlinType receiverType = var10001 != null ? var10001.getType() : null;
            if (receiverType != null && InlineClassesUtilsKt.needsMfvcFlattening(receiverType)) {
               label243: {
                  List var58;
                  if (this.isDefault) {
                     var58 = descriptor.getValueParameters();
                     Intrinsics.checkNotNullExpressionValue(var58, "getValueParameters(...)");
                     Iterable $this$any$iv = (Iterable)var58;
                     $i$f$any = false;
                     if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                        var56 = false;
                     } else {
                        Iterator var7 = $this$any$iv.iterator();

                        while(true) {
                           if (!var7.hasNext()) {
                              var56 = false;
                              break;
                           }

                           Object element$iv = var7.next();
                           ValueParameterDescriptor it = (ValueParameterDescriptor)element$iv;
                           int var10 = false;
                           if (it.declaresDefaultValue()) {
                              var56 = true;
                              break;
                           }
                        }
                     }

                     var24 = var56;
                     var10000 = this;
                     if (!var24) {
                        break label243;
                     }
                  }

                  var58 = ValueClassAwareCallerKt.getMfvcUnboxMethods(TypeSubstitutionKt.asSimpleType(receiverType));
                  Intrinsics.checkNotNull(var58);
                  $this$slices_u24lambda_u246 = var58;
                  Iterable $this$map$iv = (Iterable)$this$slices_u24lambda_u246;
                  ValueClassAwareCaller var23 = var10000;
                  int $i$f$toTypedArray = false;
                  Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
                  int $i$f$mapTo = false;
                  Iterator var12 = $this$map$iv.iterator();

                  while(var12.hasNext()) {
                     Object item$iv$iv = var12.next();
                     Method it = (Method)item$iv$iv;
                     int var15 = false;
                     destination$iv$iv.add(it.invoke(((CallerImpl.Method.BoundStatic)oldCaller).getBoundReceiver$kotlin_reflection()));
                  }

                  var58 = (List)destination$iv$iv;
                  var10000 = var23;
                  Collection $this$toTypedArray$iv = (Collection)var58;
                  $i$f$toTypedArray = false;
                  Object[] boundReceiverComponents = $this$toTypedArray$iv.toArray(new Object[0]);
                  var59 = (Caller)(new CallerImpl.Method.BoundStaticMultiFieldValueClass((Method)((CallerImpl.Method)oldCaller).getMember(), boundReceiverComponents));
                  break label262;
               }
            }

            var59 = oldCaller;
         }
      } else {
         var59 = oldCaller;
      }

      ValueClassAwareCaller $this$data_u24lambda_u245;
      boolean var41;
      Method var63;
      label194: {
         var10000.caller = var59;
         this.member = this.caller.getMember();
         $this$data_u24lambda_u245 = (ValueClassAwareCaller)this;
         $i$f$any = false;
         KotlinType var60 = descriptor.getReturnType();
         Intrinsics.checkNotNull(var60);
         KotlinType returnType = var60;
         if (descriptor instanceof FunctionDescriptor && ((FunctionDescriptor)descriptor).isSuspend()) {
            var60 = InlineClassesUtilsKt.substitutedUnderlyingType(returnType);
            if (var60 != null) {
               KotlinType it = var60;
               var41 = false;
               var56 = KotlinBuiltIns.isPrimitiveType(it);
            } else {
               var56 = false;
            }

            if (var56) {
               var63 = null;
               break label194;
            }
         }

         Class var62 = ValueClassAwareCallerKt.access$toInlineClass(returnType);
         var63 = var62 != null ? ValueClassAwareCallerKt.access$getBoxMethod(var62, descriptor) : null;
      }

      Method box = var63;
      int length;
      ValueClassAwareCaller.BoxUnboxData var64;
      List var67;
      if (InlineClassesUtilsKt.isGetterOfUnderlyingPropertyOfValueClass((CallableDescriptor)descriptor)) {
         var64 = new ValueClassAwareCaller.BoxUnboxData(IntRange.Companion.getEMPTY(), new List[0], box);
      } else {
         int var65;
         if ($this$data_u24lambda_u245.caller instanceof CallerImpl.Method.BoundStatic && !((CallerImpl.Method.BoundStatic)$this$data_u24lambda_u245.caller).isCallByToValueClassMangledMethod$kotlin_reflection()) {
            var65 = -1;
         } else if ($this$data_u24lambda_u245.caller instanceof CallerImpl.Method.BoundStaticMultiFieldValueClass) {
            var65 = -1;
         } else if (descriptor instanceof ConstructorDescriptor) {
            var65 = $this$data_u24lambda_u245.caller instanceof BoundCaller ? -1 : 0;
         } else if (descriptor.getDispatchReceiverParameter() != null && !($this$data_u24lambda_u245.caller instanceof BoundCaller)) {
            DeclarationDescriptor var66 = descriptor.getContainingDeclaration();
            Intrinsics.checkNotNullExpressionValue(var66, "getContainingDeclaration(...)");
            var65 = InlineClassesUtilsKt.isValueClass(var66) ? 0 : 1;
         } else {
            var65 = 0;
         }

         int shift = var65;
         length = $this$data_u24lambda_u245.caller instanceof CallerImpl.Method.BoundStaticMultiFieldValueClass ? -((CallerImpl.Method.BoundStaticMultiFieldValueClass)$this$data_u24lambda_u245.caller).getReceiverComponentsCount() : shift;
         List kotlinParameterTypes = ValueClassAwareCallerKt.access$makeKotlinParameterTypes(descriptor, $this$data_u24lambda_u245.caller.getMember(), ValueClassAwareCaller$$Lambda$0.INSTANCE);
         Iterable var51 = (Iterable)kotlinParameterTypes;
         int expectedArgsSize = 0;

         int var20;
         for(Iterator var54 = var51.iterator(); var54.hasNext(); expectedArgsSize += var20) {
            Object var16 = var54.next();
            KotlinType it = (KotlinType)var16;
            int var19 = false;
            var67 = ValueClassAwareCallerKt.getMfvcUnboxMethods(TypeSubstitutionKt.asSimpleType(it));
            var20 = var67 != null ? var67.size() : 1;
         }

         int extraArgumentsTail = ($this$data_u24lambda_u245.isDefault ? (expectedArgsSize + 32 - 1) / 32 + 1 : 0) + (descriptor instanceof FunctionDescriptor && ((FunctionDescriptor)descriptor).isSuspend() ? 1 : 0);
         expectedArgsSize = expectedArgsSize + length + extraArgumentsTail;
         ValueClassAwareCallerKt.access$checkParametersSize((Caller)$this$data_u24lambda_u245, expectedArgsSize, descriptor, $this$data_u24lambda_u245.isDefault);
         IntRange argumentRange = RangesKt.until(Math.max(shift, 0), kotlinParameterTypes.size() + shift);
         int var57 = 0;

         List[] var61;
         for(var61 = new List[expectedArgsSize]; var57 < expectedArgsSize; ++var57) {
            int var22 = argumentRange.getFirst();
            var61[var57] = (var57 <= argumentRange.getLast() ? var22 <= var57 : false) ? ValueClassAwareCallerKt.access$getValueClassUnboxMethods(TypeSubstitutionKt.asSimpleType((KotlinType)kotlinParameterTypes.get(var57 - shift)), descriptor) : null;
         }

         var64 = new ValueClassAwareCaller.BoxUnboxData(argumentRange, var61, box);
      }

      this.data = var64;
      List var25 = CollectionsKt.createListBuilder();
      $this$slices_u24lambda_u246 = var25;
      $i$f$any = false;
      Caller var37 = this.caller;
      int currentOffset = var37 instanceof CallerImpl.Method.BoundStaticMultiFieldValueClass ? ((CallerImpl.Method.BoundStaticMultiFieldValueClass)this.caller).getBoundReceiverComponents$kotlin_reflection().length : (var37 instanceof CallerImpl.Method.BoundStatic ? 1 : 0);
      if (currentOffset > 0) {
         var25.add(RangesKt.until(0, currentOffset));
      }

      List[] var38 = this.data.getUnboxParameters();
      int var44 = 0;

      for(int var47 = var38.length; var44 < var47; ++var44) {
         List parameterUnboxMethods = var38[var44];
         length = parameterUnboxMethods != null ? parameterUnboxMethods.size() : 1;
         $this$slices_u24lambda_u246.add(RangesKt.until(currentOffset, currentOffset + length));
         currentOffset += length;
      }

      Collection $this$toTypedArray$iv = (Collection)CollectionsKt.build(var25);
      int $i$f$any = false;
      this.slices = (IntRange[])$this$toTypedArray$iv.toArray(new IntRange[0]);
      Iterable $this$any$iv = (Iterable)this.data.getArgumentRange();
      $i$f$any = false;
      if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
         var56 = false;
      } else {
         label274: {
            Iterator var33 = $this$any$iv.iterator();

            while(var33.hasNext()) {
               int element$iv = ((IntIterator)var33).nextInt();
               var41 = false;
               var67 = this.data.getUnboxParameters()[element$iv];
               if (var67 == null ? false : var67.size() > 1) {
                  var56 = true;
                  break label274;
               }
            }

            var56 = false;
         }
      }

      var24 = var56;
      this.hasMfvcParameters = var24;
   }

   public M getMember() {
      return this.member;
   }

   @NotNull
   public Type getReturnType() {
      return this.caller.getReturnType();
   }

   @NotNull
   public List<Type> getParameterTypes() {
      return this.caller.getParameterTypes();
   }

   public boolean isBoundInstanceCallWithValueClasses() {
      return this.caller instanceof CallerImpl.Method.BoundInstance;
   }

   @NotNull
   public final IntRange getRealSlicesOfParameters(int index) {
      IntRange var10000;
      if (0 <= index ? index < this.slices.length : false) {
         var10000 = this.slices[index];
      } else if (this.slices.length == 0) {
         var10000 = new IntRange(index, index);
      } else {
         int start = index - this.slices.length + ((IntRange)ArraysKt.last(this.slices)).getLast() + 1;
         var10000 = new IntRange(start, start);
      }

      return var10000;
   }

   @Nullable
   public Object call(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      IntRange range = this.data.getArgumentRange();
      List[] unbox = this.data.getUnboxParameters();
      Method box = this.data.getBox();
      Object[] var10000;
      Object[] var25;
      Object var29;
      if (range.isEmpty()) {
         var10000 = args;
      } else {
         int index;
         if (this.hasMfvcParameters) {
            List var7 = CollectionsKt.createListBuilder(args.length);
            List $this$call_u24lambda_u249 = var7;
            int var9 = false;
            index = 0;

            int var11;
            for(var11 = range.getFirst(); index < var11; ++index) {
               $this$call_u24lambda_u249.add(args[index]);
            }

            index = range.getFirst();
            var11 = range.getLast();
            if (index <= var11) {
               while(true) {
                  List methods = unbox[index];
                  Object arg = args[index];
                  if (methods == null) {
                     $this$call_u24lambda_u249.add(arg);
                  } else {
                     Iterable $this$mapTo$iv = (Iterable)methods;
                     int $i$f$mapTo = false;

                     Collection var19;
                     Collection var28;
                     for(Iterator var16 = $this$mapTo$iv.iterator(); var16.hasNext(); var19.add(var29)) {
                        Object item$iv = var16.next();
                        var28 = (Collection)$this$call_u24lambda_u249;
                        Method it = (Method)item$iv;
                        var19 = var28;
                        int var20 = false;
                        if (arg != null) {
                           var29 = it.invoke(arg);
                        } else {
                           Class var30 = it.getReturnType();
                           Intrinsics.checkNotNullExpressionValue(var30, "getReturnType(...)");
                           var29 = UtilKt.defaultPrimitiveValue((Type)var30);
                        }
                     }

                     var28 = (Collection)$this$call_u24lambda_u249;
                  }

                  if (index == var11) {
                     break;
                  }

                  ++index;
               }
            }

            index = range.getLast() + 1;
            var11 = ArraysKt.getLastIndex(args);
            if (index <= var11) {
               while(true) {
                  $this$call_u24lambda_u249.add(args[index]);
                  if (index == var11) {
                     break;
                  }

                  ++index;
               }
            }

            Collection $this$toTypedArray$iv = (Collection)CollectionsKt.build(var7);
            int $i$f$toTypedArray = false;
            var10000 = $this$toTypedArray$iv.toArray(new Object[0]);
         } else {
            int var21 = 0;
            int var24 = args.length;

            for(var25 = new Object[var24]; var21 < var24; ++var21) {
               index = range.getFirst();
               Object var10002;
               if (var21 <= range.getLast() ? index <= var21 : false) {
                  Method method = unbox[var21] != null ? (Method)CollectionsKt.single(unbox[var21]) : null;
                  Object arg = args[var21];
                  if (method == null) {
                     var10002 = arg;
                  } else if (arg != null) {
                     var10002 = method.invoke(arg);
                  } else {
                     Class var31 = method.getReturnType();
                     Intrinsics.checkNotNullExpressionValue(var31, "getReturnType(...)");
                     var10002 = UtilKt.defaultPrimitiveValue((Type)var31);
                  }
               } else {
                  var10002 = args[var21];
               }

               var25[var21] = var10002;
            }

            var10000 = var25;
         }
      }

      Object[] unboxedArguments = var10000;
      Object result = this.caller.call(unboxedArguments);
      if (result == IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
         return result;
      } else {
         if (box != null) {
            var25 = new Object[]{result};
            var29 = box.invoke((Object)null, var25);
            if (var29 != null) {
               return var29;
            }
         }

         var29 = result;
         return var29;
      }
   }

   private static final boolean data$lambda$5$lambda$3(ClassDescriptor $this$makeKotlinParameterTypes) {
      Intrinsics.checkNotNullParameter($this$makeKotlinParameterTypes, "$this$makeKotlinParameterTypes");
      return InlineClassesUtilsKt.isValueClass((DeclarationDescriptor)$this$makeKotlinParameterTypes);
   }

   // $FF: synthetic method
   static boolean accessor$ValueClassAwareCaller$lambda0(ClassDescriptor var0) {
      return data$lambda$5$lambda$3(var0);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000b\b\u0002\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0014\u0010\u0004\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u00060\u0005\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR!\u0010\u0004\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u00060\u0005¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\r\u0010\u000eR\u0013\u0010\b\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u0012"},
      d2 = {"Lkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller$BoxUnboxData;", "", "argumentRange", "Lkotlin/ranges/IntRange;", "unboxParameters", "", "", "Ljava/lang/reflect/Method;", "box", "<init>", "(Lkotlin/ranges/IntRange;[Ljava/util/List;Ljava/lang/reflect/Method;)V", "getArgumentRange", "()Lkotlin/ranges/IntRange;", "getUnboxParameters", "()[Ljava/util/List;", "[Ljava/util/List;", "getBox", "()Ljava/lang/reflect/Method;", "kotlin-reflection"}
   )
   private static final class BoxUnboxData {
      @NotNull
      private final IntRange argumentRange;
      @NotNull
      private final List<Method>[] unboxParameters;
      @Nullable
      private final Method box;

      public BoxUnboxData(@NotNull IntRange argumentRange, @NotNull List<Method>[] unboxParameters, @Nullable Method box) {
         Intrinsics.checkNotNullParameter(argumentRange, "argumentRange");
         Intrinsics.checkNotNullParameter(unboxParameters, "unboxParameters");
         super();
         this.argumentRange = argumentRange;
         this.unboxParameters = unboxParameters;
         this.box = box;
      }

      @NotNull
      public final IntRange getArgumentRange() {
         return this.argumentRange;
      }

      @NotNull
      public final List<Method>[] getUnboxParameters() {
         return this.unboxParameters;
      }

      @Nullable
      public final Method getBox() {
         return this.box;
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\u0018\u00002\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001B-\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\u0004\b\f\u0010\rJ\u001b\u0010\u001f\u001a\u0004\u0018\u00010 2\n\u0010!\u001a\u0006\u0012\u0002\b\u00030\"H\u0016¢\u0006\u0002\u0010#R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0011\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\n0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0012\u001a\u0004\u0018\u00010\u00028VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0015\u001a\u00020\u00168VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0018R!\u0010\u0019\u001a\u0012\u0012\u000e\u0012\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u001a0\n0\n¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u001a\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00160\nX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001c¨\u0006$"},
      d2 = {"Lkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller$MultiFieldValueClassPrimaryConstructorCaller;", "Lkotlin/reflect/jvm/internal/calls/Caller;", "", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/FunctionDescriptor;", "container", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "constructorDesc", "", "originalParameters", "", "Lkotlin/reflect/jvm/internal/impl/descriptors/ParameterDescriptor;", "<init>", "(Lorg/jetbrains/kotlin/descriptors/FunctionDescriptor;Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Ljava/lang/String;Ljava/util/List;)V", "constructorImpl", "Ljava/lang/reflect/Method;", "boxMethod", "parameterUnboxMethods", "member", "getMember", "()Ljava/lang/Void;", "returnType", "Ljava/lang/reflect/Type;", "getReturnType", "()Ljava/lang/reflect/Type;", "originalParametersGroups", "Ljava/lang/Class;", "getOriginalParametersGroups", "()Ljava/util/List;", "parameterTypes", "getParameterTypes", "call", "", "args", "", "([Ljava/lang/Object;)Ljava/lang/Object;", "kotlin-reflection"}
   )
   @SourceDebugExtension({"SMAP\nValueClassAwareCaller.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ValueClassAwareCaller.kt\nkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller$MultiFieldValueClassPrimaryConstructorCaller\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,392:1\n1563#2:393\n1634#2,3:394\n1573#2:397\n1604#2,3:398\n1563#2:401\n1634#2,3:402\n1607#2:405\n1374#2:406\n1460#2,2:407\n1563#2:409\n1634#2,3:410\n1462#2,3:413\n37#3:416\n36#3,3:417\n*S KotlinDebug\n*F\n+ 1 ValueClassAwareCaller.kt\nkotlin/reflect/jvm/internal/calls/ValueClassAwareCaller$MultiFieldValueClassPrimaryConstructorCaller\n*L\n224#1:393\n224#1:394,3\n232#1:397\n232#1:398,3\n234#1:401\n234#1:402,3\n232#1:405\n241#1:406\n241#1:407,2\n241#1:409\n241#1:410,3\n241#1:413,3\n241#1:416\n241#1:417,3\n*E\n"})
   public static final class MultiFieldValueClassPrimaryConstructorCaller implements Caller {
      @NotNull
      private final Method constructorImpl;
      @NotNull
      private final Method boxMethod;
      @NotNull
      private final List<List<Method>> parameterUnboxMethods;
      @NotNull
      private final List<List<Class<?>>> originalParametersGroups;
      @NotNull
      private final List<Type> parameterTypes;

      public MultiFieldValueClassPrimaryConstructorCaller(@NotNull FunctionDescriptor descriptor, @NotNull KDeclarationContainerImpl container, @NotNull String constructorDesc, @NotNull List<? extends ParameterDescriptor> originalParameters) {
         Intrinsics.checkNotNullParameter(descriptor, "descriptor");
         Intrinsics.checkNotNullParameter(container, "container");
         Intrinsics.checkNotNullParameter(constructorDesc, "constructorDesc");
         Intrinsics.checkNotNullParameter(originalParameters, "originalParameters");
         super();
         Method var10001 = container.findMethodBySignature("constructor-impl", constructorDesc);
         Intrinsics.checkNotNull(var10001);
         this.constructorImpl = var10001;
         var10001 = container.findMethodBySignature("box-impl", StringsKt.removeSuffix(constructorDesc, (CharSequence)"V") + ReflectClassUtilKt.getDesc(container.getJClass()));
         Intrinsics.checkNotNull(var10001);
         this.boxMethod = var10001;
         Iterable $this$mapIndexed$iv = (Iterable)originalParameters;
         int $i$f$mapIndexed = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$mapIndexed$iv, 10)));
         int $i$f$mapIndexedTo = false;
         Iterator var10 = $this$mapIndexed$iv.iterator();

         while(var10.hasNext()) {
            Object item$iv$iv = var10.next();
            ParameterDescriptor parameter = (ParameterDescriptor)item$iv$iv;
            int var13 = false;
            KotlinType var10000 = parameter.getType();
            Intrinsics.checkNotNullExpressionValue(var10000, "getType(...)");
            destination$iv$iv.add(ValueClassAwareCallerKt.access$getValueClassUnboxMethods(TypeSubstitutionKt.asSimpleType(var10000), (CallableMemberDescriptor)descriptor));
         }

         this.parameterUnboxMethods = (List)destination$iv$iv;
         $this$mapIndexed$iv = (Iterable)originalParameters;
         $i$f$mapIndexed = false;
         destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$mapIndexed$iv, 10)));
         $i$f$mapIndexedTo = false;
         int index$iv$iv = 0;

         List var35;
         for(Iterator var31 = $this$mapIndexed$iv.iterator(); var31.hasNext(); destination$iv$iv.add(var35)) {
            Object item$iv$iv = var31.next();
            int var33 = index$iv$iv++;
            if (var33 < 0) {
               CollectionsKt.throwIndexOverflow();
            }

            ParameterDescriptor it = (ParameterDescriptor)item$iv$iv;
            int var16 = false;
            ClassifierDescriptor var34 = it.getType().getConstructor().getDeclarationDescriptor();
            Intrinsics.checkNotNull(var34, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor");
            ClassDescriptor classDescriptor = (ClassDescriptor)var34;
            var35 = (List)this.parameterUnboxMethods.get(var33);
            if (var35 == null) {
               Class var36 = UtilKt.toJavaClass(classDescriptor);
               Intrinsics.checkNotNull(var36);
               var35 = CollectionsKt.listOf(var36);
            } else {
               Iterable $this$map$iv = (Iterable)var35;
               int $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               int $i$f$mapTo = false;
               Iterator var23 = $this$map$iv.iterator();

               while(var23.hasNext()) {
                  Object item$iv$iv = var23.next();
                  Method it = (Method)item$iv$iv;
                  int var27 = false;
                  destination$iv$iv.add(it.getReturnType());
               }

               var35 = (List)destination$iv$iv;
            }
         }

         this.originalParametersGroups = (List)destination$iv$iv;
         this.parameterTypes = CollectionsKt.flatten((Iterable)this.originalParametersGroups);
      }

      @Nullable
      public Void getMember() {
         return null;
      }

      @NotNull
      public Type getReturnType() {
         Class var10000 = this.boxMethod.getReturnType();
         Intrinsics.checkNotNullExpressionValue(var10000, "getReturnType(...)");
         return (Type)var10000;
      }

      @NotNull
      public final List<List<Class<?>>> getOriginalParametersGroups() {
         return this.originalParametersGroups;
      }

      @NotNull
      public List<Type> getParameterTypes() {
         return this.parameterTypes;
      }

      @Nullable
      public Object call(@NotNull Object[] args) {
         Intrinsics.checkNotNullParameter(args, "args");
         Iterable $this$flatMap$iv = (Iterable)ArraysKt.zip(args, (Iterable)this.parameterUnboxMethods);
         int $i$f$toTypedArray = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$flatMapTo = false;
         Iterator var8 = $this$flatMap$iv.iterator();

         while(var8.hasNext()) {
            Object element$iv$iv = var8.next();
            Pair var10 = (Pair)element$iv$iv;
            int var11 = false;
            Object arg = var10.component1();
            List unboxMethods = (List)var10.component2();
            List var10000;
            if (unboxMethods == null) {
               var10000 = CollectionsKt.listOf(arg);
            } else {
               Iterable $this$map$iv = (Iterable)unboxMethods;
               int $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               int $i$f$mapTo = false;
               Iterator var19 = $this$map$iv.iterator();

               while(var19.hasNext()) {
                  Object item$iv$iv = var19.next();
                  Method it = (Method)item$iv$iv;
                  int var23 = false;
                  destination$iv$iv.add(it.invoke(arg));
               }

               var10000 = (List)destination$iv$iv;
            }

            Iterable list$iv$iv = (Iterable)var10000;
            CollectionsKt.addAll(destination$iv$iv, list$iv$iv);
         }

         Collection $this$toTypedArray$iv = (Collection)((List)destination$iv$iv);
         $i$f$toTypedArray = false;
         Object[] newArgs = $this$toTypedArray$iv.toArray(new Object[0]);
         this.constructorImpl.invoke((Object)null, Arrays.copyOf(newArgs, newArgs.length));
         return this.boxMethod.invoke((Object)null, Arrays.copyOf(newArgs, newArgs.length));
      }

      public boolean isBoundInstanceCallWithValueClasses() {
         return Caller.DefaultImpls.isBoundInstanceCallWithValueClasses(this);
      }
   }
}
