package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function1;

class CachesKt$$Lambda$2 implements Function1 {
   public static final CachesKt$$Lambda$2 INSTANCE = new CachesKt$$Lambda$2();

   public CachesKt$$Lambda$2() {
   }

   public Object invoke(Object var1) {
      return CachesKt.accessor$CachesKt$lambda2((Class)var1);
   }
}
