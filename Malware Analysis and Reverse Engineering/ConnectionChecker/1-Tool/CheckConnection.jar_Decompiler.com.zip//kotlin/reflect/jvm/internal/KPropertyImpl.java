package kotlin.reflect.jvm.internal;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.jvm.internal.CallableReference;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.KCallable;
import kotlin.reflect.KFunction;
import kotlin.reflect.KMutableProperty;
import kotlin.reflect.KProperty;
import kotlin.reflect.full.IllegalPropertyDelegateAccessException;
import kotlin.reflect.jvm.KCallablesJvm;
import kotlin.reflect.jvm.internal.calls.Caller;
import kotlin.reflect.jvm.internal.calls.ValueClassAwareCallerKt;
import kotlin.reflect.jvm.internal.impl.descriptors.CallableMemberDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertyAccessorDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertyDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertyGetterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertySetterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.Annotations;
import kotlin.reflect.jvm.internal.impl.descriptors.impl.PropertyGetterDescriptorImpl;
import kotlin.reflect.jvm.internal.impl.descriptors.impl.PropertySetterDescriptorImpl;
import kotlin.reflect.jvm.internal.impl.load.java.DescriptorsJvmAbiUtil;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.JvmProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmMemberSignature;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmProtoBufUtil;
import kotlin.reflect.jvm.internal.impl.resolve.DescriptorFactory;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0006\b \u0018\u0000 C*\u0006\b\u0000\u0010\u0001 \u00012\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003:\u0004@ABCB5\b\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\r\u0010\u000eB+\b\u0016\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\r\u0010\u0010B\u0019\b\u0016\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0011\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u0012J\n\u0010#\u001a\u0004\u0018\u00010$H\u0004J(\u0010%\u001a\u0004\u0018\u00010\f2\b\u0010&\u001a\u0004\u0018\u00010$2\b\u0010'\u001a\u0004\u0018\u00010\f2\b\u0010(\u001a\u0004\u0018\u00010\fH\u0004J\u0013\u0010;\u001a\u00020\u001b2\b\u0010<\u001a\u0004\u0018\u00010\fH\u0096\u0002J\b\u0010=\u001a\u00020>H\u0016J\b\u0010?\u001a\u00020\u0007H\u0016R\u0014\u0010\u0004\u001a\u00020\u0005X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0006\u001a\u00020\u0007X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0013\u0010\u000f\u001a\u0004\u0018\u00010\f8F¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001a\u001a\u00020\u001b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001cR\u0016\u0010\u001d\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001f0\u001eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0013\u0010 \u001a\u0004\u0018\u00010\u001f8F¢\u0006\u0006\u001a\u0004\b!\u0010\"R\u0018\u0010)\u001a\b\u0012\u0004\u0012\u00028\u00000*X¦\u0004¢\u0006\u0006\u001a\u0004\b+\u0010,R\u001c\u0010-\u001a\u0010\u0012\f\u0012\n /*\u0004\u0018\u00010\n0\n0.X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\u00020\n8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b0\u00101R\u0018\u00102\u001a\u0006\u0012\u0002\b\u0003038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b4\u00105R\u001a\u00106\u001a\b\u0012\u0002\b\u0003\u0018\u0001038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b7\u00105R\u0014\u00108\u001a\u00020\u001b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b8\u0010\u001cR\u0014\u00109\u001a\u00020\u001b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b9\u0010\u001cR\u0014\u0010:\u001a\u00020\u001b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b:\u0010\u001c¨\u0006D"},
   d2 = {"Lkotlin/reflect/jvm/internal/KPropertyImpl;", "V", "Lkotlin/reflect/jvm/internal/KCallableImpl;", "Lkotlin/reflect/KProperty;", "container", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "name", "", "signature", "descriptorInitialValue", "Lkotlin/reflect/jvm/internal/impl/descriptors/PropertyDescriptor;", "rawBoundReceiver", "", "<init>", "(Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Ljava/lang/String;Ljava/lang/String;Lorg/jetbrains/kotlin/descriptors/PropertyDescriptor;Ljava/lang/Object;)V", "boundReceiver", "(Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V", "descriptor", "(Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;Lorg/jetbrains/kotlin/descriptors/PropertyDescriptor;)V", "getContainer", "()Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "getName", "()Ljava/lang/String;", "getSignature", "getBoundReceiver", "()Ljava/lang/Object;", "isBound", "", "()Z", "_javaField", "Lkotlin/Lazy;", "Ljava/lang/reflect/Field;", "javaField", "getJavaField", "()Ljava/lang/reflect/Field;", "computeDelegateSource", "Ljava/lang/reflect/Member;", "getDelegateImpl", "fieldOrMethod", "receiver1", "receiver2", "getter", "Lkotlin/reflect/jvm/internal/KPropertyImpl$Getter;", "getGetter", "()Lkotlin/reflect/jvm/internal/KPropertyImpl$Getter;", "_descriptor", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "kotlin.jvm.PlatformType", "getDescriptor", "()Lorg/jetbrains/kotlin/descriptors/PropertyDescriptor;", "caller", "Lkotlin/reflect/jvm/internal/calls/Caller;", "getCaller", "()Lkotlin/reflect/jvm/internal/calls/Caller;", "defaultCaller", "getDefaultCaller", "isLateinit", "isConst", "isSuspend", "equals", "other", "hashCode", "", "toString", "Accessor", "Getter", "Setter", "Companion", "kotlin-reflection"}
)
@SourceDebugExtension({"SMAP\nKPropertyImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 KPropertyImpl.kt\nkotlin/reflect/jvm/internal/KPropertyImpl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,334:1\n1#2:335\n*E\n"})
public abstract class KPropertyImpl<V> extends KCallableImpl<V> implements KProperty<V> {
   @NotNull
   public static final KPropertyImpl.Companion Companion = new KPropertyImpl.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final KDeclarationContainerImpl container;
   @NotNull
   private final String name;
   @NotNull
   private final String signature;
   @Nullable
   private final Object rawBoundReceiver;
   @NotNull
   private final Lazy<Field> _javaField;
   @NotNull
   private final ReflectProperties.LazySoftVal<PropertyDescriptor> _descriptor;
   @NotNull
   private static final Object EXTENSION_PROPERTY_DELEGATE = new Object();

   private KPropertyImpl(KDeclarationContainerImpl container, String name, String signature, PropertyDescriptor descriptorInitialValue, Object rawBoundReceiver) {
      this.container = container;
      this.name = name;
      this.signature = signature;
      this.rawBoundReceiver = rawBoundReceiver;
      this._javaField = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KPropertyImpl$$Lambda$0(this));
      ReflectProperties.LazySoftVal var10001 = ReflectProperties.lazySoft(descriptorInitialValue, new KPropertyImpl$$Lambda$1(this));
      Intrinsics.checkNotNullExpressionValue(var10001, "lazySoft(...)");
      this._descriptor = var10001;
   }

   @NotNull
   public KDeclarationContainerImpl getContainer() {
      return this.container;
   }

   @NotNull
   public String getName() {
      return this.name;
   }

   @NotNull
   public final String getSignature() {
      return this.signature;
   }

   public KPropertyImpl(@NotNull KDeclarationContainerImpl container, @NotNull String name, @NotNull String signature, @Nullable Object boundReceiver) {
      Intrinsics.checkNotNullParameter(container, "container");
      Intrinsics.checkNotNullParameter(name, "name");
      Intrinsics.checkNotNullParameter(signature, "signature");
      this(container, name, signature, (PropertyDescriptor)null, boundReceiver);
   }

   public KPropertyImpl(@NotNull KDeclarationContainerImpl container, @NotNull PropertyDescriptor descriptor) {
      Intrinsics.checkNotNullParameter(container, "container");
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      String var10002 = descriptor.getName().asString();
      Intrinsics.checkNotNullExpressionValue(var10002, "asString(...)");
      this(container, var10002, RuntimeTypeMapper.INSTANCE.mapPropertySignature(descriptor).asString(), descriptor, CallableReference.NO_RECEIVER);
   }

   @Nullable
   public final Object getBoundReceiver() {
      return ValueClassAwareCallerKt.coerceToExpectedReceiverType(this.rawBoundReceiver, (CallableMemberDescriptor)this.getDescriptor());
   }

   public boolean isBound() {
      return this.rawBoundReceiver != CallableReference.NO_RECEIVER;
   }

   @Nullable
   public final Field getJavaField() {
      return (Field)this._javaField.getValue();
   }

   @Nullable
   protected final Member computeDelegateSource() {
      if (!this.getDescriptor().isDelegated()) {
         return null;
      } else {
         JvmPropertySignature jvmSignature = RuntimeTypeMapper.INSTANCE.mapPropertySignature(this.getDescriptor());
         if (jvmSignature instanceof JvmPropertySignature.KotlinProperty && ((JvmPropertySignature.KotlinProperty)jvmSignature).getSignature().hasDelegateMethod()) {
            JvmProtoBuf.JvmMethodSignature method = ((JvmPropertySignature.KotlinProperty)jvmSignature).getSignature().getDelegateMethod();
            if (method.hasName() && method.hasDesc()) {
               String name = ((JvmPropertySignature.KotlinProperty)jvmSignature).getNameResolver().getString(method.getName());
               String desc = ((JvmPropertySignature.KotlinProperty)jvmSignature).getNameResolver().getString(method.getDesc());
               return (Member)this.getContainer().findMethodBySignature(name, desc);
            } else {
               return null;
            }
         } else {
            return (Member)this.getJavaField();
         }
      }
   }

   @Nullable
   protected final Object getDelegateImpl(@Nullable Member fieldOrMethod, @Nullable Object receiver1, @Nullable Object receiver2) {
      try {
         if ((receiver1 == EXTENSION_PROPERTY_DELEGATE || receiver2 == EXTENSION_PROPERTY_DELEGATE) && this.getDescriptor().getExtensionReceiverParameter() == null) {
            throw new RuntimeException("" + '\'' + this + "' is not an extension property and thus getExtensionDelegate() is not going to work, use getDelegate() instead");
         } else {
            Object realReceiver2 = this.isBound() ? this.getBoundReceiver() : receiver1;
            int var7 = false;
            Object realReceiver1 = realReceiver2 != EXTENSION_PROPERTY_DELEGATE ? realReceiver2 : null;
            Object var6 = this.isBound() ? receiver1 : receiver2;
            int var8 = false;
            realReceiver2 = var6 != EXTENSION_PROPERTY_DELEGATE ? var6 : null;
            AccessibleObject var10000 = fieldOrMethod instanceof AccessibleObject ? (AccessibleObject)fieldOrMethod : null;
            if ((fieldOrMethod instanceof AccessibleObject ? (AccessibleObject)fieldOrMethod : null) != null) {
               var10000.setAccessible(KCallablesJvm.isAccessible((KCallable)this));
            }

            Object var11;
            if (fieldOrMethod == null) {
               var11 = null;
            } else if (fieldOrMethod instanceof Field) {
               var11 = ((Field)fieldOrMethod).get(realReceiver1);
            } else {
               if (!(fieldOrMethod instanceof Method)) {
                  throw new AssertionError("delegate field/method " + fieldOrMethod + " neither field nor method");
               }

               Object[] var10;
               Method var12;
               Class var13;
               Object var10004;
               switch(((Method)fieldOrMethod).getParameterTypes().length) {
               case 0:
                  var11 = ((Method)fieldOrMethod).invoke((Object)null);
                  break;
               case 1:
                  var12 = (Method)fieldOrMethod;
                  var10 = new Object[1];
                  var10004 = realReceiver1;
                  if (realReceiver1 == null) {
                     var13 = ((Method)fieldOrMethod).getParameterTypes()[0];
                     Intrinsics.checkNotNullExpressionValue(var13, "get(...)");
                     var10004 = UtilKt.defaultPrimitiveValue((Type)var13);
                  }

                  var10[0] = var10004;
                  var11 = var12.invoke((Object)null, var10);
                  break;
               case 2:
                  var12 = (Method)fieldOrMethod;
                  var10 = new Object[]{realReceiver1, null};
                  var10004 = realReceiver2;
                  if (realReceiver2 == null) {
                     var13 = ((Method)fieldOrMethod).getParameterTypes()[1];
                     Intrinsics.checkNotNullExpressionValue(var13, "get(...)");
                     var10004 = UtilKt.defaultPrimitiveValue((Type)var13);
                  }

                  var10[1] = var10004;
                  var11 = var12.invoke((Object)null, var10);
                  break;
               default:
                  throw new AssertionError("delegate method " + fieldOrMethod + " should take 0, 1, or 2 parameters");
               }
            }

            realReceiver1 = var11;
            return realReceiver1;
         }
      } catch (IllegalAccessException var9) {
         throw new IllegalPropertyDelegateAccessException(var9);
      }
   }

   @NotNull
   public abstract KPropertyImpl.Getter<V> getGetter();

   @NotNull
   public PropertyDescriptor getDescriptor() {
      Object var10000 = this._descriptor.invoke();
      Intrinsics.checkNotNullExpressionValue(var10000, "invoke(...)");
      return (PropertyDescriptor)var10000;
   }

   @NotNull
   public Caller<?> getCaller() {
      return this.getGetter().getCaller();
   }

   @Nullable
   public Caller<?> getDefaultCaller() {
      return this.getGetter().getDefaultCaller();
   }

   public boolean isLateinit() {
      return this.getDescriptor().isLateInit();
   }

   public boolean isConst() {
      return this.getDescriptor().isConst();
   }

   public boolean isSuspend() {
      return false;
   }

   public boolean equals(@Nullable Object other) {
      KPropertyImpl var10000 = UtilKt.asKPropertyImpl(other);
      if (var10000 == null) {
         return false;
      } else {
         KPropertyImpl that = var10000;
         return Intrinsics.areEqual((Object)this.getContainer(), (Object)that.getContainer()) && Intrinsics.areEqual((Object)this.getName(), (Object)that.getName()) && Intrinsics.areEqual((Object)this.signature, (Object)that.signature) && Intrinsics.areEqual(this.rawBoundReceiver, that.rawBoundReceiver);
      }
   }

   public int hashCode() {
      return (this.getContainer().hashCode() * 31 + this.getName().hashCode()) * 31 + this.signature.hashCode();
   }

   @NotNull
   public String toString() {
      return ReflectionObjectRenderer.INSTANCE.renderProperty(this.getDescriptor());
   }

   private static final Field _javaField$lambda$2(KPropertyImpl this$0) {
      JvmPropertySignature jvmSignature = RuntimeTypeMapper.INSTANCE.mapPropertySignature(this$0.getDescriptor());
      Field var11;
      if (jvmSignature instanceof JvmPropertySignature.KotlinProperty) {
         PropertyDescriptor descriptor = ((JvmPropertySignature.KotlinProperty)jvmSignature).getDescriptor();
         JvmMemberSignature.Field var10000 = JvmProtoBufUtil.getJvmFieldSignature$default(JvmProtoBufUtil.INSTANCE, ((JvmPropertySignature.KotlinProperty)jvmSignature).getProto(), ((JvmPropertySignature.KotlinProperty)jvmSignature).getNameResolver(), ((JvmPropertySignature.KotlinProperty)jvmSignature).getTypeTable(), false, 8, (Object)null);
         if (var10000 != null) {
            JvmMemberSignature.Field it = var10000;
            int var4 = false;
            Class var10;
            if (!DescriptorsJvmAbiUtil.isPropertyWithBackingFieldInOuterClass(descriptor) && !JvmProtoBufUtil.isMovedFromInterfaceCompanion(((JvmPropertySignature.KotlinProperty)jvmSignature).getProto())) {
               DeclarationDescriptor containingDeclaration = descriptor.getContainingDeclaration();
               int var6 = false;
               var10 = containingDeclaration instanceof ClassDescriptor ? UtilKt.toJavaClass((ClassDescriptor)containingDeclaration) : this$0.getContainer().getJClass();
            } else {
               var10 = this$0.getContainer().getJClass().getEnclosingClass();
            }

            Class owner = var10;

            Field var8;
            try {
               var8 = owner != null ? owner.getDeclaredField(it.getName()) : null;
            } catch (NoSuchFieldException var9) {
               var8 = null;
            }

            var11 = var8;
         } else {
            var11 = null;
         }
      } else if (jvmSignature instanceof JvmPropertySignature.JavaField) {
         var11 = ((JvmPropertySignature.JavaField)jvmSignature).getField();
      } else if (jvmSignature instanceof JvmPropertySignature.JavaMethodProperty) {
         var11 = null;
      } else {
         if (!(jvmSignature instanceof JvmPropertySignature.MappedKotlinProperty)) {
            throw new NoWhenBranchMatchedException();
         }

         var11 = null;
      }

      return var11;
   }

   private static final PropertyDescriptor _descriptor$lambda$5(KPropertyImpl this$0) {
      return this$0.getContainer().findPropertyDescriptor(this$0.getName(), this$0.signature);
   }

   // $FF: synthetic method
   static Field accessor$KPropertyImpl$lambda0(KPropertyImpl var0) {
      return _javaField$lambda$2(var0);
   }

   // $FF: synthetic method
   static PropertyDescriptor accessor$KPropertyImpl$lambda1(KPropertyImpl var0) {
      return _descriptor$lambda$5(var0);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0007\b&\u0018\u0000*\u0006\b\u0001\u0010\u0001 \u0001*\u0006\b\u0002\u0010\u0002 \u00012\b\u0012\u0004\u0012\u0002H\u00020\u00032\b\u0012\u0004\u0012\u0002H\u00010\u00042\b\u0012\u0004\u0012\u0002H\u00020\u0005B\u0007¢\u0006\u0004\b\u0006\u0010\u0007R\u0018\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00010\tX¦\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0012\u0010\f\u001a\u00020\rX¦\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0010\u001a\u00020\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00158VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u001aR\u0014\u0010\u001b\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001b\u0010\u001aR\u0014\u0010\u001c\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u001aR\u0014\u0010\u001d\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u001aR\u0014\u0010\u001e\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001e\u0010\u001aR\u0014\u0010\u001f\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001f\u0010\u001a¨\u0006 "},
      d2 = {"Lkotlin/reflect/jvm/internal/KPropertyImpl$Accessor;", "PropertyType", "ReturnType", "Lkotlin/reflect/jvm/internal/KCallableImpl;", "Lkotlin/reflect/KProperty$Accessor;", "Lkotlin/reflect/KFunction;", "<init>", "()V", "property", "Lkotlin/reflect/jvm/internal/KPropertyImpl;", "getProperty", "()Lkotlin/reflect/jvm/internal/KPropertyImpl;", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/PropertyAccessorDescriptor;", "getDescriptor", "()Lorg/jetbrains/kotlin/descriptors/PropertyAccessorDescriptor;", "container", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "getContainer", "()Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "defaultCaller", "Lkotlin/reflect/jvm/internal/calls/Caller;", "getDefaultCaller", "()Lkotlin/reflect/jvm/internal/calls/Caller;", "isBound", "", "()Z", "isInline", "isExternal", "isOperator", "isInfix", "isSuspend", "kotlin-reflection"}
   )
   public abstract static class Accessor<PropertyType, ReturnType> extends KCallableImpl<ReturnType> implements KFunction<ReturnType>, KProperty.Accessor<PropertyType> {
      @NotNull
      public abstract KPropertyImpl<PropertyType> getProperty();

      @NotNull
      public abstract PropertyAccessorDescriptor getDescriptor();

      @NotNull
      public KDeclarationContainerImpl getContainer() {
         return this.getProperty().getContainer();
      }

      @Nullable
      public Caller<?> getDefaultCaller() {
         return null;
      }

      public boolean isBound() {
         return this.getProperty().isBound();
      }

      public boolean isInline() {
         return this.getDescriptor().isInline();
      }

      public boolean isExternal() {
         return this.getDescriptor().isExternal();
      }

      public boolean isOperator() {
         return this.getDescriptor().isOperator();
      }

      public boolean isInfix() {
         return this.getDescriptor().isInfix();
      }

      public boolean isSuspend() {
         return this.getDescriptor().isSuspend();
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
      d2 = {"Lkotlin/reflect/jvm/internal/KPropertyImpl$Companion;", "", "<init>", "()V", "EXTENSION_PROPERTY_DELEGATE", "getEXTENSION_PROPERTY_DELEGATE", "()Ljava/lang/Object;", "kotlin-reflection"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final Object getEXTENSION_PROPERTY_DELEGATE() {
         return KPropertyImpl.EXTENSION_PROPERTY_DELEGATE;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\b&\u0018\u0000*\u0006\b\u0001\u0010\u0001 \u00012\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003B\u0007¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0016\u001a\u00020\u0007H\u0016J\u0013\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0096\u0002J\b\u0010\u001b\u001a\u00020\u001cH\u0016R\u0014\u0010\u0006\u001a\u00020\u00078VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\tR\u001b\u0010\n\u001a\u00020\u000b8VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\f\u0010\rR\u001f\u0010\u0010\u001a\u0006\u0012\u0002\b\u00030\u00118VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u0012\u0010\u0013¨\u0006\u001d"},
      d2 = {"Lkotlin/reflect/jvm/internal/KPropertyImpl$Getter;", "V", "Lkotlin/reflect/jvm/internal/KPropertyImpl$Accessor;", "Lkotlin/reflect/KProperty$Getter;", "<init>", "()V", "name", "", "getName", "()Ljava/lang/String;", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/PropertyGetterDescriptor;", "getDescriptor", "()Lorg/jetbrains/kotlin/descriptors/PropertyGetterDescriptor;", "descriptor$delegate", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "caller", "Lkotlin/reflect/jvm/internal/calls/Caller;", "getCaller", "()Lkotlin/reflect/jvm/internal/calls/Caller;", "caller$delegate", "Lkotlin/Lazy;", "toString", "equals", "", "other", "", "hashCode", "", "kotlin-reflection"}
   )
   public abstract static class Getter<V> extends KPropertyImpl.Accessor<V, V> implements KProperty.Getter<V> {
      // $FF: synthetic field
      static final KProperty<Object>[] $$delegatedProperties;
      @NotNull
      private final ReflectProperties.LazySoftVal descriptor$delegate = ReflectProperties.lazySoft(new KPropertyImpl$Getter$$Lambda$0(this));
      @NotNull
      private final Lazy caller$delegate;

      public Getter() {
         this.caller$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KPropertyImpl$Getter$$Lambda$1(this));
      }

      @NotNull
      public String getName() {
         return "<get-" + this.getProperty().getName() + '>';
      }

      @NotNull
      public PropertyGetterDescriptor getDescriptor() {
         Object var10000 = this.descriptor$delegate.getValue(this, $$delegatedProperties[0]);
         Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
         return (PropertyGetterDescriptor)var10000;
      }

      @NotNull
      public Caller<?> getCaller() {
         Lazy var1 = this.caller$delegate;
         return (Caller)var1.getValue();
      }

      @NotNull
      public String toString() {
         return "getter of " + this.getProperty();
      }

      public boolean equals(@Nullable Object other) {
         return other instanceof KPropertyImpl.Getter && Intrinsics.areEqual((Object)this.getProperty(), (Object)((KPropertyImpl.Getter)other).getProperty());
      }

      public int hashCode() {
         return this.getProperty().hashCode();
      }

      private static final PropertyGetterDescriptor descriptor_delegate$lambda$0(KPropertyImpl.Getter this$0) {
         PropertyGetterDescriptor var10000 = this$0.getProperty().getDescriptor().getGetter();
         if (var10000 == null) {
            PropertyGetterDescriptorImpl var1 = DescriptorFactory.createDefaultGetter(this$0.getProperty().getDescriptor(), Annotations.Companion.getEMPTY());
            Intrinsics.checkNotNullExpressionValue(var1, "createDefaultGetter(...)");
            var10000 = (PropertyGetterDescriptor)var1;
         }

         return var10000;
      }

      private static final Caller caller_delegate$lambda$1(KPropertyImpl.Getter this$0) {
         return KPropertyImplKt.access$computeCallerForAccessor((KPropertyImpl.Accessor)this$0, true);
      }

      static {
         KProperty[] var0 = new KProperty[]{Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KPropertyImpl.Getter.class, "descriptor", "getDescriptor()Lorg/jetbrains/kotlin/descriptors/PropertyGetterDescriptor;", 0)))};
         $$delegatedProperties = var0;
      }

      // $FF: synthetic method
      static PropertyGetterDescriptor accessor$KPropertyImpl$Getter$lambda0(KPropertyImpl.Getter var0) {
         return descriptor_delegate$lambda$0(var0);
      }

      // $FF: synthetic method
      static Caller accessor$KPropertyImpl$Getter$lambda1(KPropertyImpl.Getter var0) {
         return caller_delegate$lambda$1(var0);
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\b&\u0018\u0000*\u0004\b\u0001\u0010\u00012\u000e\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u00020\u00030\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0004B\u0007¢\u0006\u0004\b\u0005\u0010\u0006J\b\u0010\u0017\u001a\u00020\bH\u0016J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0096\u0002J\b\u0010\u001c\u001a\u00020\u001dH\u0016R\u0014\u0010\u0007\u001a\u00020\b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\t\u0010\nR\u001b\u0010\u000b\u001a\u00020\f8VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\r\u0010\u000eR\u001f\u0010\u0011\u001a\u0006\u0012\u0002\b\u00030\u00128VX\u0096\u0084\u0002¢\u0006\f\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u001e"},
      d2 = {"Lkotlin/reflect/jvm/internal/KPropertyImpl$Setter;", "V", "Lkotlin/reflect/jvm/internal/KPropertyImpl$Accessor;", "", "Lkotlin/reflect/KMutableProperty$Setter;", "<init>", "()V", "name", "", "getName", "()Ljava/lang/String;", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/PropertySetterDescriptor;", "getDescriptor", "()Lorg/jetbrains/kotlin/descriptors/PropertySetterDescriptor;", "descriptor$delegate", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "caller", "Lkotlin/reflect/jvm/internal/calls/Caller;", "getCaller", "()Lkotlin/reflect/jvm/internal/calls/Caller;", "caller$delegate", "Lkotlin/Lazy;", "toString", "equals", "", "other", "", "hashCode", "", "kotlin-reflection"}
   )
   public abstract static class Setter<V> extends KPropertyImpl.Accessor<V, Unit> implements KMutableProperty.Setter<V> {
      // $FF: synthetic field
      static final KProperty<Object>[] $$delegatedProperties;
      @NotNull
      private final ReflectProperties.LazySoftVal descriptor$delegate = ReflectProperties.lazySoft(new KPropertyImpl$Setter$$Lambda$0(this));
      @NotNull
      private final Lazy caller$delegate;

      public Setter() {
         this.caller$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KPropertyImpl$Setter$$Lambda$1(this));
      }

      @NotNull
      public String getName() {
         return "<set-" + this.getProperty().getName() + '>';
      }

      @NotNull
      public PropertySetterDescriptor getDescriptor() {
         Object var10000 = this.descriptor$delegate.getValue(this, $$delegatedProperties[0]);
         Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
         return (PropertySetterDescriptor)var10000;
      }

      @NotNull
      public Caller<?> getCaller() {
         Lazy var1 = this.caller$delegate;
         return (Caller)var1.getValue();
      }

      @NotNull
      public String toString() {
         return "setter of " + this.getProperty();
      }

      public boolean equals(@Nullable Object other) {
         return other instanceof KPropertyImpl.Setter && Intrinsics.areEqual((Object)this.getProperty(), (Object)((KPropertyImpl.Setter)other).getProperty());
      }

      public int hashCode() {
         return this.getProperty().hashCode();
      }

      private static final PropertySetterDescriptor descriptor_delegate$lambda$0(KPropertyImpl.Setter this$0) {
         PropertySetterDescriptor var10000 = this$0.getProperty().getDescriptor().getSetter();
         if (var10000 == null) {
            PropertySetterDescriptorImpl var1 = DescriptorFactory.createDefaultSetter(this$0.getProperty().getDescriptor(), Annotations.Companion.getEMPTY(), Annotations.Companion.getEMPTY());
            Intrinsics.checkNotNullExpressionValue(var1, "createDefaultSetter(...)");
            var10000 = (PropertySetterDescriptor)var1;
         }

         return var10000;
      }

      private static final Caller caller_delegate$lambda$1(KPropertyImpl.Setter this$0) {
         return KPropertyImplKt.access$computeCallerForAccessor((KPropertyImpl.Accessor)this$0, false);
      }

      static {
         KProperty[] var0 = new KProperty[]{Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KPropertyImpl.Setter.class, "descriptor", "getDescriptor()Lorg/jetbrains/kotlin/descriptors/PropertySetterDescriptor;", 0)))};
         $$delegatedProperties = var0;
      }

      // $FF: synthetic method
      static PropertySetterDescriptor accessor$KPropertyImpl$Setter$lambda0(KPropertyImpl.Setter var0) {
         return descriptor_delegate$lambda$0(var0);
      }

      // $FF: synthetic method
      static Caller accessor$KPropertyImpl$Setter$lambda1(KPropertyImpl.Setter var0) {
         return caller_delegate$lambda$1(var0);
      }
   }
}
