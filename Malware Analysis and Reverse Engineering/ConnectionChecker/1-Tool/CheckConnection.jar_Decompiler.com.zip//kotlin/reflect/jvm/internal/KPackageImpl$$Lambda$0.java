package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KPackageImpl$$Lambda$0 implements Function0 {
   private final KPackageImpl arg$0;

   public KPackageImpl$$Lambda$0(KPackageImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KPackageImpl.accessor$KPackageImpl$lambda0(this.arg$0);
   }
}
