package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KMutableProperty0Impl$$Lambda$0 implements Function0 {
   private final KMutableProperty0Impl arg$0;

   public KMutableProperty0Impl$$Lambda$0(KMutableProperty0Impl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KMutableProperty0Impl.accessor$KMutableProperty0Impl$lambda0(this.arg$0);
   }
}
