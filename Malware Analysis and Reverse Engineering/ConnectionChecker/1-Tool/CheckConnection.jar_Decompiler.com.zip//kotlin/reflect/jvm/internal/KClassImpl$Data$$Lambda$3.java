package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KClassImpl$Data$$Lambda$3 implements Function0 {
   private final KClassImpl arg$0;

   public KClassImpl$Data$$Lambda$3(KClassImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KClassImpl.Data.accessor$KClassImpl$Data$lambda3(this.arg$0);
   }
}
