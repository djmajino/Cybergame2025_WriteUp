package kotlin.reflect.jvm.internal.calls;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.jvm.internal.impl.descriptors.runtime.structure.ReflectClassUtilKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0004\b\u0000\u0018\u00002\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001:\u0002!\"BA\u0012\n\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\u0006¢\u0006\u0004\b\u000e\u0010\u000fJ\u001b\u0010\u001d\u001a\u0004\u0018\u00010\u001c2\n\u0010\u001e\u001a\u0006\u0012\u0002\b\u00030\u001fH\u0016¢\u0006\u0002\u0010 R\u0012\u0010\u0003\u001a\u0006\u0012\u0002\b\u00030\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\u0004\u0018\u00010\u00028VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0013\u001a\u00020\u00148VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00140\u0006X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0018\u0010\u001a\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00040\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u001b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001c0\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006#"},
   d2 = {"Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller;", "Lkotlin/reflect/jvm/internal/calls/Caller;", "", "jClass", "Ljava/lang/Class;", "parameterNames", "", "", "callMode", "Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller$CallMode;", "origin", "Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller$Origin;", "methods", "Ljava/lang/reflect/Method;", "<init>", "(Ljava/lang/Class;Ljava/util/List;Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller$CallMode;Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller$Origin;Ljava/util/List;)V", "member", "getMember", "()Ljava/lang/Void;", "returnType", "Ljava/lang/reflect/Type;", "getReturnType", "()Ljava/lang/reflect/Type;", "parameterTypes", "getParameterTypes", "()Ljava/util/List;", "erasedParameterTypes", "defaultValues", "", "call", "args", "", "([Ljava/lang/Object;)Ljava/lang/Object;", "CallMode", "Origin", "kotlin-reflection"}
)
@SourceDebugExtension({"SMAP\nAnnotationConstructorCaller.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnnotationConstructorCaller.kt\nkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,181:1\n1563#2:182\n1634#2,3:183\n1563#2:186\n1634#2,2:187\n1636#2:190\n1563#2:191\n1634#2,3:192\n1563#2:195\n1634#2,3:196\n1#3:189\n11318#4:199\n11429#4,4:200\n*S KotlinDebug\n*F\n+ 1 AnnotationConstructorCaller.kt\nkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller\n*L\n28#1:182\n28#1:183,3\n35#1:186\n35#1:187,2\n35#1:190\n37#1:191\n37#1:192,3\n20#1:195\n20#1:196,3\n53#1:199\n53#1:200,4\n*E\n"})
public final class AnnotationConstructorCaller implements Caller {
   @NotNull
   private final Class<?> jClass;
   @NotNull
   private final List<String> parameterNames;
   @NotNull
   private final AnnotationConstructorCaller.CallMode callMode;
   @NotNull
   private final List<Method> methods;
   @NotNull
   private final List<Type> parameterTypes;
   @NotNull
   private final List<Class<?>> erasedParameterTypes;
   @NotNull
   private final List<Object> defaultValues;

   public AnnotationConstructorCaller(@NotNull Class<?> jClass, @NotNull List<String> parameterNames, @NotNull AnnotationConstructorCaller.CallMode callMode, @NotNull AnnotationConstructorCaller.Origin origin, @NotNull List<Method> methods) {
      Intrinsics.checkNotNullParameter(jClass, "jClass");
      Intrinsics.checkNotNullParameter(parameterNames, "parameterNames");
      Intrinsics.checkNotNullParameter(callMode, "callMode");
      Intrinsics.checkNotNullParameter(origin, "origin");
      Intrinsics.checkNotNullParameter(methods, "methods");
      super();
      this.jClass = jClass;
      this.parameterNames = parameterNames;
      this.callMode = callMode;
      this.methods = methods;
      Iterable $this$map$iv = (Iterable)this.methods;
      int $i$f$map = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      int $i$f$mapTo = false;
      Iterator var11 = $this$map$iv.iterator();

      Object item$iv$iv;
      Method method;
      boolean var14;
      while(var11.hasNext()) {
         item$iv$iv = var11.next();
         method = (Method)item$iv$iv;
         var14 = false;
         destination$iv$iv.add(method.getGenericReturnType());
      }

      this.parameterTypes = (List)destination$iv$iv;
      $this$map$iv = (Iterable)this.methods;
      $i$f$map = false;
      destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      $i$f$mapTo = false;

      Class var10000;
      for(var11 = $this$map$iv.iterator(); var11.hasNext(); destination$iv$iv.add(var10000)) {
         item$iv$iv = var11.next();
         method = (Method)item$iv$iv;
         var14 = false;
         Class it = method.getReturnType();
         int var16 = false;
         Intrinsics.checkNotNull(it);
         var10000 = ReflectClassUtilKt.getWrapperByPrimitive(it);
         if (var10000 == null) {
            var10000 = it;
         }
      }

      this.erasedParameterTypes = (List)destination$iv$iv;
      $this$map$iv = (Iterable)this.methods;
      $i$f$map = false;
      destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
      $i$f$mapTo = false;
      var11 = $this$map$iv.iterator();

      while(var11.hasNext()) {
         item$iv$iv = var11.next();
         method = (Method)item$iv$iv;
         var14 = false;
         destination$iv$iv.add(method.getDefaultValue());
      }

      this.defaultValues = (List)destination$iv$iv;
      if (this.callMode == AnnotationConstructorCaller.CallMode.POSITIONAL_CALL && origin == AnnotationConstructorCaller.Origin.JAVA && !((Collection)CollectionsKt.minus((Iterable)this.parameterNames, "value")).isEmpty()) {
         throw new UnsupportedOperationException("Positional call of a Java annotation constructor is allowed only if there are no parameters or one parameter named \"value\". This restriction exists because Java annotations (in contrast to Kotlin)do not impose any order on their arguments. Use KCallable#callBy instead.");
      }
   }

   // $FF: synthetic method
   public AnnotationConstructorCaller(Class var1, List var2, AnnotationConstructorCaller.CallMode var3, AnnotationConstructorCaller.Origin var4, List var5, int var6, DefaultConstructorMarker var7) {
      if ((var6 & 16) != 0) {
         Iterable $this$map$iv = (Iterable)var2;
         int $i$f$map = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;
         Iterator var13 = $this$map$iv.iterator();

         while(var13.hasNext()) {
            Object item$iv$iv = var13.next();
            String name = (String)item$iv$iv;
            int var16 = false;
            destination$iv$iv.add(var1.getDeclaredMethod(name));
         }

         var5 = (List)destination$iv$iv;
      }

      this(var1, var2, var3, var4, var5);
   }

   @Nullable
   public Void getMember() {
      return null;
   }

   @NotNull
   public Type getReturnType() {
      return (Type)this.jClass;
   }

   @NotNull
   public List<Type> getParameterTypes() {
      return this.parameterTypes;
   }

   @Nullable
   public Object call(@NotNull Object[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      this.checkArguments(args);
      int $i$f$mapIndexed = false;
      Object[] $this$mapIndexedTo$iv$iv = args;
      Collection destination$iv$iv = (Collection)(new ArrayList(args.length));
      int $i$f$mapIndexedTo = false;
      int index$iv$iv = 0;
      int var9 = 0;

      for(int var10 = args.length; var9 < var10; ++var9) {
         Object item$iv$iv = $this$mapIndexedTo$iv$iv[var9];
         int index = index$iv$iv++;
         int var14 = false;
         Object value = item$iv$iv == null && this.callMode == AnnotationConstructorCaller.CallMode.CALL_BY_NAME ? this.defaultValues.get(index) : AnnotationConstructorCallerKt.access$transformKotlinToJvm(item$iv$iv, (Class)this.erasedParameterTypes.get(index));
         if (value == null) {
            AnnotationConstructorCallerKt.access$throwIllegalArgumentType(index, (String)this.parameterNames.get(index), (Class)this.erasedParameterTypes.get(index));
            throw new KotlinNothingValueException();
         }

         destination$iv$iv.add(value);
      }

      List values = (List)destination$iv$iv;
      return AnnotationConstructorCallerKt.createAnnotationInstance(this.jClass, MapsKt.toMap((Iterable)CollectionsKt.zip((Iterable)this.parameterNames, (Iterable)values)), this.methods);
   }

   public void checkArguments(@NotNull Object[] args) {
      Caller.DefaultImpls.checkArguments(this, args);
   }

   public boolean isBoundInstanceCallWithValueClasses() {
      return Caller.DefaultImpls.isBoundInstanceCallWithValueClasses(this);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller$CallMode;", "", "<init>", "(Ljava/lang/String;I)V", "CALL_BY_NAME", "POSITIONAL_CALL", "kotlin-reflection"}
   )
   public static enum CallMode {
      CALL_BY_NAME,
      POSITIONAL_CALL;

      // $FF: synthetic field
      private static final EnumEntries $ENTRIES = EnumEntriesKt.enumEntries((Enum[])$VALUES);

      // $FF: synthetic method
      private static final AnnotationConstructorCaller.CallMode[] $values() {
         AnnotationConstructorCaller.CallMode[] var0 = new AnnotationConstructorCaller.CallMode[]{CALL_BY_NAME, POSITIONAL_CALL};
         return var0;
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lkotlin/reflect/jvm/internal/calls/AnnotationConstructorCaller$Origin;", "", "<init>", "(Ljava/lang/String;I)V", "JAVA", "KOTLIN", "kotlin-reflection"}
   )
   public static enum Origin {
      JAVA,
      KOTLIN;

      // $FF: synthetic field
      private static final EnumEntries $ENTRIES = EnumEntriesKt.enumEntries((Enum[])$VALUES);

      // $FF: synthetic method
      private static final AnnotationConstructorCaller.Origin[] $values() {
         AnnotationConstructorCaller.Origin[] var0 = new AnnotationConstructorCaller.Origin[]{JAVA, KOTLIN};
         return var0;
      }
   }
}
