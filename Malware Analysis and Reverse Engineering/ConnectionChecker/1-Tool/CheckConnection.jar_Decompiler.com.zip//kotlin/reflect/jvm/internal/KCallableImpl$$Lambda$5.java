package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KCallableImpl$$Lambda$5 implements Function0 {
   private final KCallableImpl arg$0;

   public KCallableImpl$$Lambda$5(KCallableImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KCallableImpl.accessor$KCallableImpl$lambda5(this.arg$0);
   }
}
