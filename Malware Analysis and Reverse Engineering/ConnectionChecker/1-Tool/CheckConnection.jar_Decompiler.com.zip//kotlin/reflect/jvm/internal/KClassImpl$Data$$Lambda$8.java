package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KClassImpl$Data$$Lambda$8 implements Function0 {
   private final KClassImpl.Data arg$0;
   private final KClassImpl arg$1;

   public KClassImpl$Data$$Lambda$8(KClassImpl.Data var1, KClassImpl var2) {
      this.arg$0 = var1;
      this.arg$1 = var2;
   }

   public Object invoke() {
      return KClassImpl.Data.accessor$KClassImpl$Data$lambda8(this.arg$0, this.arg$1);
   }
}
