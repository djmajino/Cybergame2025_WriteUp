package kotlin.reflect.jvm.internal.calls;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.KClass;
import kotlin.reflect.jvm.internal.KotlinReflectionInternalError;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00004\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010$\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\u001c\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u0004\u0018\u00010\u00012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003H\u0002\u001a$\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\n\u0010\n\u001a\u0006\u0012\u0002\b\u00030\u0003H\u0002\u001aI\u0010\u000b\u001a\u0002H\f\"\b\b\u0000\u0010\f*\u00020\u00012\f\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\f0\u00032\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00010\u000f2\u000e\b\u0002\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011H\u0000¢\u0006\u0002\u0010\u0013¨\u0006\u0014²\u0006\n\u0010\u0015\u001a\u00020\u0007X\u008a\u0084\u0002²\u0006\n\u0010\u0016\u001a\u00020\tX\u008a\u0084\u0002"},
   d2 = {"transformKotlinToJvm", "", "expectedType", "Ljava/lang/Class;", "throwIllegalArgumentType", "", "index", "", "name", "", "expectedJvmType", "createAnnotationInstance", "T", "annotationClass", "values", "", "methods", "", "Ljava/lang/reflect/Method;", "(Ljava/lang/Class;Ljava/util/Map;Ljava/util/List;)Ljava/lang/Object;", "kotlin-reflection", "hashCode", "toString"}
)
@SourceDebugExtension({"SMAP\nAnnotationConstructorCaller.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnnotationConstructorCaller.kt\nkotlin/reflect/jvm/internal/calls/AnnotationConstructorCallerKt\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,181:1\n11228#2:182\n11563#2,3:183\n37#3:186\n36#3,3:187\n18#3:197\n1563#4:190\n1634#4,3:191\n1740#4,3:194\n*S KotlinDebug\n*F\n+ 1 AnnotationConstructorCaller.kt\nkotlin/reflect/jvm/internal/calls/AnnotationConstructorCallerKt\n*L\n75#1:182\n75#1:183,3\n75#1:186\n75#1:187,3\n173#1:197\n102#1:190\n102#1:191,3\n106#1:194,3\n*E\n"})
public final class AnnotationConstructorCallerKt {
   private static final Object transformKotlinToJvm(Object $this$transformKotlinToJvm, Class<?> expectedType) {
      if ($this$transformKotlinToJvm instanceof Class) {
         return null;
      } else {
         Object var10000;
         if ($this$transformKotlinToJvm instanceof KClass) {
            var10000 = JvmClassMappingKt.getJavaClass((KClass)$this$transformKotlinToJvm);
         } else if ($this$transformKotlinToJvm instanceof Object[]) {
            if ((Object[])$this$transformKotlinToJvm instanceof Class[]) {
               return null;
            }

            if ((Object[])$this$transformKotlinToJvm instanceof KClass[]) {
               Intrinsics.checkNotNull($this$transformKotlinToJvm, "null cannot be cast to non-null type kotlin.Array<kotlin.reflect.KClass<*>>");
               Object[] $this$map$iv = (KClass[])$this$transformKotlinToJvm;
               int $i$f$toTypedArray = false;
               KClass[] $this$mapTo$iv$iv = $this$map$iv;
               Collection destination$iv$iv = (Collection)(new ArrayList($this$map$iv.length));
               int $i$f$mapTo = false;
               int var9 = 0;

               for(int var10 = $this$map$iv.length; var9 < var10; ++var9) {
                  Object item$iv$iv = $this$mapTo$iv$iv[var9];
                  int var13 = false;
                  destination$iv$iv.add(JvmClassMappingKt.getJavaClass(item$iv$iv));
               }

               Collection $this$toTypedArray$iv = (Collection)((List)destination$iv$iv);
               $i$f$toTypedArray = false;
               var10000 = $this$toTypedArray$iv.toArray(new Class[0]);
            } else {
               var10000 = (Object[])$this$transformKotlinToJvm;
            }
         } else {
            var10000 = $this$transformKotlinToJvm;
         }

         Object result = var10000;
         return expectedType.isInstance(result) ? result : null;
      }
   }

   private static final Void throwIllegalArgumentType(int index, String name, Class<?> expectedJvmType) {
      KClass kotlinClass = Intrinsics.areEqual((Object)expectedJvmType, (Object)Class.class) ? Reflection.getOrCreateKotlinClass(KClass.class) : (expectedJvmType.isArray() && Intrinsics.areEqual((Object)expectedJvmType.getComponentType(), (Object)Class.class) ? Reflection.getOrCreateKotlinClass(KClass[].class) : JvmClassMappingKt.getKotlinClass(expectedJvmType));
      String var5;
      if (Intrinsics.areEqual((Object)kotlinClass.getQualifiedName(), (Object)Reflection.getOrCreateKotlinClass(Object[].class).getQualifiedName())) {
         StringBuilder var10000 = (new StringBuilder()).append(kotlinClass.getQualifiedName()).append('<');
         Class var10001 = JvmClassMappingKt.getJavaClass(kotlinClass).getComponentType();
         Intrinsics.checkNotNullExpressionValue(var10001, "getComponentType(...)");
         var5 = var10000.append(JvmClassMappingKt.getKotlinClass(var10001).getQualifiedName()).append('>').toString();
      } else {
         var5 = kotlinClass.getQualifiedName();
      }

      String typeString = var5;
      throw new IllegalArgumentException("Argument #" + index + ' ' + name + " is not of the required type " + typeString);
   }

   @NotNull
   public static final <T> T createAnnotationInstance(@NotNull Class<T> annotationClass, @NotNull Map<String, ? extends Object> values, @NotNull List<Method> methods) {
      Intrinsics.checkNotNullParameter(annotationClass, "annotationClass");
      Intrinsics.checkNotNullParameter(values, "values");
      Intrinsics.checkNotNullParameter(methods, "methods");
      Lazy hashCode$delegate = LazyKt.lazy(new AnnotationConstructorCallerKt$$Lambda$0(values));
      Lazy toString$delegate = LazyKt.lazy(new AnnotationConstructorCallerKt$$Lambda$1(annotationClass, values));
      ClassLoader var10000 = annotationClass.getClassLoader();
      Class[] var6 = new Class[]{annotationClass};
      Object result = Proxy.newProxyInstance(var10000, var6, new AnnotationConstructorCallerKt$$Lambda$2(annotationClass, values, toString$delegate, hashCode$delegate, methods));
      Intrinsics.checkNotNull(result, "null cannot be cast to non-null type T of kotlin.reflect.jvm.internal.calls.AnnotationConstructorCallerKt.createAnnotationInstance");
      return result;
   }

   // $FF: synthetic method
   public static Object createAnnotationInstance$default(Class var0, Map var1, List var2, int var3, Object var4) {
      if ((var3 & 4) != 0) {
         Iterable $this$map$iv = (Iterable)var1.keySet();
         int $i$f$map = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;
         Iterator var10 = $this$map$iv.iterator();

         while(var10.hasNext()) {
            Object item$iv$iv = var10.next();
            String name = (String)item$iv$iv;
            int var13 = false;
            destination$iv$iv.add(var0.getDeclaredMethod(name));
         }

         var2 = (List)destination$iv$iv;
      }

      return createAnnotationInstance(var0, var1, var2);
   }

   private static final <T> boolean createAnnotationInstance$equals(Class<T> $annotationClass, List<Method> $methods, Map<String, ? extends Object> $values, Object other) {
      Class var14;
      label74: {
         Annotation var10000 = other instanceof Annotation ? (Annotation)other : null;
         if ((other instanceof Annotation ? (Annotation)other : null) != null) {
            KClass var13 = JvmClassMappingKt.getAnnotationClass(var10000);
            if (var13 != null) {
               var14 = JvmClassMappingKt.getJavaClass(var13);
               break label74;
            }
         }

         var14 = null;
      }

      boolean var16;
      if (Intrinsics.areEqual((Object)var14, (Object)$annotationClass)) {
         Iterable $this$all$iv = (Iterable)$methods;
         int $i$f$all = false;
         if ($this$all$iv instanceof Collection && ((Collection)$this$all$iv).isEmpty()) {
            var16 = true;
         } else {
            label82: {
               Iterator var6 = $this$all$iv.iterator();

               while(var6.hasNext()) {
                  Object element$iv = var6.next();
                  Method method = (Method)element$iv;
                  int var9 = false;
                  Object ours = $values.get(method.getName());
                  Object theirs = method.invoke(other);
                  if (ours instanceof boolean[]) {
                     boolean[] var15 = (boolean[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.BooleanArray");
                     var16 = Arrays.equals(var15, (boolean[])theirs);
                  } else if (ours instanceof char[]) {
                     char[] var17 = (char[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.CharArray");
                     var16 = Arrays.equals(var17, (char[])theirs);
                  } else if (ours instanceof byte[]) {
                     byte[] var18 = (byte[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.ByteArray");
                     var16 = Arrays.equals(var18, (byte[])theirs);
                  } else if (ours instanceof short[]) {
                     short[] var19 = (short[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.ShortArray");
                     var16 = Arrays.equals(var19, (short[])theirs);
                  } else if (ours instanceof int[]) {
                     int[] var20 = (int[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.IntArray");
                     var16 = Arrays.equals(var20, (int[])theirs);
                  } else if (ours instanceof float[]) {
                     float[] var21 = (float[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.FloatArray");
                     var16 = Arrays.equals(var21, (float[])theirs);
                  } else if (ours instanceof long[]) {
                     long[] var22 = (long[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.LongArray");
                     var16 = Arrays.equals(var22, (long[])theirs);
                  } else if (ours instanceof double[]) {
                     double[] var23 = (double[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.DoubleArray");
                     var16 = Arrays.equals(var23, (double[])theirs);
                  } else if (ours instanceof Object[]) {
                     Object[] var24 = (Object[])ours;
                     Intrinsics.checkNotNull(theirs, "null cannot be cast to non-null type kotlin.Array<*>");
                     var16 = Arrays.equals(var24, (Object[])theirs);
                  } else {
                     var16 = Intrinsics.areEqual(ours, theirs);
                  }

                  if (!var16) {
                     var16 = false;
                     break label82;
                  }
               }

               var16 = true;
            }
         }

         if (var16) {
            var16 = true;
            return var16;
         }
      }

      var16 = false;
      return var16;
   }

   private static final int createAnnotationInstance$lambda$3(Map $values) {
      Iterable var1 = (Iterable)$values.entrySet();
      int var2 = 0;

      int var12;
      for(Iterator var3 = var1.iterator(); var3.hasNext(); var2 += var12) {
         Object var4 = var3.next();
         Entry entry = (Entry)var4;
         int var6 = false;
         String key = (String)entry.getKey();
         Object value = entry.getValue();
         int valueHash = value instanceof boolean[] ? Arrays.hashCode((boolean[])value) : (value instanceof char[] ? Arrays.hashCode((char[])value) : (value instanceof byte[] ? Arrays.hashCode((byte[])value) : (value instanceof short[] ? Arrays.hashCode((short[])value) : (value instanceof int[] ? Arrays.hashCode((int[])value) : (value instanceof float[] ? Arrays.hashCode((float[])value) : (value instanceof long[] ? Arrays.hashCode((long[])value) : (value instanceof double[] ? Arrays.hashCode((double[])value) : (value instanceof Object[] ? Arrays.hashCode((Object[])value) : value.hashCode()))))))));
         var12 = 127 * key.hashCode() ^ valueHash;
      }

      return var2;
   }

   private static final int createAnnotationInstance$lambda$4(Lazy<Integer> $hashCode$delegate) {
      return ((Number)$hashCode$delegate.getValue()).intValue();
   }

   private static final CharSequence createAnnotationInstance$lambda$7$lambda$6$lambda$5(Entry entry) {
      Intrinsics.checkNotNullParameter(entry, "entry");
      String key = (String)entry.getKey();
      Object value = entry.getValue();
      String var10000;
      if (value instanceof boolean[]) {
         var10000 = Arrays.toString((boolean[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof char[]) {
         var10000 = Arrays.toString((char[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof byte[]) {
         var10000 = Arrays.toString((byte[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof short[]) {
         var10000 = Arrays.toString((short[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof int[]) {
         var10000 = Arrays.toString((int[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof float[]) {
         var10000 = Arrays.toString((float[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof long[]) {
         var10000 = Arrays.toString((long[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof double[]) {
         var10000 = Arrays.toString((double[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else if (value instanceof Object[]) {
         var10000 = Arrays.toString((Object[])value);
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      } else {
         var10000 = value.toString();
      }

      String valueString = var10000;
      return (CharSequence)(key + '=' + valueString);
   }

   private static final String createAnnotationInstance$lambda$7(Class $annotationClass, Map $values) {
      StringBuilder var2 = new StringBuilder();
      int var4 = false;
      var2.append('@');
      var2.append($annotationClass.getCanonicalName());
      CollectionsKt.joinTo$default((Iterable)$values.entrySet(), (Appendable)var2, (CharSequence)", ", (CharSequence)"(", (CharSequence)")", 0, (CharSequence)null, AnnotationConstructorCallerKt$$Lambda$3.INSTANCE, 48, (Object)null);
      return var2.toString();
   }

   private static final String createAnnotationInstance$lambda$8(Lazy<String> $toString$delegate) {
      return (String)$toString$delegate.getValue();
   }

   private static final Object createAnnotationInstance$lambda$9(Class $annotationClass, Map $values, Lazy $toString$delegate, Lazy $hashCode$delegate, List $methods, Object var5, Method method, Object[] args) {
      String name = method.getName();
      Object var10000;
      if (name != null) {
         switch(name.hashCode()) {
         case -1776922004:
            if (name.equals("toString")) {
               var10000 = createAnnotationInstance$lambda$8($toString$delegate);
               return var10000;
            }
            break;
         case 147696667:
            if (name.equals("hashCode")) {
               var10000 = createAnnotationInstance$lambda$4($hashCode$delegate);
               return var10000;
            }
            break;
         case 1444986633:
            if (name.equals("annotationType")) {
               var10000 = $annotationClass;
               return var10000;
            }
         }
      }

      if (Intrinsics.areEqual((Object)name, (Object)"equals") && (args != null ? args.length == 1 : false)) {
         var10000 = createAnnotationInstance$equals($annotationClass, $methods, $values, ArraysKt.single(args));
      } else {
         if (!$values.containsKey(name)) {
            KotlinReflectionInternalError var11 = new KotlinReflectionInternalError;
            StringBuilder var10002 = (new StringBuilder()).append("Method is not supported: ").append(method).append(" (args: ");
            int $i$f$orEmpty = false;
            Object[] var10003 = args;
            if (args == null) {
               var10003 = new Object[0];
            }

            var11.<init>(var10002.append(ArraysKt.toList(var10003)).append(')').toString());
            throw var11;
         }

         var10000 = $values.get(name);
      }

      return var10000;
   }

   // $FF: synthetic method
   public static final Object access$transformKotlinToJvm(Object $receiver, Class expectedType) {
      return transformKotlinToJvm($receiver, expectedType);
   }

   // $FF: synthetic method
   public static final Void access$throwIllegalArgumentType(int index, String name, Class expectedJvmType) {
      return throwIllegalArgumentType(index, name, expectedJvmType);
   }

   // $FF: synthetic method
   static int accessor$AnnotationConstructorCallerKt$lambda0(Map var0) {
      return createAnnotationInstance$lambda$3(var0);
   }

   // $FF: synthetic method
   static String accessor$AnnotationConstructorCallerKt$lambda1(Class var0, Map var1) {
      return createAnnotationInstance$lambda$7(var0, var1);
   }

   // $FF: synthetic method
   static Object accessor$AnnotationConstructorCallerKt$lambda2(Class var0, Map var1, Lazy var2, Lazy var3, List var4, Object var5, Method var6, Object[] var7) {
      return createAnnotationInstance$lambda$9(var0, var1, var2, var3, var4, var5, var6, var7);
   }

   // $FF: synthetic method
   static CharSequence accessor$AnnotationConstructorCallerKt$lambda3(Entry var0) {
      return createAnnotationInstance$lambda$7$lambda$6$lambda$5(var0);
   }
}
