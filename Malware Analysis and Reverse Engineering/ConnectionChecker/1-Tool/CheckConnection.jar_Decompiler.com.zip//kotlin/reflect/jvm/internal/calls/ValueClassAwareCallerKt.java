package kotlin.reflect.jvm.internal.calls;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.jvm.internal.KotlinReflectionInternalError;
import kotlin.reflect.jvm.internal.UtilKt;
import kotlin.reflect.jvm.internal.impl.builtins.KotlinBuiltIns;
import kotlin.reflect.jvm.internal.impl.descriptors.CallableDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.CallableMemberDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassifierDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ConstructorDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.MultiFieldValueClassRepresentation;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertyDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ReceiverParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.ValueParameterDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.VariableDescriptor;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.ClassMapperLite;
import kotlin.reflect.jvm.internal.impl.name.ClassId;
import kotlin.reflect.jvm.internal.impl.name.Name;
import kotlin.reflect.jvm.internal.impl.resolve.InlineClassesUtilsKt;
import kotlin.reflect.jvm.internal.impl.resolve.descriptorUtil.DescriptorUtilsKt;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;
import kotlin.reflect.jvm.internal.impl.types.SimpleType;
import kotlin.reflect.jvm.internal.impl.types.TypeSubstitutionKt;
import kotlin.reflect.jvm.internal.impl.types.TypeUtils;
import kotlin.reflect.jvm.internal.impl.types.typeUtil.TypeUtilsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000l\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\u001a\f\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0000\u001a \u0010\u0003\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00042\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0002\u001a\u0018\u0010\n\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\u0000\u001a(\u0010\u000b\u001a\u00020\f*\u0006\u0012\u0002\b\u00030\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002\u001a9\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u00042\u0006\u0010\b\u001a\u00020\t2\b\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0017\u0010\u0016\u001a\u0013\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u00110\u0017¢\u0006\u0002\b\u0019H\u0002\u001a\f\u0010\u001a\u001a\u00020\u0011*\u00020\u0015H\u0002\u001a6\u0010\u001b\u001a\b\u0012\u0004\u0012\u0002H\u001c0\r\"\n\b\u0000\u0010\u001c*\u0004\u0018\u00010\u0015*\b\u0012\u0004\u0012\u0002H\u001c0\r2\u0006\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\u0010\u001a\u00020\u0011H\u0000\u001a\f\u0010\u001d\u001a\u00020\u0011*\u00020\tH\u0002\u001a\u0018\u0010\u001e\u001a\u00020\u0005*\u0006\u0012\u0002\b\u00030\u001f2\u0006\u0010\b\u001a\u00020\tH\u0000\u001a\u0018\u0010 \u001a\u00020\u0005*\u0006\u0012\u0002\b\u00030\u001f2\u0006\u0010\b\u001a\u00020\tH\u0002\u001a\u0012\u0010!\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u001f*\u00020\u0013H\u0002\u001a\u0014\u0010!\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u001f*\u0004\u0018\u00010\"H\u0000\u001a\u0018\u0010&\u001a\u0004\u0018\u00010'*\u0004\u0018\u00010'2\u0006\u0010\b\u001a\u00020\tH\u0000\"\u001a\u0010#\u001a\u0004\u0018\u00010\u0013*\u00020\t8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b$\u0010%¨\u0006("},
   d2 = {"toJvmDescriptor", "", "Lkotlin/reflect/jvm/internal/impl/descriptors/ClassifierDescriptor;", "getValueClassUnboxMethods", "", "Ljava/lang/reflect/Method;", "type", "Lkotlin/reflect/jvm/internal/impl/types/SimpleType;", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/CallableMemberDescriptor;", "getMfvcUnboxMethods", "checkParametersSize", "", "Lkotlin/reflect/jvm/internal/calls/Caller;", "expectedArgsSize", "", "isDefault", "", "makeKotlinParameterTypes", "Lkotlin/reflect/jvm/internal/impl/types/KotlinType;", "member", "Ljava/lang/reflect/Member;", "isSpecificClass", "Lkotlin/Function1;", "Lkotlin/reflect/jvm/internal/impl/descriptors/ClassDescriptor;", "Lkotlin/ExtensionFunctionType;", "acceptsBoxedReceiverParameter", "createValueClassAwareCallerIfNeeded", "M", "hasValueClassReceiver", "getInlineClassUnboxMethod", "Ljava/lang/Class;", "getBoxMethod", "toInlineClass", "Lkotlin/reflect/jvm/internal/impl/descriptors/DeclarationDescriptor;", "expectedReceiverType", "getExpectedReceiverType", "(Lorg/jetbrains/kotlin/descriptors/CallableMemberDescriptor;)Lorg/jetbrains/kotlin/types/KotlinType;", "coerceToExpectedReceiverType", "", "kotlin-reflection"}
)
@SourceDebugExtension({"SMAP\nValueClassAwareCaller.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ValueClassAwareCaller.kt\nkotlin/reflect/jvm/internal/calls/ValueClassAwareCallerKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,392:1\n1#2:393\n1563#3:394\n1634#3,3:395\n1563#3:398\n1634#3,3:399\n1634#3,3:402\n1761#3,3:405\n1761#3,3:408\n1374#3:411\n1460#3,2:412\n1563#3:414\n1634#3,3:415\n1462#3,3:418\n*S KotlinDebug\n*F\n+ 1 ValueClassAwareCaller.kt\nkotlin/reflect/jvm/internal/calls/ValueClassAwareCallerKt\n*L\n262#1:394\n262#1:395,3\n264#1:398\n264#1:399,3\n308#1:402,3\n328#1:405,3\n329#1:408,3\n257#1:411\n257#1:412,2\n258#1:414\n258#1:415,3\n257#1:418,3\n*E\n"})
public final class ValueClassAwareCallerKt {
   @NotNull
   public static final String toJvmDescriptor(@NotNull ClassifierDescriptor $this$toJvmDescriptor) {
      Intrinsics.checkNotNullParameter($this$toJvmDescriptor, "<this>");
      ClassId var10000 = DescriptorUtilsKt.getClassId($this$toJvmDescriptor);
      Intrinsics.checkNotNull(var10000);
      return ClassMapperLite.mapClass(var10000.asString());
   }

   private static final List<Method> getValueClassUnboxMethods(SimpleType type, CallableMemberDescriptor descriptor) {
      List var10000 = getMfvcUnboxMethods(type);
      if (var10000 == null) {
         Class var4 = toInlineClass((KotlinType)type);
         if (var4 != null) {
            Method var5 = getInlineClassUnboxMethod(var4, descriptor);
            if (var5 != null) {
               Method p0 = var5;
               int var3 = false;
               var10000 = CollectionsKt.listOf(p0);
               return var10000;
            }
         }

         var10000 = null;
      }

      return var10000;
   }

   @Nullable
   public static final List<Method> getMfvcUnboxMethods(@NotNull SimpleType type) {
      Intrinsics.checkNotNullParameter(type, "type");
      List var10000 = getMfvcUnboxMethods$getUnboxMethodNameSuffixes(TypeSubstitutionKt.asSimpleType((KotlinType)type));
      if (var10000 == null) {
         return null;
      } else {
         Iterable $this$map$iv = (Iterable)var10000;
         int $i$f$map = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         int $i$f$mapTo = false;
         Iterator var9 = $this$map$iv.iterator();

         while(var9.hasNext()) {
            Object item$iv$iv = var9.next();
            String it = (String)item$iv$iv;
            int var12 = false;
            destination$iv$iv.add("unbox-impl-" + it);
         }

         List unboxMethodsNames = (List)destination$iv$iv;
         ClassifierDescriptor var20 = type.getConstructor().getDeclarationDescriptor();
         Intrinsics.checkNotNull(var20, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor");
         Class var21 = UtilKt.toJavaClass((ClassDescriptor)var20);
         Intrinsics.checkNotNull(var21);
         Class javaClass = var21;
         Iterable $this$map$iv = (Iterable)unboxMethodsNames;
         boolean var14 = false;
         Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
         boolean var15 = false;
         Iterator var16 = $this$map$iv.iterator();

         while(var16.hasNext()) {
            Object item$iv$iv = var16.next();
            String it = (String)item$iv$iv;
            int var19 = false;
            destination$iv$iv.add(javaClass.getDeclaredMethod(it));
         }

         return (List)destination$iv$iv;
      }
   }

   private static final void checkParametersSize(Caller<?> $this$checkParametersSize, int expectedArgsSize, CallableMemberDescriptor descriptor, boolean isDefault) {
      if (CallerKt.getArity($this$checkParametersSize) != expectedArgsSize) {
         throw new KotlinReflectionInternalError("Inconsistent number of parameters in the descriptor and Java reflection object: " + CallerKt.getArity($this$checkParametersSize) + " != " + expectedArgsSize + "\nCalling: " + descriptor + "\nParameter types: " + $this$checkParametersSize.getParameterTypes() + ")\nDefault: " + isDefault);
      }
   }

   private static final List<KotlinType> makeKotlinParameterTypes(CallableMemberDescriptor descriptor, Member member, Function1<? super ClassDescriptor, Boolean> isSpecificClass) {
      ArrayList var3 = new ArrayList();
      ArrayList kotlinParameterTypes = var3;
      int var5 = false;
      ReceiverParameterDescriptor var10000 = descriptor.getExtensionReceiverParameter();
      KotlinType extensionReceiverType = var10000 != null ? var10000.getType() : null;
      if (extensionReceiverType != null) {
         var3.add(extensionReceiverType);
      } else if (descriptor instanceof ConstructorDescriptor) {
         ClassDescriptor var16 = ((ConstructorDescriptor)descriptor).getConstructedClass();
         Intrinsics.checkNotNullExpressionValue(var16, "getConstructedClass(...)");
         ClassDescriptor constructedClass = var16;
         if (constructedClass.isInner()) {
            DeclarationDescriptor var10001 = constructedClass.getContainingDeclaration();
            Intrinsics.checkNotNull(var10001, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor");
            var3.add(((ClassDescriptor)var10001).getDefaultType());
         }
      } else {
         DeclarationDescriptor var17 = descriptor.getContainingDeclaration();
         Intrinsics.checkNotNullExpressionValue(var17, "getContainingDeclaration(...)");
         DeclarationDescriptor containingDeclaration = var17;
         if (containingDeclaration instanceof ClassDescriptor && (Boolean)isSpecificClass.invoke(containingDeclaration)) {
            if (member != null ? acceptsBoxedReceiverParameter(member) : false) {
               SimpleType var20 = ((ClassDescriptor)containingDeclaration).getDefaultType();
               Intrinsics.checkNotNullExpressionValue(var20, "getDefaultType(...)");
               var3.add(TypeUtilsKt.makeNullable((KotlinType)var20));
            } else {
               var3.add(((ClassDescriptor)containingDeclaration).getDefaultType());
            }
         }
      }

      List var18 = descriptor.getValueParameters();
      Intrinsics.checkNotNullExpressionValue(var18, "getValueParameters(...)");
      Iterable $this$mapTo$iv = (Iterable)var18;
      int $i$f$mapTo = false;
      Iterator var9 = $this$mapTo$iv.iterator();

      Collection var19;
      while(var9.hasNext()) {
         Object item$iv = var9.next();
         var19 = (Collection)kotlinParameterTypes;
         ValueParameterDescriptor p0 = (ValueParameterDescriptor)item$iv;
         Collection var12 = var19;
         int var13 = false;
         var12.add(p0.getType());
      }

      var19 = (Collection)kotlinParameterTypes;
      return (List)var3;
   }

   private static final boolean acceptsBoxedReceiverParameter(Member $this$acceptsBoxedReceiverParameter) {
      Class var10000 = $this$acceptsBoxedReceiverParameter.getDeclaringClass();
      if (var10000 == null) {
         return false;
      } else {
         Class clazz = var10000;
         return !JvmClassMappingKt.getKotlinClass(clazz).isValue();
      }
   }

   @NotNull
   public static final <M extends Member> Caller<M> createValueClassAwareCallerIfNeeded(@NotNull Caller<? extends M> $this$createValueClassAwareCallerIfNeeded, @NotNull CallableMemberDescriptor descriptor, boolean isDefault) {
      boolean var12;
      label67: {
         Intrinsics.checkNotNullParameter($this$createValueClassAwareCallerIfNeeded, "<this>");
         Intrinsics.checkNotNullParameter(descriptor, "descriptor");
         if (!InlineClassesUtilsKt.isGetterOfUnderlyingPropertyOfValueClass((CallableDescriptor)descriptor)) {
            List var10000 = descriptor.getContextReceiverParameters();
            Intrinsics.checkNotNullExpressionValue(var10000, "getContextReceiverParameters(...)");
            Iterable $this$any$iv = (Iterable)var10000;
            int $i$f$any = false;
            Iterator var6;
            Object element$iv;
            boolean var9;
            KotlinType var11;
            if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
               var12 = false;
            } else {
               var6 = $this$any$iv.iterator();

               while(true) {
                  if (!var6.hasNext()) {
                     var12 = false;
                     break;
                  }

                  element$iv = var6.next();
                  ReceiverParameterDescriptor it = (ReceiverParameterDescriptor)element$iv;
                  var9 = false;
                  var11 = it.getType();
                  Intrinsics.checkNotNullExpressionValue(var11, "getType(...)");
                  if (InlineClassesUtilsKt.isValueClassType(var11)) {
                     var12 = true;
                     break;
                  }
               }
            }

            if (!var12) {
               var10000 = descriptor.getValueParameters();
               Intrinsics.checkNotNullExpressionValue(var10000, "getValueParameters(...)");
               $this$any$iv = (Iterable)var10000;
               $i$f$any = false;
               if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                  var12 = false;
               } else {
                  var6 = $this$any$iv.iterator();

                  while(true) {
                     if (!var6.hasNext()) {
                        var12 = false;
                        break;
                     }

                     element$iv = var6.next();
                     ValueParameterDescriptor it = (ValueParameterDescriptor)element$iv;
                     var9 = false;
                     var11 = it.getType();
                     Intrinsics.checkNotNullExpressionValue(var11, "getType(...)");
                     if (InlineClassesUtilsKt.isValueClassType(var11)) {
                        var12 = true;
                        break;
                     }
                  }
               }

               if (!var12) {
                  var11 = descriptor.getReturnType();
                  if (!(var11 != null ? InlineClassesUtilsKt.isInlineClassType(var11) : false) && !hasValueClassReceiver(descriptor)) {
                     var12 = false;
                     break label67;
                  }
               }
            }
         }

         var12 = true;
      }

      boolean needsValueClassAwareCaller = var12;
      return needsValueClassAwareCaller ? (Caller)(new ValueClassAwareCaller(descriptor, $this$createValueClassAwareCallerIfNeeded, isDefault)) : $this$createValueClassAwareCallerIfNeeded;
   }

   // $FF: synthetic method
   public static Caller createValueClassAwareCallerIfNeeded$default(Caller var0, CallableMemberDescriptor var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return createValueClassAwareCallerIfNeeded(var0, var1, var2);
   }

   private static final boolean hasValueClassReceiver(CallableMemberDescriptor $this$hasValueClassReceiver) {
      KotlinType var10000 = getExpectedReceiverType($this$hasValueClassReceiver);
      return var10000 != null ? InlineClassesUtilsKt.isValueClassType(var10000) : false;
   }

   @NotNull
   public static final Method getInlineClassUnboxMethod(@NotNull Class<?> $this$getInlineClassUnboxMethod, @NotNull CallableMemberDescriptor descriptor) {
      Intrinsics.checkNotNullParameter($this$getInlineClassUnboxMethod, "<this>");
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");

      try {
         Method var2 = $this$getInlineClassUnboxMethod.getDeclaredMethod("unbox-impl");
         Intrinsics.checkNotNull(var2);
         return var2;
      } catch (NoSuchMethodException var4) {
         throw new KotlinReflectionInternalError("No unbox method found in inline class: " + $this$getInlineClassUnboxMethod + " (calling " + descriptor + ')');
      }
   }

   private static final Method getBoxMethod(Class<?> $this$getBoxMethod, CallableMemberDescriptor descriptor) {
      try {
         Class[] var3 = new Class[]{getInlineClassUnboxMethod($this$getBoxMethod, descriptor).getReturnType()};
         Method var2 = $this$getBoxMethod.getDeclaredMethod("box-impl", var3);
         Intrinsics.checkNotNull(var2);
         return var2;
      } catch (NoSuchMethodException var4) {
         throw new KotlinReflectionInternalError("No box method found in inline class: " + $this$getBoxMethod + " (calling " + descriptor + ')');
      }
   }

   private static final Class<?> toInlineClass(KotlinType $this$toInlineClass) {
      Class var10000 = toInlineClass((DeclarationDescriptor)$this$toInlineClass.getConstructor().getDeclarationDescriptor());
      if (var10000 == null) {
         return null;
      } else {
         Class klass = var10000;
         if (!TypeUtils.isNullableType($this$toInlineClass)) {
            return klass;
         } else {
            KotlinType var3 = InlineClassesUtilsKt.unsubstitutedUnderlyingType($this$toInlineClass);
            if (var3 == null) {
               return null;
            } else {
               KotlinType expandedUnderlyingType = var3;
               return !TypeUtils.isNullableType(expandedUnderlyingType) && !KotlinBuiltIns.isPrimitiveType(expandedUnderlyingType) ? klass : null;
            }
         }
      }
   }

   @Nullable
   public static final Class<?> toInlineClass(@Nullable DeclarationDescriptor $this$toInlineClass) {
      Class var10000;
      if ($this$toInlineClass instanceof ClassDescriptor && InlineClassesUtilsKt.isInlineClass($this$toInlineClass)) {
         var10000 = UtilKt.toJavaClass((ClassDescriptor)$this$toInlineClass);
         if (var10000 == null) {
            throw new KotlinReflectionInternalError("Class object for the class " + ((ClassDescriptor)$this$toInlineClass).getName() + " cannot be found (classId=" + DescriptorUtilsKt.getClassId((ClassifierDescriptor)$this$toInlineClass) + ')');
         }
      } else {
         var10000 = null;
      }

      return var10000;
   }

   private static final KotlinType getExpectedReceiverType(CallableMemberDescriptor $this$expectedReceiverType) {
      ReceiverParameterDescriptor extensionReceiver = $this$expectedReceiverType.getExtensionReceiverParameter();
      ReceiverParameterDescriptor dispatchReceiver = $this$expectedReceiverType.getDispatchReceiverParameter();
      KotlinType var10000;
      if (extensionReceiver != null) {
         var10000 = extensionReceiver.getType();
      } else if (dispatchReceiver == null) {
         var10000 = null;
      } else if ($this$expectedReceiverType instanceof ConstructorDescriptor) {
         var10000 = dispatchReceiver.getType();
      } else {
         DeclarationDescriptor var3 = $this$expectedReceiverType.getContainingDeclaration();
         var10000 = (KotlinType)((var3 instanceof ClassDescriptor ? (ClassDescriptor)var3 : null) != null ? (var3 instanceof ClassDescriptor ? (ClassDescriptor)var3 : null).getDefaultType() : null);
      }

      return var10000;
   }

   @Nullable
   public static final Object coerceToExpectedReceiverType(@Nullable Object $this$coerceToExpectedReceiverType, @NotNull CallableMemberDescriptor descriptor) {
      Intrinsics.checkNotNullParameter(descriptor, "descriptor");
      if (descriptor instanceof PropertyDescriptor && InlineClassesUtilsKt.isUnderlyingPropertyOfInlineClass((VariableDescriptor)descriptor)) {
         return $this$coerceToExpectedReceiverType;
      } else {
         KotlinType expectedReceiverType = getExpectedReceiverType(descriptor);
         if (expectedReceiverType != null) {
            Class var10000 = toInlineClass(expectedReceiverType);
            if (var10000 != null) {
               Method var4 = getInlineClassUnboxMethod(var10000, descriptor);
               if (var4 != null) {
                  Method unboxMethod = var4;
                  return unboxMethod.invoke($this$coerceToExpectedReceiverType);
               }
            }
         }

         return $this$coerceToExpectedReceiverType;
      }
   }

   private static final List<String> getMfvcUnboxMethods$getUnboxMethodNameSuffixes(SimpleType type) {
      List var24;
      if (InlineClassesUtilsKt.needsMfvcFlattening((KotlinType)type)) {
         ClassifierDescriptor var10000 = type.getConstructor().getDeclarationDescriptor();
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor");
         MultiFieldValueClassRepresentation var23 = DescriptorUtilsKt.getMultiFieldValueClassRepresentation((ClassDescriptor)var10000);
         Intrinsics.checkNotNull(var23);
         Iterable $this$flatMap$iv = (Iterable)var23.getUnderlyingPropertyNamesToTypes();
         int $i$f$flatMap = false;
         Collection destination$iv$iv = (Collection)(new ArrayList());
         int $i$f$flatMapTo = false;
         Iterator var6 = $this$flatMap$iv.iterator();

         while(var6.hasNext()) {
            Object element$iv$iv = var6.next();
            Pair var8 = (Pair)element$iv$iv;
            int var9 = false;
            Name name = (Name)var8.component1();
            SimpleType innerType = (SimpleType)var8.component2();
            var24 = getMfvcUnboxMethods$getUnboxMethodNameSuffixes(innerType);
            if (var24 == null) {
               var24 = CollectionsKt.listOf(name.getIdentifier());
            } else {
               Iterable $this$map$iv = (Iterable)var24;
               int $i$f$map = false;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               int $i$f$mapTo = false;
               Iterator var17 = $this$map$iv.iterator();

               while(var17.hasNext()) {
                  Object item$iv$iv = var17.next();
                  String it = (String)item$iv$iv;
                  int var21 = false;
                  destination$iv$iv.add(name.getIdentifier() + '-' + it);
               }

               var24 = (List)destination$iv$iv;
            }

            Iterable list$iv$iv = (Iterable)var24;
            CollectionsKt.addAll(destination$iv$iv, list$iv$iv);
         }

         var24 = (List)destination$iv$iv;
      } else {
         var24 = null;
      }

      return var24;
   }

   // $FF: synthetic method
   public static final List access$getValueClassUnboxMethods(SimpleType type, CallableMemberDescriptor descriptor) {
      return getValueClassUnboxMethods(type, descriptor);
   }

   // $FF: synthetic method
   public static final Class access$toInlineClass(KotlinType $receiver) {
      return toInlineClass($receiver);
   }

   // $FF: synthetic method
   public static final Method access$getBoxMethod(Class $receiver, CallableMemberDescriptor descriptor) {
      return getBoxMethod($receiver, descriptor);
   }

   // $FF: synthetic method
   public static final List access$makeKotlinParameterTypes(CallableMemberDescriptor descriptor, Member member, Function1 isSpecificClass) {
      return makeKotlinParameterTypes(descriptor, member, isSpecificClass);
   }

   // $FF: synthetic method
   public static final void access$checkParametersSize(Caller $receiver, int expectedArgsSize, CallableMemberDescriptor descriptor, boolean isDefault) {
      checkParametersSize($receiver, expectedArgsSize, descriptor, isDefault);
   }
}
