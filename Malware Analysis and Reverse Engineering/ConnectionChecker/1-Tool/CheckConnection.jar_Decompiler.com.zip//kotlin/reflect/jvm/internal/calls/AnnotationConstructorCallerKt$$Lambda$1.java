package kotlin.reflect.jvm.internal.calls;

import java.util.Map;
import kotlin.jvm.functions.Function0;

class AnnotationConstructorCallerKt$$Lambda$1 implements Function0 {
   private final Class arg$0;
   private final Map arg$1;

   public AnnotationConstructorCallerKt$$Lambda$1(Class var1, Map var2) {
      this.arg$0 = var1;
      this.arg$1 = var2;
   }

   public Object invoke() {
      return AnnotationConstructorCallerKt.accessor$AnnotationConstructorCallerKt$lambda1(this.arg$0, this.arg$1);
   }
}
