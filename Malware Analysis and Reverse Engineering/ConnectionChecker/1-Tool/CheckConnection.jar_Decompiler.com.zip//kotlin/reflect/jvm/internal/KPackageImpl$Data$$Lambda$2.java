package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KPackageImpl$Data$$Lambda$2 implements Function0 {
   private final KPackageImpl.Data arg$0;
   private final KPackageImpl arg$1;

   public KPackageImpl$Data$$Lambda$2(KPackageImpl.Data var1, KPackageImpl var2) {
      this.arg$0 = var1;
      this.arg$1 = var2;
   }

   public Object invoke() {
      return KPackageImpl.Data.accessor$KPackageImpl$Data$lambda2(this.arg$0, this.arg$1);
   }
}
