package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KFunctionImpl$$Lambda$1 implements Function0 {
   private final KFunctionImpl arg$0;

   public KFunctionImpl$$Lambda$1(KFunctionImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KFunctionImpl.accessor$KFunctionImpl$lambda1(this.arg$0);
   }
}
