package kotlin.reflect.jvm.internal;

import java.util.Comparator;
import kotlin.jvm.functions.Function2;

class KDeclarationContainerImpl$$Lambda$1 implements Comparator {
   private final Function2 arg$0;

   public KDeclarationContainerImpl$$Lambda$1(Function2 var1) {
      this.arg$0 = var1;
   }

   public int compare(Object var1, Object var2) {
      return KDeclarationContainerImpl.accessor$KDeclarationContainerImpl$lambda1(this.arg$0, var1, var2);
   }
}
