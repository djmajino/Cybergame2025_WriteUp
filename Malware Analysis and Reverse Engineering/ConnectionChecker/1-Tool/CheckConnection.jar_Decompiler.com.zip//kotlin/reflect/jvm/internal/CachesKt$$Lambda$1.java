package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function1;

class CachesKt$$Lambda$1 implements Function1 {
   public static final CachesKt$$Lambda$1 INSTANCE = new CachesKt$$Lambda$1();

   public CachesKt$$Lambda$1() {
   }

   public Object invoke(Object var1) {
      return CachesKt.accessor$CachesKt$lambda1((Class)var1);
   }
}
