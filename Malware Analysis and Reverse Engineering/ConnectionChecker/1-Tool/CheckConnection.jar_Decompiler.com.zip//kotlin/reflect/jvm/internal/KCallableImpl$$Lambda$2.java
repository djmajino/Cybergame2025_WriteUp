package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KCallableImpl$$Lambda$2 implements Function0 {
   private final KCallableImpl arg$0;

   public KCallableImpl$$Lambda$2(KCallableImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KCallableImpl.accessor$KCallableImpl$lambda2(this.arg$0);
   }
}
