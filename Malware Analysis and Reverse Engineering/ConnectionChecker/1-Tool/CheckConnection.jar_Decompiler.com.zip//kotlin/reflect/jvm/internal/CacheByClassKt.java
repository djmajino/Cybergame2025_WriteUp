package kotlin.reflect.jvm.internal;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a0\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\u00040\u0003\"\b\b\u0000\u0010\u0004*\u00020\u00052\u0016\u0010\u0006\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b\u0012\u0004\u0012\u0002H\u00040\u0007H\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"},
   d2 = {"useClassValue", "", "createCache", "Lkotlin/reflect/jvm/internal/CacheByClass;", "V", "", "compute", "Lkotlin/Function1;", "Ljava/lang/Class;", "kotlin-reflection"}
)
@SourceDebugExtension({"SMAP\nCacheByClass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CacheByClass.kt\nkotlin/reflect/jvm/internal/CacheByClassKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,98:1\n1#2:99\n*E\n"})
public final class CacheByClassKt {
   private static final boolean useClassValue;

   @NotNull
   public static final <V> CacheByClass<V> createCache(@NotNull Function1<? super Class<?>, ? extends V> compute) {
      Intrinsics.checkNotNullParameter(compute, "compute");
      return useClassValue ? (CacheByClass)(new ClassValueCache(compute)) : (CacheByClass)(new ConcurrentHashMapCache(compute));
   }

   static {
      Result.Companion var10000;
      Object var0;
      try {
         var10000 = Result.Companion;
         int var4 = false;
         var0 = Result.constructor-impl(Class.forName("java.lang.ClassValue"));
      } catch (Throwable var3) {
         var10000 = Result.Companion;
         var0 = Result.constructor-impl(ResultKt.createFailure(var3));
      }

      Object var6;
      if (Result.isSuccess-impl(var0)) {
         var10000 = Result.Companion;
         Class it = (Class)var0;
         int var2 = false;
         var6 = Result.constructor-impl(true);
      } else {
         var6 = Result.constructor-impl(var0);
      }

      var0 = var6;
      Boolean var5 = false;
      useClassValue = (Boolean)(Result.isFailure-impl(var0) ? var5 : var0);
   }
}
