package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KProperty0Impl$$Lambda$0 implements Function0 {
   private final KProperty0Impl arg$0;

   public KProperty0Impl$$Lambda$0(KProperty0Impl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KProperty0Impl.accessor$KProperty0Impl$lambda0(this.arg$0);
   }
}
