package kotlin.reflect.jvm.internal;

import java.util.Collection;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.PropertyReference1;
import kotlin.jvm.internal.PropertyReference1Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KCallable;
import kotlin.reflect.KProperty;
import kotlin.reflect.jvm.internal.impl.descriptors.ConstructorDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.FunctionDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertyDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.runtime.components.ReflectKotlinClass;
import kotlin.reflect.jvm.internal.impl.descriptors.runtime.structure.ReflectClassUtilKt;
import kotlin.reflect.jvm.internal.impl.incremental.components.LookupLocation;
import kotlin.reflect.jvm.internal.impl.incremental.components.NoLookupLocation;
import kotlin.reflect.jvm.internal.impl.load.kotlin.header.KotlinClassHeader;
import kotlin.reflect.jvm.internal.impl.metadata.ProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.BinaryVersion;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.MetadataVersion;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.NameResolver;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.ProtoBufUtilKt;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.TypeTable;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.JvmProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmNameResolver;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmProtoBufUtil;
import kotlin.reflect.jvm.internal.impl.name.Name;
import kotlin.reflect.jvm.internal.impl.protobuf.GeneratedMessageLite;
import kotlin.reflect.jvm.internal.impl.protobuf.MessageLite;
import kotlin.reflect.jvm.internal.impl.resolve.scopes.MemberScope;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001:\u0001)B\u0013\u0012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001a0\u00122\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J\u0016\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u001e0\u00122\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J\u0012\u0010\u001f\u001a\u0004\u0018\u00010\u001a2\u0006\u0010 \u001a\u00020!H\u0016J\u0013\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%H\u0096\u0002J\b\u0010&\u001a\u00020!H\u0016J\b\u0010'\u001a\u00020(H\u0016R\u0018\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0018\u0010\b\u001a\f\u0012\b\u0012\u00060\nR\u00020\u00000\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u000b\u001a\u0006\u0012\u0002\b\u00030\u00038TX\u0094\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\u0007R\u0014\u0010\r\u001a\u00020\u000e8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u001e\u0010\u0011\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00130\u00128VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\u00128VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u0015¨\u0006*"},
   d2 = {"Lkotlin/reflect/jvm/internal/KPackageImpl;", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "jClass", "Ljava/lang/Class;", "<init>", "(Ljava/lang/Class;)V", "getJClass", "()Ljava/lang/Class;", "data", "Lkotlin/Lazy;", "Lkotlin/reflect/jvm/internal/KPackageImpl$Data;", "methodOwner", "getMethodOwner", "scope", "Lkotlin/reflect/jvm/internal/impl/resolve/scopes/MemberScope;", "getScope", "()Lorg/jetbrains/kotlin/resolve/scopes/MemberScope;", "members", "", "Lkotlin/reflect/KCallable;", "getMembers", "()Ljava/util/Collection;", "constructorDescriptors", "Lkotlin/reflect/jvm/internal/impl/descriptors/ConstructorDescriptor;", "getConstructorDescriptors", "getProperties", "Lkotlin/reflect/jvm/internal/impl/descriptors/PropertyDescriptor;", "name", "Lkotlin/reflect/jvm/internal/impl/name/Name;", "getFunctions", "Lkotlin/reflect/jvm/internal/impl/descriptors/FunctionDescriptor;", "getLocalProperty", "index", "", "equals", "", "other", "", "hashCode", "toString", "", "Data", "kotlin-reflection"}
)
public final class KPackageImpl extends KDeclarationContainerImpl {
   @NotNull
   private final Class<?> jClass;
   @NotNull
   private final Lazy<KPackageImpl.Data> data;

   public KPackageImpl(@NotNull Class<?> jClass) {
      Intrinsics.checkNotNullParameter(jClass, "jClass");
      super();
      this.jClass = jClass;
      this.data = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KPackageImpl$$Lambda$0(this));
   }

   @NotNull
   public Class<?> getJClass() {
      return this.jClass;
   }

   @NotNull
   protected Class<?> getMethodOwner() {
      Class var10000 = ((KPackageImpl.Data)this.data.getValue()).getMultifileFacade();
      if (var10000 == null) {
         var10000 = this.getJClass();
      }

      return var10000;
   }

   private final MemberScope getScope() {
      return ((KPackageImpl.Data)this.data.getValue()).getScope();
   }

   @NotNull
   public Collection<KCallable<?>> getMembers() {
      return ((KPackageImpl.Data)this.data.getValue()).getMembers();
   }

   @NotNull
   public Collection<ConstructorDescriptor> getConstructorDescriptors() {
      return (Collection)CollectionsKt.emptyList();
   }

   @NotNull
   public Collection<PropertyDescriptor> getProperties(@NotNull Name name) {
      Intrinsics.checkNotNullParameter(name, "name");
      return this.getScope().getContributedVariables(name, (LookupLocation)NoLookupLocation.FROM_REFLECTION);
   }

   @NotNull
   public Collection<FunctionDescriptor> getFunctions(@NotNull Name name) {
      Intrinsics.checkNotNullParameter(name, "name");
      return this.getScope().getContributedFunctions(name, (LookupLocation)NoLookupLocation.FROM_REFLECTION);
   }

   @Nullable
   public PropertyDescriptor getLocalProperty(int index) {
      Triple var10000 = ((KPackageImpl.Data)this.data.getValue()).getMetadata();
      PropertyDescriptor var12;
      if (var10000 != null) {
         Triple var2 = var10000;
         int var3 = false;
         JvmNameResolver nameResolver = (JvmNameResolver)var2.component1();
         ProtoBuf.Package packageProto = (ProtoBuf.Package)var2.component2();
         MetadataVersion metadataVersion = (MetadataVersion)var2.component3();
         GeneratedMessageLite.ExtendableMessage var9 = (GeneratedMessageLite.ExtendableMessage)packageProto;
         GeneratedMessageLite.GeneratedExtension var10001 = JvmProtoBuf.packageLocalVariable;
         Intrinsics.checkNotNullExpressionValue(var10001, "packageLocalVariable");
         ProtoBuf.Property var10 = (ProtoBuf.Property)ProtoBufUtilKt.getExtensionOrNull(var9, var10001, index);
         if (var10 != null) {
            ProtoBuf.Property proto = var10;
            int var8 = false;
            Class var11 = this.getJClass();
            MessageLite var13 = (MessageLite)proto;
            NameResolver var10002 = (NameResolver)nameResolver;
            ProtoBuf.TypeTable var10005 = packageProto.getTypeTable();
            Intrinsics.checkNotNullExpressionValue(var10005, "getTypeTable(...)");
            var12 = (PropertyDescriptor)UtilKt.deserializeToDescriptor(var11, var13, var10002, new TypeTable(var10005), (BinaryVersion)metadataVersion, (Function2)null.INSTANCE);
         } else {
            var12 = null;
         }
      } else {
         var12 = null;
      }

      return var12;
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof KPackageImpl && Intrinsics.areEqual((Object)this.getJClass(), (Object)((KPackageImpl)other).getJClass());
   }

   public int hashCode() {
      return this.getJClass().hashCode();
   }

   @NotNull
   public String toString() {
      return "file class " + ReflectClassUtilKt.getClassId(this.getJClass()).asSingleFqName();
   }

   private static final KPackageImpl.Data data$lambda$0(KPackageImpl this$0) {
      return this$0.new Data();
   }

   // $FF: synthetic method
   static KPackageImpl.Data accessor$KPackageImpl$lambda0(KPackageImpl var0) {
      return data$lambda$0(var0);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u00060\u0001R\u00020\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004R\u001d\u0010\u0005\u001a\u0004\u0018\u00010\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR\u001b\u0010\u000b\u001a\u00020\f8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\n\u001a\u0004\b\r\u0010\u000eR!\u0010\u0010\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00118FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u0012\u0010\u0013R/\u0010\u0016\u001a\u0016\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u001a\u0018\u00010\u00178FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u001d\u0010\u0015\u001a\u0004\b\u001b\u0010\u001cR%\u0010\u001e\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030 0\u001f8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b#\u0010\n\u001a\u0004\b!\u0010\"¨\u0006$"},
      d2 = {"Lkotlin/reflect/jvm/internal/KPackageImpl$Data;", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl$Data;", "Lkotlin/reflect/jvm/internal/KDeclarationContainerImpl;", "<init>", "(Lkotlin/reflect/jvm/internal/KPackageImpl;)V", "kotlinClass", "Lkotlin/reflect/jvm/internal/impl/descriptors/runtime/components/ReflectKotlinClass;", "getKotlinClass", "()Lorg/jetbrains/kotlin/descriptors/runtime/components/ReflectKotlinClass;", "kotlinClass$delegate", "Lkotlin/reflect/jvm/internal/ReflectProperties$LazySoftVal;", "scope", "Lkotlin/reflect/jvm/internal/impl/resolve/scopes/MemberScope;", "getScope", "()Lorg/jetbrains/kotlin/resolve/scopes/MemberScope;", "scope$delegate", "multifileFacade", "Ljava/lang/Class;", "getMultifileFacade", "()Ljava/lang/Class;", "multifileFacade$delegate", "Lkotlin/Lazy;", "metadata", "Lkotlin/Triple;", "Lkotlin/reflect/jvm/internal/impl/metadata/jvm/deserialization/JvmNameResolver;", "Lkotlin/reflect/jvm/internal/impl/metadata/ProtoBuf$Package;", "Lkotlin/reflect/jvm/internal/impl/metadata/deserialization/MetadataVersion;", "getMetadata", "()Lkotlin/Triple;", "metadata$delegate", "members", "", "Lkotlin/reflect/jvm/internal/KCallableImpl;", "getMembers", "()Ljava/util/Collection;", "members$delegate", "kotlin-reflection"}
   )
   private final class Data extends KDeclarationContainerImpl.Data {
      // $FF: synthetic field
      static final KProperty<Object>[] $$delegatedProperties;
      @NotNull
      private final ReflectProperties.LazySoftVal kotlinClass$delegate;
      @NotNull
      private final ReflectProperties.LazySoftVal scope$delegate;
      @NotNull
      private final Lazy multifileFacade$delegate;
      @NotNull
      private final Lazy metadata$delegate;
      @NotNull
      private final ReflectProperties.LazySoftVal members$delegate;

      public Data() {
         super();
         KPackageImpl var2 = KPackageImpl.this;
         this.kotlinClass$delegate = ReflectProperties.lazySoft(new KPackageImpl$Data$$Lambda$0(var2));
         this.scope$delegate = ReflectProperties.lazySoft(new KPackageImpl$Data$$Lambda$1(this));
         var2 = KPackageImpl.this;
         this.multifileFacade$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KPackageImpl$Data$$Lambda$2(this, var2));
         this.metadata$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new KPackageImpl$Data$$Lambda$3(this));
         KPackageImpl var3 = KPackageImpl.this;
         this.members$delegate = ReflectProperties.lazySoft(new KPackageImpl$Data$$Lambda$4(var3, this));
      }

      private final ReflectKotlinClass getKotlinClass() {
         return (ReflectKotlinClass)this.kotlinClass$delegate.getValue(this, $$delegatedProperties[0]);
      }

      @NotNull
      public final MemberScope getScope() {
         Object var10000 = this.scope$delegate.getValue(this, $$delegatedProperties[1]);
         Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
         return (MemberScope)var10000;
      }

      @Nullable
      public final Class<?> getMultifileFacade() {
         Lazy var1 = this.multifileFacade$delegate;
         return (Class)var1.getValue();
      }

      @Nullable
      public final Triple<JvmNameResolver, ProtoBuf.Package, MetadataVersion> getMetadata() {
         Lazy var1 = this.metadata$delegate;
         return (Triple)var1.getValue();
      }

      @NotNull
      public final Collection<KCallableImpl<?>> getMembers() {
         Object var10000 = this.members$delegate.getValue(this, $$delegatedProperties[2]);
         Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
         return (Collection)var10000;
      }

      private static final ReflectKotlinClass kotlinClass_delegate$lambda$0(KPackageImpl this$0) {
         return ReflectKotlinClass.Factory.create(this$0.getJClass());
      }

      private static final MemberScope scope_delegate$lambda$1(KPackageImpl.Data this$0) {
         ReflectKotlinClass klass = this$0.getKotlinClass();
         return klass != null ? this$0.getModuleData().getPackagePartScopeCache().getPackagePartScope(klass) : (MemberScope)MemberScope.Empty.INSTANCE;
      }

      private static final Class multifileFacade_delegate$lambda$2(KPackageImpl.Data this$0, KPackageImpl this$1) {
         String var4;
         label26: {
            ReflectKotlinClass var10000 = this$0.getKotlinClass();
            if (var10000 != null) {
               KotlinClassHeader var3 = var10000.getClassHeader();
               if (var3 != null) {
                  var4 = var3.getMultifileClassName();
                  break label26;
               }
            }

            var4 = null;
         }

         String facadeName = var4;
         return facadeName != null && ((CharSequence)facadeName).length() > 0 ? this$1.getJClass().getClassLoader().loadClass(StringsKt.replace$default(facadeName, '/', '.', false, 4, (Object)null)) : null;
      }

      private static final Triple metadata_delegate$lambda$4(KPackageImpl.Data this$0) {
         ReflectKotlinClass var10000 = this$0.getKotlinClass();
         Triple var9;
         if (var10000 != null) {
            KotlinClassHeader var8 = var10000.getClassHeader();
            if (var8 != null) {
               KotlinClassHeader header = var8;
               int var2 = false;
               String[] data = header.getData();
               String[] strings = header.getStrings();
               if (data != null && strings != null) {
                  Pair var5 = JvmProtoBufUtil.readPackageDataFrom(data, strings);
                  JvmNameResolver nameResolver = (JvmNameResolver)var5.component1();
                  ProtoBuf.Package proto = (ProtoBuf.Package)var5.component2();
                  var9 = new Triple(nameResolver, proto, header.getMetadataVersion());
               } else {
                  var9 = null;
               }

               return var9;
            }
         }

         var9 = null;
         return var9;
      }

      private static final Collection members_delegate$lambda$5(KPackageImpl this$0, KPackageImpl.Data this$1) {
         return this$0.getMembers(this$1.getScope(), KDeclarationContainerImpl.MemberBelonginess.DECLARED);
      }

      static {
         KProperty[] var0 = new KProperty[]{Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KPackageImpl.Data.class, "kotlinClass", "getKotlinClass()Lorg/jetbrains/kotlin/descriptors/runtime/components/ReflectKotlinClass;", 0))), Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KPackageImpl.Data.class, "scope", "getScope()Lorg/jetbrains/kotlin/resolve/scopes/MemberScope;", 0))), Reflection.property1((PropertyReference1)(new PropertyReference1Impl(KPackageImpl.Data.class, "members", "getMembers()Ljava/util/Collection;", 0)))};
         $$delegatedProperties = var0;
      }

      // $FF: synthetic method
      static ReflectKotlinClass accessor$KPackageImpl$Data$lambda0(KPackageImpl var0) {
         return kotlinClass_delegate$lambda$0(var0);
      }

      // $FF: synthetic method
      static MemberScope accessor$KPackageImpl$Data$lambda1(KPackageImpl.Data var0) {
         return scope_delegate$lambda$1(var0);
      }

      // $FF: synthetic method
      static Class accessor$KPackageImpl$Data$lambda2(KPackageImpl.Data var0, KPackageImpl var1) {
         return multifileFacade_delegate$lambda$2(var0, var1);
      }

      // $FF: synthetic method
      static Triple accessor$KPackageImpl$Data$lambda3(KPackageImpl.Data var0) {
         return metadata_delegate$lambda$4(var0);
      }

      // $FF: synthetic method
      static Collection accessor$KPackageImpl$Data$lambda4(KPackageImpl var0, KPackageImpl.Data var1) {
         return members_delegate$lambda$5(var0, var1);
      }
   }
}
