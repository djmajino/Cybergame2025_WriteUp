package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KProperty1Impl$$Lambda$0 implements Function0 {
   private final KProperty1Impl arg$0;

   public KProperty1Impl$$Lambda$0(KProperty1Impl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KProperty1Impl.accessor$KProperty1Impl$lambda0(this.arg$0);
   }
}
