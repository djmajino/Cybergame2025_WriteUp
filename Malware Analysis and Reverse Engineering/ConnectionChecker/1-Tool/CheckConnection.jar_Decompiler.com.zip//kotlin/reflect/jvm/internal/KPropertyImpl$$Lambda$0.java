package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KPropertyImpl$$Lambda$0 implements Function0 {
   private final KPropertyImpl arg$0;

   public KPropertyImpl$$Lambda$0(KPropertyImpl var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KPropertyImpl.accessor$KPropertyImpl$lambda0(this.arg$0);
   }
}
