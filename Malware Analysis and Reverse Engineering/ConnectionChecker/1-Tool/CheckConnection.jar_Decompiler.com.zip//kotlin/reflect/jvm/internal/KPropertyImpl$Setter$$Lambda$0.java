package kotlin.reflect.jvm.internal;

import kotlin.jvm.functions.Function0;

class KPropertyImpl$Setter$$Lambda$0 implements Function0 {
   private final KPropertyImpl.Setter arg$0;

   public KPropertyImpl$Setter$$Lambda$0(KPropertyImpl.Setter var1) {
      this.arg$0 = var1;
   }

   public Object invoke() {
      return KPropertyImpl.Setter.accessor$KPropertyImpl$Setter$lambda0(this.arg$0);
   }
}
