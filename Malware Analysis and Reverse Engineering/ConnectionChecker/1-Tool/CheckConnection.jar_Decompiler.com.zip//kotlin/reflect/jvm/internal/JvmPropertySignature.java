package kotlin.reflect.jvm.internal;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.jvm.internal.impl.descriptors.DeclarationDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.DescriptorVisibilities;
import kotlin.reflect.jvm.internal.impl.descriptors.PackageFragmentDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.PropertyDescriptor;
import kotlin.reflect.jvm.internal.impl.descriptors.runtime.structure.ReflectClassUtilKt;
import kotlin.reflect.jvm.internal.impl.load.java.JvmAbi;
import kotlin.reflect.jvm.internal.impl.load.kotlin.JvmPackagePartSource;
import kotlin.reflect.jvm.internal.impl.metadata.ProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.NameResolver;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.ProtoBufUtilKt;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.TypeTable;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.JvmProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmMemberSignature;
import kotlin.reflect.jvm.internal.impl.metadata.jvm.deserialization.JvmProtoBufUtil;
import kotlin.reflect.jvm.internal.impl.name.NameUtils;
import kotlin.reflect.jvm.internal.impl.protobuf.GeneratedMessageLite;
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors.DeserializedClassDescriptor;
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors.DeserializedContainerSource;
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors.DeserializedPropertyDescriptor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b0\u0018\u00002\u00020\u0001:\u0004\u0006\u0007\b\tB\t\b\u0004¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&\u0082\u0001\u0004\n\u000b\f\r¨\u0006\u000e"},
   d2 = {"Lkotlin/reflect/jvm/internal/JvmPropertySignature;", "", "<init>", "()V", "asString", "", "KotlinProperty", "JavaMethodProperty", "JavaField", "MappedKotlinProperty", "Lkotlin/reflect/jvm/internal/JvmPropertySignature$JavaField;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature$JavaMethodProperty;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature$KotlinProperty;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature$MappedKotlinProperty;", "kotlin-reflection"}
)
public abstract class JvmPropertySignature {
   private JvmPropertySignature() {
   }

   @NotNull
   public abstract String asString();

   // $FF: synthetic method
   public JvmPropertySignature(DefaultConstructorMarker $constructor_marker) {
      this();
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\b\u001a\u00020\tH\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\n"},
      d2 = {"Lkotlin/reflect/jvm/internal/JvmPropertySignature$JavaField;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature;", "field", "Ljava/lang/reflect/Field;", "<init>", "(Ljava/lang/reflect/Field;)V", "getField", "()Ljava/lang/reflect/Field;", "asString", "", "kotlin-reflection"}
   )
   public static final class JavaField extends JvmPropertySignature {
      @NotNull
      private final Field field;

      public JavaField(@NotNull Field field) {
         Intrinsics.checkNotNullParameter(field, "field");
         super((DefaultConstructorMarker)null);
         this.field = field;
      }

      @NotNull
      public final Field getField() {
         return this.field;
      }

      @NotNull
      public String asString() {
         StringBuilder var10000 = new StringBuilder();
         String var10001 = this.field.getName();
         Intrinsics.checkNotNullExpressionValue(var10001, "getName(...)");
         var10000 = var10000.append(JvmAbi.getterName(var10001)).append("()");
         Class var1 = this.field.getType();
         Intrinsics.checkNotNullExpressionValue(var1, "getType(...)");
         return var10000.append(ReflectClassUtilKt.getDesc(var1)).toString();
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\b\u0010\n\u001a\u00020\u000bH\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\f"},
      d2 = {"Lkotlin/reflect/jvm/internal/JvmPropertySignature$JavaMethodProperty;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature;", "getterMethod", "Ljava/lang/reflect/Method;", "setterMethod", "<init>", "(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V", "getGetterMethod", "()Ljava/lang/reflect/Method;", "getSetterMethod", "asString", "", "kotlin-reflection"}
   )
   public static final class JavaMethodProperty extends JvmPropertySignature {
      @NotNull
      private final Method getterMethod;
      @Nullable
      private final Method setterMethod;

      public JavaMethodProperty(@NotNull Method getterMethod, @Nullable Method setterMethod) {
         Intrinsics.checkNotNullParameter(getterMethod, "getterMethod");
         super((DefaultConstructorMarker)null);
         this.getterMethod = getterMethod;
         this.setterMethod = setterMethod;
      }

      @NotNull
      public final Method getGetterMethod() {
         return this.getterMethod;
      }

      @Nullable
      public final Method getSetterMethod() {
         return this.setterMethod;
      }

      @NotNull
      public String asString() {
         return RuntimeTypeMapperKt.access$getSignature(this.getterMethod);
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\b\u0010\u001a\u001a\u00020\u0019H\u0002J\b\u0010\u001b\u001a\u00020\u0019H\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001c"},
      d2 = {"Lkotlin/reflect/jvm/internal/JvmPropertySignature$KotlinProperty;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature;", "descriptor", "Lkotlin/reflect/jvm/internal/impl/descriptors/PropertyDescriptor;", "proto", "Lkotlin/reflect/jvm/internal/impl/metadata/ProtoBuf$Property;", "signature", "Lkotlin/reflect/jvm/internal/impl/metadata/jvm/JvmProtoBuf$JvmPropertySignature;", "nameResolver", "Lkotlin/reflect/jvm/internal/impl/metadata/deserialization/NameResolver;", "typeTable", "Lkotlin/reflect/jvm/internal/impl/metadata/deserialization/TypeTable;", "<init>", "(Lorg/jetbrains/kotlin/descriptors/PropertyDescriptor;Lorg/jetbrains/kotlin/metadata/ProtoBuf$Property;Lorg/jetbrains/kotlin/metadata/jvm/JvmProtoBuf$JvmPropertySignature;Lorg/jetbrains/kotlin/metadata/deserialization/NameResolver;Lorg/jetbrains/kotlin/metadata/deserialization/TypeTable;)V", "getDescriptor", "()Lorg/jetbrains/kotlin/descriptors/PropertyDescriptor;", "getProto", "()Lorg/jetbrains/kotlin/metadata/ProtoBuf$Property;", "getSignature", "()Lorg/jetbrains/kotlin/metadata/jvm/JvmProtoBuf$JvmPropertySignature;", "getNameResolver", "()Lorg/jetbrains/kotlin/metadata/deserialization/NameResolver;", "getTypeTable", "()Lorg/jetbrains/kotlin/metadata/deserialization/TypeTable;", "string", "", "getManglingSuffix", "asString", "kotlin-reflection"}
   )
   @SourceDebugExtension({"SMAP\nRuntimeTypeMapper.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RuntimeTypeMapper.kt\nkotlin/reflect/jvm/internal/JvmPropertySignature$KotlinProperty\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,302:1\n1#2:303\n*E\n"})
   public static final class KotlinProperty extends JvmPropertySignature {
      @NotNull
      private final PropertyDescriptor descriptor;
      @NotNull
      private final ProtoBuf.Property proto;
      @NotNull
      private final JvmProtoBuf.JvmPropertySignature signature;
      @NotNull
      private final NameResolver nameResolver;
      @NotNull
      private final TypeTable typeTable;
      @NotNull
      private final String string;

      public KotlinProperty(@NotNull PropertyDescriptor descriptor, @NotNull ProtoBuf.Property proto, @NotNull JvmProtoBuf.JvmPropertySignature signature, @NotNull NameResolver nameResolver, @NotNull TypeTable typeTable) {
         Intrinsics.checkNotNullParameter(descriptor, "descriptor");
         Intrinsics.checkNotNullParameter(proto, "proto");
         Intrinsics.checkNotNullParameter(signature, "signature");
         Intrinsics.checkNotNullParameter(nameResolver, "nameResolver");
         Intrinsics.checkNotNullParameter(typeTable, "typeTable");
         super((DefaultConstructorMarker)null);
         this.descriptor = descriptor;
         this.proto = proto;
         this.signature = signature;
         this.nameResolver = nameResolver;
         this.typeTable = typeTable;
         String var10001;
         if (this.signature.hasGetter()) {
            var10001 = this.nameResolver.getString(this.signature.getGetter().getName()) + this.nameResolver.getString(this.signature.getGetter().getDesc());
         } else {
            JvmMemberSignature.Field var9 = JvmProtoBufUtil.getJvmFieldSignature$default(JvmProtoBufUtil.INSTANCE, this.proto, this.nameResolver, this.typeTable, false, 8, (Object)null);
            if (var9 == null) {
               throw new KotlinReflectionInternalError("No field signature for property: " + this.descriptor);
            }

            JvmMemberSignature.Field var6 = var9;
            String name = var6.component1();
            String desc = var6.component2();
            var10001 = JvmAbi.getterName(name) + this.getManglingSuffix() + "()" + desc;
         }

         this.string = var10001;
      }

      @NotNull
      public final PropertyDescriptor getDescriptor() {
         return this.descriptor;
      }

      @NotNull
      public final ProtoBuf.Property getProto() {
         return this.proto;
      }

      @NotNull
      public final JvmProtoBuf.JvmPropertySignature getSignature() {
         return this.signature;
      }

      @NotNull
      public final NameResolver getNameResolver() {
         return this.nameResolver;
      }

      @NotNull
      public final TypeTable getTypeTable() {
         return this.typeTable;
      }

      private final String getManglingSuffix() {
         DeclarationDescriptor var10000 = this.descriptor.getContainingDeclaration();
         Intrinsics.checkNotNullExpressionValue(var10000, "getContainingDeclaration(...)");
         DeclarationDescriptor containingDeclaration = var10000;
         if (Intrinsics.areEqual((Object)this.descriptor.getVisibility(), (Object)DescriptorVisibilities.INTERNAL) && containingDeclaration instanceof DeserializedClassDescriptor) {
            String var12;
            label24: {
               ProtoBuf.Class classProto = ((DeserializedClassDescriptor)containingDeclaration).getClassProto();
               GeneratedMessageLite.ExtendableMessage var10 = (GeneratedMessageLite.ExtendableMessage)classProto;
               GeneratedMessageLite.GeneratedExtension var10001 = JvmProtoBuf.classModuleName;
               Intrinsics.checkNotNullExpressionValue(var10001, "classModuleName");
               Integer var11 = (Integer)ProtoBufUtilKt.getExtensionOrNull(var10, var10001);
               if (var11 != null) {
                  Integer var4 = var11;
                  NameResolver var5 = this.nameResolver;
                  int p0 = ((Number)var4).intValue();
                  int var7 = false;
                  var12 = var5.getString(p0);
                  if (var12 != null) {
                     break label24;
                  }
               }

               var12 = "main";
            }

            String moduleName = var12;
            return '$' + NameUtils.sanitizeAsJavaIdentifier(moduleName);
         } else {
            if (Intrinsics.areEqual((Object)this.descriptor.getVisibility(), (Object)DescriptorVisibilities.PRIVATE) && containingDeclaration instanceof PackageFragmentDescriptor) {
               PropertyDescriptor var9 = this.descriptor;
               Intrinsics.checkNotNull(var9, "null cannot be cast to non-null type org.jetbrains.kotlin.serialization.deserialization.descriptors.DeserializedPropertyDescriptor");
               DeserializedContainerSource packagePartSource = ((DeserializedPropertyDescriptor)var9).getContainerSource();
               if (packagePartSource instanceof JvmPackagePartSource && ((JvmPackagePartSource)packagePartSource).getFacadeClassName() != null) {
                  return '$' + ((JvmPackagePartSource)packagePartSource).getSimpleName().asString();
               }
            }

            return "";
         }
      }

      @NotNull
      public String asString() {
         return this.string;
      }
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\b\u0010\n\u001a\u00020\u000bH\u0016R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\f"},
      d2 = {"Lkotlin/reflect/jvm/internal/JvmPropertySignature$MappedKotlinProperty;", "Lkotlin/reflect/jvm/internal/JvmPropertySignature;", "getterSignature", "Lkotlin/reflect/jvm/internal/JvmFunctionSignature$KotlinFunction;", "setterSignature", "<init>", "(Lkotlin/reflect/jvm/internal/JvmFunctionSignature$KotlinFunction;Lkotlin/reflect/jvm/internal/JvmFunctionSignature$KotlinFunction;)V", "getGetterSignature", "()Lkotlin/reflect/jvm/internal/JvmFunctionSignature$KotlinFunction;", "getSetterSignature", "asString", "", "kotlin-reflection"}
   )
   public static final class MappedKotlinProperty extends JvmPropertySignature {
      @NotNull
      private final JvmFunctionSignature.KotlinFunction getterSignature;
      @Nullable
      private final JvmFunctionSignature.KotlinFunction setterSignature;

      public MappedKotlinProperty(@NotNull JvmFunctionSignature.KotlinFunction getterSignature, @Nullable JvmFunctionSignature.KotlinFunction setterSignature) {
         Intrinsics.checkNotNullParameter(getterSignature, "getterSignature");
         super((DefaultConstructorMarker)null);
         this.getterSignature = getterSignature;
         this.setterSignature = setterSignature;
      }

      @NotNull
      public final JvmFunctionSignature.KotlinFunction getGetterSignature() {
         return this.getterSignature;
      }

      @Nullable
      public final JvmFunctionSignature.KotlinFunction getSetterSignature() {
         return this.setterSignature;
      }

      @NotNull
      public String asString() {
         return this.getterSignature.asString();
      }
   }
}
