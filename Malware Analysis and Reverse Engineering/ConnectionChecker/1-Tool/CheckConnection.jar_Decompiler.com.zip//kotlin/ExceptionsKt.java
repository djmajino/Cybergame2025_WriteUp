package kotlin;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/ExceptionsKt__ExceptionsKt"}
)
public final class ExceptionsKt extends ExceptionsKt__ExceptionsKt {
   private ExceptionsKt() {
   }
}
