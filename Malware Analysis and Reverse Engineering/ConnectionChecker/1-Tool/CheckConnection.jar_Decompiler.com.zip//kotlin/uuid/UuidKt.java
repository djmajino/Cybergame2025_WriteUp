package kotlin.uuid;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/uuid/UuidKt__UuidJVMKt", "kotlin/uuid/UuidKt__UuidKt"}
)
public final class UuidKt extends UuidKt__UuidKt {
   private UuidKt() {
   }
}
