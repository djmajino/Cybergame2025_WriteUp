package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\bg\u0018\u00002\u00020\u0001J\u000f\u0010\u0002\u001a\u00020\u0003H&¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\u0006\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\u0003H\u0096\u0002¢\u0006\u0004\b\b\u0010\tJ\u0018\u0010\n\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\u0003H\u0096\u0002¢\u0006\u0004\b\u000b\u0010\tJ\b\u0010\f\u001a\u00020\rH\u0016J\b\u0010\u000e\u001a\u00020\rH\u0016¨\u0006\u000f"},
   d2 = {"Lkotlin/time/TimeMark;", "", "elapsedNow", "Lkotlin/time/Duration;", "elapsedNow-UwyO8pc", "()J", "plus", "duration", "plus-LRDsOJo", "(J)Lkotlin/time/TimeMark;", "minus", "minus-LRDsOJo", "hasPassedNow", "", "hasNotPassedNow", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.9"
)
@WasExperimental(
   markerClass = {ExperimentalTime.class}
)
public interface TimeMark {
   long elapsedNow_UwyO8pc/* $FF was: elapsedNow-UwyO8pc*/();

   @NotNull
   TimeMark plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long var1);

   @NotNull
   TimeMark minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long var1);

   boolean hasPassedNow();

   boolean hasNotPassedNow();

   @Metadata(
      mv = {2, 1, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      @NotNull
      public static TimeMark plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(@NotNull TimeMark $this, long duration) {
         return (TimeMark)(new AdjustedTimeMark($this, duration, (DefaultConstructorMarker)null));
      }

      @NotNull
      public static TimeMark minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(@NotNull TimeMark $this, long duration) {
         return $this.plus-LRDsOJo(Duration.unaryMinus-UwyO8pc(duration));
      }

      public static boolean hasPassedNow(@NotNull TimeMark $this) {
         return !Duration.isNegative-impl($this.elapsedNow-UwyO8pc());
      }

      public static boolean hasNotPassedNow(@NotNull TimeMark $this) {
         return Duration.isNegative-impl($this.elapsedNow-UwyO8pc());
      }
   }
}
