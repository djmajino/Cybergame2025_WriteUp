package kotlin.time;

import java.io.Serializable;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.NotImplementedError;
import kotlin.ReplaceWith;
import kotlin.SinceKotlin;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0007\u0018\u0000 !2\b\u0012\u0004\u0012\u00020\u00000\u00012\u00060\u0002j\u0002`\u0003:\u0001!B\u0019\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u0006\u0010\u000e\u001a\u00020\u0005J\u0018\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0011H\u0086\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u0018\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0011H\u0086\u0002¢\u0006\u0004\b\u0015\u0010\u0013J\u0018\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0011\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u0000H\u0096\u0002J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u0016\u001a\u0004\u0018\u00010\u001cH\u0096\u0002J\b\u0010\u001d\u001a\u00020\u0007H\u0016J\b\u0010\u001e\u001a\u00020\u001fH\u0016J\b\u0010 \u001a\u00020\u001cH\u0002R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\""},
   d2 = {"Lkotlin/time/Instant;", "", "Ljava/io/Serializable;", "Lkotlin/io/Serializable;", "epochSeconds", "", "nanosecondsOfSecond", "", "<init>", "(JI)V", "getEpochSeconds", "()J", "getNanosecondsOfSecond", "()I", "toEpochMilliseconds", "plus", "duration", "Lkotlin/time/Duration;", "plus-LRDsOJo", "(J)Lkotlin/time/Instant;", "minus", "minus-LRDsOJo", "other", "minus-UwyO8pc", "(Lkotlin/time/Instant;)J", "compareTo", "equals", "", "", "hashCode", "toString", "", "writeReplace", "Companion", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "2.1"
)
@ExperimentalTime
@SourceDebugExtension({"SMAP\nInstant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instant.kt\nkotlin/time/Instant\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Instant.kt\nkotlin/time/InstantKt\n+ 4 Duration.kt\nkotlin/time/Duration\n*L\n1#1,799:1\n1#2:800\n738#3,14:801\n721#3,6:815\n738#3,14:821\n721#3,6:835\n721#3,6:842\n549#4:841\n*S KotlinDebug\n*F\n+ 1 Instant.kt\nkotlin/time/Instant\n*L\n148#1:801,14\n151#1:815,6\n159#1:821,14\n162#1:835,6\n186#1:842,6\n182#1:841\n*E\n"})
public final class Instant implements Comparable<Instant>, Serializable {
   @NotNull
   public static final Instant.Companion Companion = new Instant.Companion((DefaultConstructorMarker)null);
   private final long epochSeconds;
   private final int nanosecondsOfSecond;
   @NotNull
   private static final Instant MIN = new Instant(-31557014167219200L, 0);
   @NotNull
   private static final Instant MAX = new Instant(31556889864403199L, 999999999);

   public Instant(long epochSeconds, int nanosecondsOfSecond) {
      this.epochSeconds = epochSeconds;
      this.nanosecondsOfSecond = nanosecondsOfSecond;
      long var4 = this.epochSeconds;
      if (!(-31557014167219200L <= var4 ? var4 < 31556889864403200L : false)) {
         int var5 = false;
         String var6 = "Instant exceeds minimum or maximum instant";
         throw new IllegalArgumentException(var6.toString());
      }
   }

   public final long getEpochSeconds() {
      return this.epochSeconds;
   }

   public final int getNanosecondsOfSecond() {
      return this.nanosecondsOfSecond;
   }

   public final long toEpochMilliseconds() {
      long var10000;
      long millis;
      long a$iv;
      long b$iv;
      long sum$iv;
      boolean $i$f$safeMultiplyOrElse;
      long total$iv;
      boolean var10;
      boolean $i$f$safeAddOrElse;
      boolean var12;
      if (this.epochSeconds >= 0L) {
         a$iv = this.epochSeconds;
         b$iv = 1000L;
         $i$f$safeMultiplyOrElse = false;
         if (b$iv == 1L) {
            var10000 = a$iv;
         } else if (a$iv == 1L) {
            var10000 = b$iv;
         } else if (a$iv != 0L && b$iv != 0L) {
            total$iv = a$iv * b$iv;
            if (total$iv / b$iv != a$iv || a$iv == Long.MIN_VALUE && b$iv == -1L || b$iv == Long.MIN_VALUE && a$iv == -1L) {
               var10 = false;
               return Long.MAX_VALUE;
            }

            var10000 = total$iv;
         } else {
            var10000 = 0L;
         }

         millis = var10000;
         a$iv = (long)(this.nanosecondsOfSecond / 1000000);
         $i$f$safeAddOrElse = false;
         sum$iv = millis + a$iv;
         if ((millis ^ sum$iv) < 0L && (millis ^ a$iv) >= 0L) {
            var12 = false;
            return Long.MAX_VALUE;
         } else {
            return sum$iv;
         }
      } else {
         a$iv = this.epochSeconds + 1L;
         b$iv = 1000L;
         $i$f$safeMultiplyOrElse = false;
         if (b$iv == 1L) {
            var10000 = a$iv;
         } else if (a$iv == 1L) {
            var10000 = b$iv;
         } else if (a$iv != 0L && b$iv != 0L) {
            total$iv = a$iv * b$iv;
            if (total$iv / b$iv != a$iv || a$iv == Long.MIN_VALUE && b$iv == -1L || b$iv == Long.MIN_VALUE && a$iv == -1L) {
               var10 = false;
               return Long.MIN_VALUE;
            }

            var10000 = total$iv;
         } else {
            var10000 = 0L;
         }

         millis = var10000;
         a$iv = (long)(this.nanosecondsOfSecond / 1000000 - 1000);
         $i$f$safeAddOrElse = false;
         sum$iv = millis + a$iv;
         if ((millis ^ sum$iv) < 0L && (millis ^ a$iv) >= 0L) {
            var12 = false;
            return Long.MIN_VALUE;
         } else {
            return sum$iv;
         }
      }
   }

   @NotNull
   public final Instant plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long duration) {
      int var3 = false;
      long var10000 = Duration.getInWholeSeconds-impl(duration);
      int nanosecondsToAdd = Duration.getNanosecondsComponent-impl(duration);
      long secondsToAdd = var10000;
      int var7 = false;
      if (secondsToAdd == 0L && nanosecondsToAdd == 0) {
         return this;
      } else {
         long a$iv = this.epochSeconds;
         int $i$f$safeAddOrElse = false;
         long sum$iv = a$iv + secondsToAdd;
         if ((a$iv ^ sum$iv) < 0L && (a$iv ^ secondsToAdd) >= 0L) {
            int var13 = false;
            return Duration.isPositive-impl(duration) ? MAX : MIN;
         } else {
            int nanoAdjustment = this.nanosecondsOfSecond + nanosecondsToAdd;
            return Companion.fromEpochSeconds(sum$iv, nanoAdjustment);
         }
      }
   }

   @NotNull
   public final Instant minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long duration) {
      return this.plus-LRDsOJo(Duration.unaryMinus-UwyO8pc(duration));
   }

   public final long minus_UwyO8pc/* $FF was: minus-UwyO8pc*/(@NotNull Instant other) {
      Intrinsics.checkNotNullParameter(other, "other");
      Duration.Companion var10000 = Duration.Companion;
      long var2 = DurationKt.toDuration(this.epochSeconds - other.epochSeconds, DurationUnit.SECONDS);
      Duration.Companion var10001 = Duration.Companion;
      return Duration.plus-LRDsOJo(var2, DurationKt.toDuration(this.nanosecondsOfSecond - other.nanosecondsOfSecond, DurationUnit.NANOSECONDS));
   }

   public int compareTo(@NotNull Instant other) {
      Intrinsics.checkNotNullParameter(other, "other");
      int s = Intrinsics.compare(this.epochSeconds, other.epochSeconds);
      return s != 0 ? s : Intrinsics.compare(this.nanosecondsOfSecond, other.nanosecondsOfSecond);
   }

   public boolean equals(@Nullable Object other) {
      return this == other || other instanceof Instant && this.epochSeconds == ((Instant)other).epochSeconds && this.nanosecondsOfSecond == ((Instant)other).nanosecondsOfSecond;
   }

   public int hashCode() {
      return Long.hashCode(this.epochSeconds) + 51 * this.nanosecondsOfSecond;
   }

   @NotNull
   public String toString() {
      return InstantKt.access$formatIso(this);
   }

   private final Object writeReplace() {
      return InstantJvmKt.serializedInstant(this);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\n\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0007J\u000e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bJ\u0018\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\bJ\u0016\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u000fR\u0011\u0010\u0010\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0013\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0012R\u0014\u0010\u0015\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0012R\u0014\u0010\u0017\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0012¨\u0006\u0019"},
      d2 = {"Lkotlin/time/Instant$Companion;", "", "<init>", "()V", "now", "Lkotlin/time/Instant;", "fromEpochMilliseconds", "epochMilliseconds", "", "fromEpochSeconds", "epochSeconds", "nanosecondAdjustment", "", "parse", "input", "", "DISTANT_PAST", "getDISTANT_PAST", "()Lkotlin/time/Instant;", "DISTANT_FUTURE", "getDISTANT_FUTURE", "MIN", "getMIN$kotlin_stdlib", "MAX", "getMAX$kotlin_stdlib", "kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nInstant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instant.kt\nkotlin/time/Instant$Companion\n+ 2 Instant.kt\nkotlin/time/InstantKt\n*L\n1#1,799:1\n721#2,6:800\n*S KotlinDebug\n*F\n+ 1 Instant.kt\nkotlin/time/Instant$Companion\n*L\n308#1:800,6\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      /** @deprecated */
      @Deprecated(
         message = "Use Clock.System.now() instead",
         replaceWith = @ReplaceWith(
   expression = "Clock.System.now()",
   imports = {"kotlin.time.Clock"}
),
         level = DeprecationLevel.ERROR
      )
      @NotNull
      public final Instant now() {
         throw new NotImplementedError((String)null, 1, (DefaultConstructorMarker)null);
      }

      @NotNull
      public final Instant fromEpochMilliseconds(long epochMilliseconds) {
         long var7 = 1000L;
         long var9 = epochMilliseconds / var7;
         if ((epochMilliseconds ^ var7) < 0L && var9 * var7 != epochMilliseconds) {
            var9 += -1L;
         }

         long var8 = 1000L;
         long var10 = epochMilliseconds % var8;
         int nanosecondsOfSecond = (int)((var10 + (var8 & ((var10 ^ var8) & (var10 | -var10)) >> 63)) * (long)1000000);
         return var9 < -31557014167219200L ? this.getMIN$kotlin_stdlib() : (var9 > 31556889864403199L ? this.getMAX$kotlin_stdlib() : this.fromEpochSeconds(var9, nanosecondsOfSecond));
      }

      @NotNull
      public final Instant fromEpochSeconds(long epochSeconds, long nanosecondAdjustment) {
         long var9 = 1000000000L;
         long var11 = nanosecondAdjustment / var9;
         if ((nanosecondAdjustment ^ var9) < 0L && var11 * var9 != nanosecondAdjustment) {
            var11 += -1L;
         }

         int $i$f$safeAddOrElse = false;
         long sum$iv = epochSeconds + var11;
         if ((epochSeconds ^ sum$iv) < 0L && (epochSeconds ^ var11) >= 0L) {
            int var14 = false;
            return epochSeconds > 0L ? Instant.Companion.getMAX$kotlin_stdlib() : Instant.Companion.getMIN$kotlin_stdlib();
         } else {
            long seconds = sum$iv;
            Instant var10000;
            if (sum$iv < -31557014167219200L) {
               var10000 = this.getMIN$kotlin_stdlib();
            } else if (sum$iv > 31556889864403199L) {
               var10000 = this.getMAX$kotlin_stdlib();
            } else {
               sum$iv = 1000000000L;
               long var12 = nanosecondAdjustment % sum$iv;
               int nanoseconds = (int)(var12 + (sum$iv & ((var12 ^ sum$iv) & (var12 | -var12)) >> 63));
               var10000 = new Instant(seconds, nanoseconds);
            }

            return var10000;
         }
      }

      // $FF: synthetic method
      public static Instant fromEpochSeconds$default(Instant.Companion var0, long var1, long var3, int var5, Object var6) {
         if ((var5 & 2) != 0) {
            var3 = 0L;
         }

         return var0.fromEpochSeconds(var1, var3);
      }

      @NotNull
      public final Instant fromEpochSeconds(long epochSeconds, int nanosecondAdjustment) {
         return this.fromEpochSeconds(epochSeconds, (long)nanosecondAdjustment);
      }

      @NotNull
      public final Instant parse(@NotNull CharSequence input) {
         Intrinsics.checkNotNullParameter(input, "input");
         return InstantKt.access$parseIso(input);
      }

      @NotNull
      public final Instant getDISTANT_PAST() {
         return this.fromEpochSeconds(-3217862419201L, 999999999);
      }

      @NotNull
      public final Instant getDISTANT_FUTURE() {
         return this.fromEpochSeconds(3093527980800L, 0);
      }

      @NotNull
      public final Instant getMIN$kotlin_stdlib() {
         return Instant.MIN;
      }

      @NotNull
      public final Instant getMAX$kotlin_stdlib() {
         return Instant.MAX;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
