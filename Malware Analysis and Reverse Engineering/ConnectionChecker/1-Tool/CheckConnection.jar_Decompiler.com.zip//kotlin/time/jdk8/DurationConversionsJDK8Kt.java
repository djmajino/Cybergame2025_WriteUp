package kotlin.time.jdk8;

import java.time.Duration;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.internal.InlineOnly;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.time.DurationKt;
import kotlin.time.DurationUnit;
import kotlin.time.ExperimentalTime;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0087\b¢\u0006\u0002\u0010\u0003\u001a\u0014\u0010\u0004\u001a\u00020\u0002*\u00020\u0001H\u0087\b¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
   d2 = {"toKotlinDuration", "Lkotlin/time/Duration;", "Ljava/time/Duration;", "(Ljava/time/Duration;)J", "toJavaDuration", "toJavaDuration-LRDsOJo", "(J)Ljava/time/Duration;", "kotlin-stdlib-jdk8"},
   pn = "kotlin.time"
)
@JvmName(
   name = "DurationConversionsJDK8Kt"
)
@SourceDebugExtension({"SMAP\nDurationConversions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DurationConversions.kt\nkotlin/time/jdk8/DurationConversionsJDK8Kt\n+ 2 Duration.kt\nkotlin/time/Duration\n*L\n1#1,35:1\n549#2:36\n*S KotlinDebug\n*F\n+ 1 DurationConversions.kt\nkotlin/time/jdk8/DurationConversionsJDK8Kt\n*L\n35#1:36\n*E\n"})
public final class DurationConversionsJDK8Kt {
   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @InlineOnly
   private static final long toKotlinDuration(Duration $this$toKotlinDuration) {
      Intrinsics.checkNotNullParameter($this$toKotlinDuration, "<this>");
      return kotlin.time.Duration.plus-LRDsOJo(DurationKt.toDuration($this$toKotlinDuration.getSeconds(), DurationUnit.SECONDS), DurationKt.toDuration($this$toKotlinDuration.getNano(), DurationUnit.NANOSECONDS));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @InlineOnly
   private static final Duration toJavaDuration_LRDsOJo/* $FF was: toJavaDuration-LRDsOJo*/(long $this$toJavaDuration_u2dLRDsOJo) {
      int var2 = false;
      long var10000 = kotlin.time.Duration.getInWholeSeconds-impl($this$toJavaDuration_u2dLRDsOJo);
      int nanoseconds = kotlin.time.Duration.getNanosecondsComponent-impl($this$toJavaDuration_u2dLRDsOJo);
      long seconds = var10000;
      int var6 = false;
      Duration var7 = Duration.ofSeconds(seconds, (long)nanoseconds);
      Intrinsics.checkNotNullExpressionValue(var7, "toComponents-impl(...)");
      return var7;
   }
}
