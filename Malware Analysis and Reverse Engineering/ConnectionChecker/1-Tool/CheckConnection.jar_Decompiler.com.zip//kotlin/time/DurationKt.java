package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.math.MathKt;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000:\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0006\n\u0002\b\t\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\f\n\u0002\b\u0015\u001a\u0019\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004H\u0007¢\u0006\u0002\u0010\u0005\u001a\u0019\u0010\u0000\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u0004H\u0007¢\u0006\u0002\u0010\u0007\u001a\u0019\u0010\u0000\u001a\u00020\u0001*\u00020\b2\u0006\u0010\u0003\u001a\u00020\u0004H\u0007¢\u0006\u0002\u0010\t\u001a\u001c\u0010\n\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u000b\u001a\u00020\u0001H\u0087\n¢\u0006\u0004\b\f\u0010\r\u001a\u001c\u0010\n\u001a\u00020\u0001*\u00020\b2\u0006\u0010\u000b\u001a\u00020\u0001H\u0087\n¢\u0006\u0004\b\u000e\u0010\u000f\u001a\u001d\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0002¢\u0006\u0002\u0010\u0015\u001a\u0010\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u0012H\u0002\u001a)\u0010\u0017\u001a\u00020\u0012*\u00020\u00122\u0006\u0010\u0018\u001a\u00020\u00022\u0012\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00140\u001aH\u0082\b\u001a)\u0010\u001c\u001a\u00020\u0002*\u00020\u00122\u0006\u0010\u0018\u001a\u00020\u00022\u0012\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u00140\u001aH\u0082\b\u001a\u0010\u0010!\u001a\u00020\u00062\u0006\u0010\"\u001a\u00020\u0006H\u0002\u001a\u0010\u0010#\u001a\u00020\u00062\u0006\u0010$\u001a\u00020\u0006H\u0002\u001a\u0015\u0010%\u001a\u00020\u00012\u0006\u0010&\u001a\u00020\u0006H\u0002¢\u0006\u0002\u0010'\u001a\u0015\u0010(\u001a\u00020\u00012\u0006\u0010)\u001a\u00020\u0006H\u0002¢\u0006\u0002\u0010'\u001a\u001d\u0010*\u001a\u00020\u00012\u0006\u0010+\u001a\u00020\u00062\u0006\u0010,\u001a\u00020\u0002H\u0002¢\u0006\u0002\u0010-\u001a\u0015\u0010.\u001a\u00020\u00012\u0006\u0010\"\u001a\u00020\u0006H\u0002¢\u0006\u0002\u0010'\u001a\u0015\u0010/\u001a\u00020\u00012\u0006\u0010$\u001a\u00020\u0006H\u0002¢\u0006\u0002\u0010'\"\u000e\u0010\u001d\u001a\u00020\u0002X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001e\u001a\u00020\u0006X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001f\u001a\u00020\u0006X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010 \u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000¨\u00060"},
   d2 = {"toDuration", "Lkotlin/time/Duration;", "", "unit", "Lkotlin/time/DurationUnit;", "(ILkotlin/time/DurationUnit;)J", "", "(JLkotlin/time/DurationUnit;)J", "", "(DLkotlin/time/DurationUnit;)J", "times", "duration", "times-mvk6XK0", "(IJ)J", "times-kIfJnKk", "(DJ)J", "parseDuration", "value", "", "strictIso", "", "(Ljava/lang/String;Z)J", "parseOverLongIsoComponent", "substringWhile", "startIndex", "predicate", "Lkotlin/Function1;", "", "skipWhile", "NANOS_IN_MILLIS", "MAX_NANOS", "MAX_MILLIS", "MAX_NANOS_IN_MILLIS", "nanosToMillis", "nanos", "millisToNanos", "millis", "durationOfNanos", "normalNanos", "(J)J", "durationOfMillis", "normalMillis", "durationOf", "normalValue", "unitDiscriminator", "(JI)J", "durationOfNanosNormalized", "durationOfMillisNormalized", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nDuration.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Duration.kt\nkotlin/time/DurationKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1068:1\n1021#1,6:1070\n1024#1,3:1076\n1021#1,6:1079\n1021#1,6:1085\n1024#1,3:1091\n1#2:1069\n*S KotlinDebug\n*F\n+ 1 Duration.kt\nkotlin/time/DurationKt\n*L\n936#1:1070,6\n970#1:1076,3\n973#1:1079,6\n976#1:1085,6\n1021#1:1091,3\n*E\n"})
public final class DurationKt {
   public static final int NANOS_IN_MILLIS = 1000000;
   public static final long MAX_NANOS = 4611686018426999999L;
   public static final long MAX_MILLIS = 4611686018427387903L;
   private static final long MAX_NANOS_IN_MILLIS = 4611686018426L;

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public static final long toDuration(int $this$toDuration, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      return unit.compareTo((Enum)DurationUnit.SECONDS) <= 0 ? durationOfNanos(DurationUnitKt.convertDurationUnitOverflow((long)$this$toDuration, unit, DurationUnit.NANOSECONDS)) : toDuration((long)$this$toDuration, unit);
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public static final long toDuration(long $this$toDuration, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      long maxNsInUnit = DurationUnitKt.convertDurationUnitOverflow(4611686018426999999L, DurationUnit.NANOSECONDS, unit);
      if (-maxNsInUnit <= $this$toDuration ? $this$toDuration <= maxNsInUnit : false) {
         return durationOfNanos(DurationUnitKt.convertDurationUnitOverflow($this$toDuration, unit, DurationUnit.NANOSECONDS));
      } else {
         long millis = DurationUnitKt.convertDurationUnit($this$toDuration, unit, DurationUnit.MILLISECONDS);
         return durationOfMillis(RangesKt.coerceIn(millis, -4611686018427387903L, 4611686018427387903L));
      }
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public static final long toDuration(double $this$toDuration, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      double valueInNs = DurationUnitKt.convertDurationUnit($this$toDuration, unit, DurationUnit.NANOSECONDS);
      if (Double.isNaN(valueInNs)) {
         int var6 = false;
         String var9 = "Duration value cannot be NaN.";
         throw new IllegalArgumentException(var9.toString());
      } else {
         long nanos = MathKt.roundToLong(valueInNs);
         long var10000;
         if (-4611686018426999999L <= nanos ? nanos < 4611686018427000000L : false) {
            var10000 = durationOfNanos(nanos);
         } else {
            long millis = MathKt.roundToLong(DurationUnitKt.convertDurationUnit($this$toDuration, unit, DurationUnit.MILLISECONDS));
            var10000 = durationOfMillisNormalized(millis);
         }

         return var10000;
      }
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @InlineOnly
   private static final long times_mvk6XK0/* $FF was: times-mvk6XK0*/(int $this$times_u2dmvk6XK0, long duration) {
      return Duration.times-UwyO8pc(duration, $this$times_u2dmvk6XK0);
   }

   @SinceKotlin(
      version = "1.6"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @InlineOnly
   private static final long times_kIfJnKk/* $FF was: times-kIfJnKk*/(double $this$times_u2dkIfJnKk, long duration) {
      return Duration.times-UwyO8pc(duration, $this$times_u2dkIfJnKk);
   }

   private static final long parseDuration(String value, boolean strictIso) {
      int length = value.length();
      if (length == 0) {
         throw new IllegalArgumentException("The string is empty");
      } else {
         int index = 0;
         long result = Duration.Companion.getZERO-UwyO8pc();
         String infinityString = "Infinity";
         switch(value.charAt(index)) {
         case '+':
         case '-':
            ++index;
         case ',':
         default:
            boolean hasSign = index > 0;
            boolean isNegative = hasSign && StringsKt.startsWith$default((CharSequence)value, '-', false, 2, (Object)null);
            if (length <= index) {
               throw new IllegalArgumentException("No components");
            } else {
               boolean isTimeComponent;
               String component;
               boolean $i$f$substringWhile;
               int dotIndex;
               String whole;
               String var10000;
               boolean $i$f$skipWhile;
               String var10001;
               int i$iv$iv;
               char it;
               boolean var20;
               DurationUnit unit;
               boolean var31;
               byte var33;
               if (value.charAt(index) != 'P') {
                  if (strictIso) {
                     throw new IllegalArgumentException();
                  }

                  if (StringsKt.regionMatches(value, index, infinityString, 0, Math.max(length - index, infinityString.length()), true)) {
                     result = Duration.Companion.getINFINITE-UwyO8pc();
                  } else {
                     DurationUnit prevUnit = null;
                     isTimeComponent = false;
                     boolean allowSpaces = !hasSign;
                     if (hasSign && value.charAt(index) == '(' && StringsKt.last((CharSequence)value) == ')') {
                        allowSpaces = true;
                        ++index;
                        --length;
                        if (index == length) {
                           throw new IllegalArgumentException("No components");
                        }
                     }

                     while(index < length) {
                        if (isTimeComponent && allowSpaces) {
                           component = value;
                           int $i$f$skipWhile = false;

                           int i$iv;
                           for(i$iv = index; i$iv < component.length(); ++i$iv) {
                              char it = component.charAt(i$iv);
                              var31 = false;
                              if (it != ' ') {
                                 break;
                              }
                           }

                           index = i$iv;
                        }

                        isTimeComponent = true;
                        $i$f$substringWhile = false;
                        whole = value;
                        $i$f$skipWhile = false;

                        for(i$iv$iv = index; i$iv$iv < whole.length(); ++i$iv$iv) {
                           it = whole.charAt(i$iv$iv);
                           var20 = false;
                           if (!('0' <= it ? it < ':' : false) && it != '.') {
                              break;
                           }
                        }

                        Intrinsics.checkNotNull(value, "null cannot be cast to non-null type java.lang.String");
                        var10000 = value.substring(index, i$iv$iv);
                        Intrinsics.checkNotNullExpressionValue(var10000, "substring(...)");
                        component = var10000;
                        if (((CharSequence)component).length() == 0) {
                           throw new IllegalArgumentException();
                        }

                        index += component.length();
                        int $i$f$substringWhile = false;
                        String $this$skipWhile$iv$iv = value;
                        int $i$f$skipWhile = false;

                        int i$iv$iv;
                        for(i$iv$iv = index; i$iv$iv < $this$skipWhile$iv$iv.length(); ++i$iv$iv) {
                           char it = $this$skipWhile$iv$iv.charAt(i$iv$iv);
                           int var21 = false;
                           if (!('a' <= it ? it < '{' : false)) {
                              break;
                           }
                        }

                        Intrinsics.checkNotNull(value, "null cannot be cast to non-null type java.lang.String");
                        var10000 = value.substring(index, i$iv$iv);
                        Intrinsics.checkNotNullExpressionValue(var10000, "substring(...)");
                        String unitName = var10000;
                        index += unitName.length();
                        unit = DurationUnitKt.durationUnitByShortName(unitName);
                        if (prevUnit != null && prevUnit.compareTo((Enum)unit) <= 0) {
                           throw new IllegalArgumentException("Unexpected order of duration components");
                        }

                        prevUnit = unit;
                        dotIndex = StringsKt.indexOf$default((CharSequence)component, '.', 0, false, 6, (Object)null);
                        if (dotIndex > 0) {
                           var33 = 0;
                           Intrinsics.checkNotNull(component, "null cannot be cast to non-null type java.lang.String");
                           var10000 = component.substring(var33, dotIndex);
                           Intrinsics.checkNotNullExpressionValue(var10000, "substring(...)");
                           whole = var10000;
                           result = Duration.plus-LRDsOJo(result, toDuration(Long.parseLong(whole), unit));
                           Intrinsics.checkNotNull(component, "null cannot be cast to non-null type java.lang.String");
                           var10001 = component.substring(dotIndex);
                           Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
                           result = Duration.plus-LRDsOJo(result, toDuration(Double.parseDouble(var10001), unit));
                           if (index < length) {
                              throw new IllegalArgumentException("Fractional component must be last");
                           }
                        } else {
                           result = Duration.plus-LRDsOJo(result, toDuration(Long.parseLong(component), unit));
                        }
                     }
                  }
               } else {
                  ++index;
                  if (index == length) {
                     throw new IllegalArgumentException();
                  }

                  String nonDigitSymbols = "+-.";
                  isTimeComponent = false;
                  DurationUnit prevUnit = null;

                  while(true) {
                     while(index < length) {
                        if (value.charAt(index) == 'T') {
                           if (isTimeComponent) {
                              throw new IllegalArgumentException();
                           }

                           ++index;
                           if (index == length) {
                              throw new IllegalArgumentException();
                           }

                           isTimeComponent = true;
                        } else {
                           $i$f$substringWhile = false;
                           whole = value;
                           $i$f$skipWhile = false;

                           for(i$iv$iv = index; i$iv$iv < whole.length(); ++i$iv$iv) {
                              it = whole.charAt(i$iv$iv);
                              var20 = false;
                              if (!('0' <= it ? it < ':' : false) && !StringsKt.contains$default((CharSequence)nonDigitSymbols, it, false, 2, (Object)null)) {
                                 break;
                              }
                           }

                           Intrinsics.checkNotNull(value, "null cannot be cast to non-null type java.lang.String");
                           var10000 = value.substring(index, i$iv$iv);
                           Intrinsics.checkNotNullExpressionValue(var10000, "substring(...)");
                           component = var10000;
                           if (((CharSequence)component).length() == 0) {
                              throw new IllegalArgumentException();
                           }

                           index += component.length();
                           CharSequence var26 = (CharSequence)value;
                           if (!(0 <= index ? index < var26.length() : false)) {
                              var31 = false;
                              throw new IllegalArgumentException("Missing unit for value " + component);
                           }

                           char unitChar = var26.charAt(index);
                           ++index;
                           unit = DurationUnitKt.durationUnitByIsoChar(unitChar, isTimeComponent);
                           if (prevUnit != null && prevUnit.compareTo((Enum)unit) <= 0) {
                              throw new IllegalArgumentException("Unexpected order of duration components");
                           }

                           prevUnit = unit;
                           dotIndex = StringsKt.indexOf$default((CharSequence)component, '.', 0, false, 6, (Object)null);
                           if (unit == DurationUnit.SECONDS && dotIndex > 0) {
                              var33 = 0;
                              Intrinsics.checkNotNull(component, "null cannot be cast to non-null type java.lang.String");
                              var10000 = component.substring(var33, dotIndex);
                              Intrinsics.checkNotNullExpressionValue(var10000, "substring(...)");
                              whole = var10000;
                              result = Duration.plus-LRDsOJo(result, toDuration(parseOverLongIsoComponent(whole), unit));
                              Intrinsics.checkNotNull(component, "null cannot be cast to non-null type java.lang.String");
                              var10001 = component.substring(dotIndex);
                              Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
                              result = Duration.plus-LRDsOJo(result, toDuration(Double.parseDouble(var10001), unit));
                           } else {
                              result = Duration.plus-LRDsOJo(result, toDuration(parseOverLongIsoComponent(component), unit));
                           }
                        }
                     }

                     return isNegative ? Duration.unaryMinus-UwyO8pc(result) : result;
                  }
               }

               return isNegative ? Duration.unaryMinus-UwyO8pc(result) : result;
            }
         }
      }
   }

   private static final long parseOverLongIsoComponent(String value) {
      int length = value.length();
      int startIndex = 0;
      if (length > 0 && StringsKt.contains$default((CharSequence)"+-", value.charAt(0), false, 2, (Object)null)) {
         ++startIndex;
      }

      if (length - startIndex > 16) {
         int var3 = false;
         int firstNonZero = startIndex;
         int index = startIndex;

         while(true) {
            if (index >= length) {
               if (length - firstNonZero > 16) {
                  return value.charAt(0) == '-' ? Long.MIN_VALUE : Long.MAX_VALUE;
               }
               break;
            }

            char var6 = value.charAt(index);
            if (var6 == '0') {
               if (firstNonZero == index) {
                  ++firstNonZero;
               }
            } else if (!('1' <= var6 ? var6 < ':' : false)) {
               break;
            }

            ++index;
         }
      }

      long var10000;
      if (StringsKt.startsWith$default(value, "+", false, 2, (Object)null) && length > 1) {
         char var7 = value.charAt(1);
         if ('0' <= var7 ? var7 < ':' : false) {
            var10000 = Long.parseLong(StringsKt.drop(value, 1));
            return var10000;
         }
      }

      var10000 = Long.parseLong(value);
      return var10000;
   }

   private static final String substringWhile(String $this$substringWhile, int startIndex, Function1<? super Character, Boolean> predicate) {
      int $i$f$substringWhile = false;
      String $this$skipWhile$iv = $this$substringWhile;
      int $i$f$skipWhile = false;

      int i$iv;
      for(i$iv = startIndex; i$iv < $this$skipWhile$iv.length() && (Boolean)predicate.invoke($this$skipWhile$iv.charAt(i$iv)); ++i$iv) {
      }

      Intrinsics.checkNotNull($this$substringWhile, "null cannot be cast to non-null type java.lang.String");
      String var10000 = $this$substringWhile.substring(startIndex, i$iv);
      Intrinsics.checkNotNullExpressionValue(var10000, "substring(...)");
      return var10000;
   }

   private static final int skipWhile(String $this$skipWhile, int startIndex, Function1<? super Character, Boolean> predicate) {
      int $i$f$skipWhile = false;

      int i;
      for(i = startIndex; i < $this$skipWhile.length() && (Boolean)predicate.invoke($this$skipWhile.charAt(i)); ++i) {
      }

      return i;
   }

   private static final long nanosToMillis(long nanos) {
      return nanos / (long)1000000;
   }

   private static final long millisToNanos(long millis) {
      return millis * (long)1000000;
   }

   private static final long durationOfNanos(long normalNanos) {
      return Duration.constructor-impl(normalNanos << 1);
   }

   private static final long durationOfMillis(long normalMillis) {
      return Duration.constructor-impl((normalMillis << 1) + 1L);
   }

   private static final long durationOf(long normalValue, int unitDiscriminator) {
      return Duration.constructor-impl((normalValue << 1) + (long)unitDiscriminator);
   }

   private static final long durationOfNanosNormalized(long nanos) {
      return (-4611686018426999999L <= nanos ? nanos < 4611686018427000000L : false) ? durationOfNanos(nanos) : durationOfMillis(nanosToMillis(nanos));
   }

   private static final long durationOfMillisNormalized(long millis) {
      return (-4611686018426L <= millis ? millis < 4611686018427L : false) ? durationOfNanos(millisToNanos(millis)) : durationOfMillis(RangesKt.coerceIn(millis, -4611686018427387903L, 4611686018427387903L));
   }

   // $FF: synthetic method
   public static final long access$parseDuration(String value, boolean strictIso) {
      return parseDuration(value, strictIso);
   }

   // $FF: synthetic method
   public static final long access$durationOf(long normalValue, int unitDiscriminator) {
      return durationOf(normalValue, unitDiscriminator);
   }

   // $FF: synthetic method
   public static final long access$durationOfNanosNormalized(long nanos) {
      return durationOfNanosNormalized(nanos);
   }

   // $FF: synthetic method
   public static final long access$durationOfMillisNormalized(long millis) {
      return durationOfMillisNormalized(millis);
   }

   // $FF: synthetic method
   public static final long access$nanosToMillis(long nanos) {
      return nanosToMillis(nanos);
   }

   // $FF: synthetic method
   public static final long access$millisToNanos(long millis) {
      return millisToNanos(millis);
   }

   // $FF: synthetic method
   public static final long access$durationOfNanos(long normalNanos) {
      return durationOfNanos(normalNanos);
   }

   // $FF: synthetic method
   public static final long access$durationOfMillis(long normalMillis) {
      return durationOfMillis(normalMillis);
   }
}
