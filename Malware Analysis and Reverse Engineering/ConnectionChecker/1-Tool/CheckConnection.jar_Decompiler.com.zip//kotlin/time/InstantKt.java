package kotlin.time;

import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000@\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\r\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\b\f\n\u0002\u0010\u0015\n\u0002\b\u0006\u001a\u0010\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u000fH\u0003\u001a\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0002H\u0003\u001a'\u0010\u0016\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0018\u001a\u00020\t2\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aH\u0082\b\u001a'\u0010\u001c\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0018\u001a\u00020\t2\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aH\u0082\b\u001a\u0010\u0010$\u001a\u00020\u00012\u0006\u0010%\u001a\u00020\u0014H\u0000\u001a\u0014\u0010&\u001a\u00020\u0014*\u00020\u00142\u0006\u0010$\u001a\u00020\u0001H\u0002\u001a\u0014\u0010,\u001a\u00020\u0011*\u00020\u000f2\u0006\u0010-\u001a\u00020\u0014H\u0002\"\u001f\u0010\u0000\u001a\u00020\u0001*\u00020\u00028Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0000\u0010\u0005\"\u001f\u0010\u0006\u001a\u00020\u0001*\u00020\u00028Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0007\u0010\u0004\u001a\u0004\b\u0006\u0010\u0005\"\u000e\u0010\b\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000b\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\f\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0013\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0015\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001d\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001e\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001f\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010 \u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010!\u001a\u00020\u0014X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010\"\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010#\u001a\u00020\u0014X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010'\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010)\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010*\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010+\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006."},
   d2 = {"isDistantPast", "", "Lkotlin/time/Instant;", "isDistantPast$annotations", "(Lkotlin/time/Instant;)V", "(Lkotlin/time/Instant;)Z", "isDistantFuture", "isDistantFuture$annotations", "DISTANT_PAST_SECONDS", "", "DISTANT_FUTURE_SECONDS", "MIN_SECOND", "MAX_SECOND", "parseIso", "isoString", "", "formatIso", "", "instant", "DAYS_PER_CYCLE", "", "DAYS_0000_TO_1970", "safeAddOrElse", "a", "b", "action", "Lkotlin/Function0;", "", "safeMultiplyOrElse", "SECONDS_PER_HOUR", "SECONDS_PER_MINUTE", "HOURS_PER_DAY", "SECONDS_PER_DAY", "NANOS_PER_SECOND", "NANOS_PER_MILLI", "MILLIS_PER_SECOND", "isLeapYear", "year", "monthLength", "POWERS_OF_TEN", "", "asciiDigitPositionsInIsoStringAfterYear", "colonsInIsoOffsetString", "asciiDigitsInIsoOffsetString", "truncateForErrorMessage", "maxLength", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nInstant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instant.kt\nkotlin/time/InstantKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,799:1\n1#2:800\n*E\n"})
public final class InstantKt {
   private static final long DISTANT_PAST_SECONDS = -3217862419201L;
   private static final long DISTANT_FUTURE_SECONDS = 3093527980800L;
   private static final long MIN_SECOND = -31557014167219200L;
   private static final long MAX_SECOND = 31556889864403199L;
   private static final int DAYS_PER_CYCLE = 146097;
   private static final int DAYS_0000_TO_1970 = 719528;
   private static final int SECONDS_PER_HOUR = 3600;
   private static final int SECONDS_PER_MINUTE = 60;
   private static final int HOURS_PER_DAY = 24;
   private static final int SECONDS_PER_DAY = 86400;
   public static final int NANOS_PER_SECOND = 1000000000;
   private static final int NANOS_PER_MILLI = 1000000;
   private static final int MILLIS_PER_SECOND = 1000;
   @NotNull
   private static final int[] POWERS_OF_TEN;
   @NotNull
   private static final int[] asciiDigitPositionsInIsoStringAfterYear;
   @NotNull
   private static final int[] colonsInIsoOffsetString;
   @NotNull
   private static final int[] asciiDigitsInIsoOffsetString;

   private static final boolean isDistantPast(Instant $this$isDistantPast) {
      Intrinsics.checkNotNullParameter($this$isDistantPast, "<this>");
      return $this$isDistantPast.compareTo(Instant.Companion.getDISTANT_PAST()) <= 0;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalTime
   @InlineOnly
   public static void isDistantPast$annotations(Instant var0) {
   }

   private static final boolean isDistantFuture(Instant $this$isDistantFuture) {
      Intrinsics.checkNotNullParameter($this$isDistantFuture, "<this>");
      return $this$isDistantFuture.compareTo(Instant.Companion.getDISTANT_FUTURE()) >= 0;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalTime
   @InlineOnly
   public static void isDistantFuture$annotations(Instant var0) {
   }

   @ExperimentalTime
   private static final Instant parseIso(CharSequence isoString) {
      CharSequence s = isoString;
      int i = 0;
      if (isoString.length() <= 0) {
         int var23 = false;
         String var24 = "An empty string is not a valid Instant";
         throw new IllegalArgumentException(var24.toString());
      } else {
         char c = isoString.charAt(i);
         char var10000;
         switch(c) {
         case '+':
         case '-':
            ++i;
            var10000 = c;
            break;
         case ',':
         default:
            var10000 = ' ';
         }

         char yearSign = var10000;
         int yearStart = i;

         int absYear;
         for(absYear = 0; i < s.length(); ++i) {
            char var6 = s.charAt(i);
            if (!('0' <= var6 ? var6 < ':' : false)) {
               break;
            }

            absYear = absYear * 10 + (s.charAt(i) - 48);
         }

         int yearStrLength = i - yearStart;
         if (yearStrLength > 10) {
            parseIso$parseFailure(isoString, "Expected at most 10 digits for the year number, got " + yearStrLength + " digits");
            throw new KotlinNothingValueException();
         } else if (yearStrLength == 10 && Intrinsics.compare(s.charAt(yearStart), 50) >= 0) {
            parseIso$parseFailure(isoString, "Expected at most 9 digits for the year number or year 1000000000, got " + yearStrLength + " digits");
            throw new KotlinNothingValueException();
         } else if (yearStrLength < 4) {
            parseIso$parseFailure(isoString, "The year number must be padded to 4 digits, got " + yearStrLength + " digits");
            throw new KotlinNothingValueException();
         } else if (yearSign == '+' && yearStrLength == 4) {
            parseIso$parseFailure(isoString, "The '+' sign at the start is only valid for year numbers longer than 4 digits");
            throw new KotlinNothingValueException();
         } else if (yearSign == ' ' && yearStrLength != 4) {
            parseIso$parseFailure(isoString, "A '+' or '-' sign is required for year numbers longer than 4 digits");
            throw new KotlinNothingValueException();
         } else {
            int year = yearSign == '-' ? -absYear : absYear;
            if (s.length() < i + 16) {
               parseIso$parseFailure(isoString, "The input string is too short");
               throw new KotlinNothingValueException();
            } else {
               parseIso$expect(isoString, "'-'", i, InstantKt::parseIso$lambda$1);
               parseIso$expect(isoString, "'-'", i + 3, InstantKt::parseIso$lambda$2);
               parseIso$expect(isoString, "'T' or 't'", i + 6, InstantKt::parseIso$lambda$3);
               parseIso$expect(isoString, "':'", i + 9, InstantKt::parseIso$lambda$4);
               parseIso$expect(isoString, "':'", i + 12, InstantKt::parseIso$lambda$5);
               int[] var8 = asciiDigitPositionsInIsoStringAfterYear;
               int day = 0;

               int hour;
               int minute;
               for(hour = var8.length; day < hour; ++day) {
                  minute = var8[day];
                  parseIso$expect(isoString, "an ASCII digit", i + minute, InstantKt::parseIso$lambda$6);
               }

               int month = parseIso$twoDigitNumber(s, i + 1);
               day = parseIso$twoDigitNumber(s, i + 4);
               hour = parseIso$twoDigitNumber(s, i + 7);
               minute = parseIso$twoDigitNumber(s, i + 10);
               int second = parseIso$twoDigitNumber(s, i + 13);
               int offsetSeconds;
               int offsetStrLength;
               int var29;
               if (s.charAt(i + 15) == '.') {
                  offsetSeconds = i + 16;
                  i = offsetSeconds;

                  int fraction;
                  for(fraction = 0; i < s.length(); ++i) {
                     char var16 = s.charAt(i);
                     if (!('0' <= var16 ? var16 < ':' : false)) {
                        break;
                     }

                     fraction = fraction * 10 + (s.charAt(i) - 48);
                  }

                  offsetStrLength = i - offsetSeconds;
                  if (!(1 <= offsetStrLength ? offsetStrLength < 10 : false)) {
                     parseIso$parseFailure(isoString, "1..9 digits are supported for the fraction of the second, got " + offsetStrLength + " digits");
                     throw new KotlinNothingValueException();
                  }

                  var29 = fraction * POWERS_OF_TEN[9 - offsetStrLength];
               } else {
                  i += 15;
                  var29 = 0;
               }

               int nanosecond = var29;
               if (i >= s.length()) {
                  parseIso$parseFailure(isoString, "The UTC offset at the end of the string is missing");
                  throw new KotlinNothingValueException();
               } else {
                  char sign = s.charAt(i);
                  switch(sign) {
                  case '+':
                  case '-':
                     offsetStrLength = s.length() - i;
                     StringBuilder var10001;
                     int offsetMinute;
                     if (offsetStrLength > 9) {
                        var10001 = (new StringBuilder()).append("The UTC offset string \"");
                        offsetMinute = s.length();
                        parseIso$parseFailure(isoString, var10001.append(truncateForErrorMessage((CharSequence)s.subSequence(i, offsetMinute).toString(), 16)).append("\" is too long").toString());
                        throw new KotlinNothingValueException();
                     }

                     if (offsetStrLength % 3 != 0) {
                        var10001 = (new StringBuilder()).append("Invalid UTC offset string \"");
                        offsetMinute = s.length();
                        parseIso$parseFailure(isoString, var10001.append(s.subSequence(i, offsetMinute).toString()).append('"').toString());
                        throw new KotlinNothingValueException();
                     }

                     int[] var17 = colonsInIsoOffsetString;
                     offsetMinute = 0;

                     int offsetSecond;
                     int j;
                     for(offsetSecond = var17.length; offsetMinute < offsetSecond; ++offsetMinute) {
                        j = var17[offsetMinute];
                        if (i + j >= s.length()) {
                           break;
                        }

                        if (s.charAt(i + j) != ':') {
                           parseIso$parseFailure(isoString, "Expected ':' at index " + (i + j) + ", got '" + s.charAt(i + j) + '\'');
                           throw new KotlinNothingValueException();
                        }
                     }

                     var17 = asciiDigitsInIsoOffsetString;
                     offsetMinute = 0;

                     for(offsetSecond = var17.length; offsetMinute < offsetSecond; ++offsetMinute) {
                        j = var17[offsetMinute];
                        if (i + j >= s.length()) {
                           break;
                        }

                        char var21 = s.charAt(i + j);
                        if (!('0' <= var21 ? var21 < ':' : false)) {
                           parseIso$parseFailure(isoString, "Expected an ASCII digit at index " + (i + j) + ", got '" + s.charAt(i + j) + '\'');
                           throw new KotlinNothingValueException();
                        }
                     }

                     int offsetHour = parseIso$twoDigitNumber(s, i + 1);
                     offsetMinute = offsetStrLength > 3 ? parseIso$twoDigitNumber(s, i + 4) : 0;
                     offsetSecond = offsetStrLength > 6 ? parseIso$twoDigitNumber(s, i + 7) : 0;
                     if (offsetMinute > 59) {
                        parseIso$parseFailure(isoString, "Expected offset-minute-of-hour in 0..59, got " + offsetMinute);
                        throw new KotlinNothingValueException();
                     }

                     if (offsetSecond > 59) {
                        parseIso$parseFailure(isoString, "Expected offset-second-of-minute in 0..59, got " + offsetSecond);
                        throw new KotlinNothingValueException();
                     }

                     if (offsetHour > 17 && (offsetHour != 18 || offsetMinute != 0 || offsetSecond != 0)) {
                        var10001 = (new StringBuilder()).append("Expected an offset in -18:00..+18:00, got ");
                        int var31 = s.length();
                        parseIso$parseFailure(isoString, var10001.append(s.subSequence(i, var31).toString()).toString());
                        throw new KotlinNothingValueException();
                     }

                     var29 = (offsetHour * 3600 + offsetMinute * 60 + offsetSecond) * (sign == '-' ? -1 : 1);
                     break;
                  case 'Z':
                  case 'z':
                     if (s.length() != i + 1) {
                        parseIso$parseFailure(isoString, "Extra text after the instant at position " + (i + 1));
                        throw new KotlinNothingValueException();
                     }

                     var29 = 0;
                     break;
                  default:
                     parseIso$parseFailure(isoString, "Expected the UTC offset at position " + i + ", got '" + sign + '\'');
                     throw new KotlinNothingValueException();
                  }

                  offsetSeconds = var29;
                  if (!(1 <= month ? month < 13 : false)) {
                     parseIso$parseFailure(isoString, "Expected a month number in 1..12, got " + month);
                     throw new KotlinNothingValueException();
                  } else if (!(1 <= day ? day <= monthLength(month, isLeapYear(year)) : false)) {
                     parseIso$parseFailure(isoString, "Expected a valid day-of-month for month " + month + " of year " + year + ", got " + day);
                     throw new KotlinNothingValueException();
                  } else if (hour > 23) {
                     parseIso$parseFailure(isoString, "Expected hour in 0..23, got " + hour);
                     throw new KotlinNothingValueException();
                  } else if (minute > 59) {
                     parseIso$parseFailure(isoString, "Expected minute-of-hour in 0..59, got " + minute);
                     throw new KotlinNothingValueException();
                  } else if (second > 59) {
                     parseIso$parseFailure(isoString, "Expected second-of-minute in 0..59, got " + second);
                     throw new KotlinNothingValueException();
                  } else {
                     return (new UnboundLocalDateTime(year, month, day, hour, minute, second, nanosecond)).toInstant(offsetSeconds);
                  }
               }
            }
         }
      }
   }

   @ExperimentalTime
   private static final String formatIso(Instant instant) {
      StringBuilder var1 = new StringBuilder();
      int var3 = false;
      UnboundLocalDateTime ldt = UnboundLocalDateTime.Companion.fromInstant(instant);
      int var6 = false;
      int number = ldt.getYear();
      if (Math.abs(number) < 1000) {
         StringBuilder innerBuilder = new StringBuilder();
         if (number >= 0) {
            Intrinsics.checkNotNullExpressionValue(innerBuilder.append(number + 10000).deleteCharAt(0), "deleteCharAt(...)");
         } else {
            Intrinsics.checkNotNullExpressionValue(innerBuilder.append(number - 10000).deleteCharAt(1), "deleteCharAt(...)");
         }

         var1.append((CharSequence)innerBuilder);
      } else {
         if (number >= 10000) {
            var1.append('+');
         }

         var1.append(number);
      }

      var1.append('-');
      formatIso$lambda$8$appendTwoDigits((Appendable)var1, var1, ldt.getMonth());
      var1.append('-');
      formatIso$lambda$8$appendTwoDigits((Appendable)var1, var1, ldt.getDay());
      var1.append('T');
      formatIso$lambda$8$appendTwoDigits((Appendable)var1, var1, ldt.getHour());
      var1.append(':');
      formatIso$lambda$8$appendTwoDigits((Appendable)var1, var1, ldt.getMinute());
      var1.append(':');
      formatIso$lambda$8$appendTwoDigits((Appendable)var1, var1, ldt.getSecond());
      if (ldt.getNanosecond() != 0) {
         var1.append('.');

         int zerosToStrip;
         for(zerosToStrip = 0; ldt.getNanosecond() % POWERS_OF_TEN[zerosToStrip + 1] == 0; ++zerosToStrip) {
         }

         zerosToStrip -= zerosToStrip % 3;
         int numberToOutput = ldt.getNanosecond() / POWERS_OF_TEN[zerosToStrip];
         String var10 = String.valueOf(numberToOutput + POWERS_OF_TEN[9 - zerosToStrip]);
         byte var11 = 1;
         Intrinsics.checkNotNull(var10, "null cannot be cast to non-null type java.lang.String");
         String var10001 = var10.substring(var11);
         Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
         var1.append(var10001);
      }

      var1.append('Z');
      return var1.toString();
   }

   private static final long safeAddOrElse(long a, long b, Function0 action) {
      int $i$f$safeAddOrElse = false;
      long sum = a + b;
      if ((a ^ sum) < 0L && (a ^ b) >= 0L) {
         action.invoke();
         throw new KotlinNothingValueException();
      } else {
         return sum;
      }
   }

   private static final long safeMultiplyOrElse(long a, long b, Function0 action) {
      int $i$f$safeMultiplyOrElse = false;
      if (b == 1L) {
         return a;
      } else if (a == 1L) {
         return b;
      } else if (a != 0L && b != 0L) {
         long total = a * b;
         if (total / b == a && (a != Long.MIN_VALUE || b != -1L) && (b != Long.MIN_VALUE || a != -1L)) {
            return total;
         } else {
            action.invoke();
            throw new KotlinNothingValueException();
         }
      } else {
         return 0L;
      }
   }

   public static final boolean isLeapYear(int year) {
      return (year & 3) == 0 && (year % 100 != 0 || year % 400 == 0);
   }

   private static final int monthLength(int $this$monthLength, boolean isLeapYear) {
      int var10000;
      switch($this$monthLength) {
      case 2:
         var10000 = isLeapYear ? 29 : 28;
         break;
      case 3:
      case 5:
      case 7:
      case 8:
      case 10:
      default:
         var10000 = 31;
         break;
      case 4:
      case 6:
      case 9:
      case 11:
         var10000 = 30;
      }

      return var10000;
   }

   private static final String truncateForErrorMessage(CharSequence $this$truncateForErrorMessage, int maxLength) {
      return $this$truncateForErrorMessage.length() <= maxLength ? $this$truncateForErrorMessage.toString() : $this$truncateForErrorMessage.subSequence(0, maxLength).toString() + "...";
   }

   private static final Void parseIso$parseFailure(CharSequence $isoString, String error) {
      throw new InstantFormatException(error + " when parsing an Instant from \"" + truncateForErrorMessage($isoString, 64) + '"');
   }

   private static final void parseIso$expect(CharSequence $isoString, String what, int where, Function1<? super Character, Boolean> predicate) {
      char c = $isoString.charAt(where);
      if (!(Boolean)predicate.invoke(c)) {
         parseIso$parseFailure($isoString, "Expected " + what + ", but got '" + c + "' at position " + where);
         throw new KotlinNothingValueException();
      }
   }

   private static final boolean parseIso$lambda$1(char it) {
      return it == '-';
   }

   private static final boolean parseIso$lambda$2(char it) {
      return it == '-';
   }

   private static final boolean parseIso$lambda$3(char it) {
      return it == 'T' || it == 't';
   }

   private static final boolean parseIso$lambda$4(char it) {
      return it == ':';
   }

   private static final boolean parseIso$lambda$5(char it) {
      return it == ':';
   }

   private static final boolean parseIso$lambda$6(char it) {
      return '0' <= it ? it < ':' : false;
   }

   private static final int parseIso$twoDigitNumber(CharSequence s, int index) {
      return (s.charAt(index) - 48) * 10 + (s.charAt(index + 1) - 48);
   }

   private static final void formatIso$lambda$8$appendTwoDigits(Appendable $this$formatIso_u24lambda_u248_u24appendTwoDigits, StringBuilder $this_buildString, int number) {
      if (number < 10) {
         $this$formatIso_u24lambda_u248_u24appendTwoDigits.append('0');
      }

      $this_buildString.append(number);
   }

   // $FF: synthetic method
   public static final String access$formatIso(Instant instant) {
      return formatIso(instant);
   }

   // $FF: synthetic method
   public static final Instant access$parseIso(CharSequence isoString) {
      return parseIso(isoString);
   }

   static {
      int[] var0 = new int[]{1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};
      POWERS_OF_TEN = var0;
      var0 = new int[]{1, 2, 4, 5, 7, 8, 10, 11, 13, 14};
      asciiDigitPositionsInIsoStringAfterYear = var0;
      var0 = new int[]{3, 6};
      colonsInIsoOffsetString = var0;
      var0 = new int[]{1, 2, 4, 5, 7, 8};
      asciiDigitsInIsoOffsetString = var0;
   }
}
