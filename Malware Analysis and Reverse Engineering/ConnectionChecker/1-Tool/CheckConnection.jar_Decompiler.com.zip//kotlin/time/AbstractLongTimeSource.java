package kotlin.time;

import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.math.MathKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\u00020\u0001:\u0001\u0012B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\b\u001a\u00020\tH$J\b\u0010\u000f\u001a\u00020\tH\u0002J\b\u0010\u0010\u001a\u00020\u0011H\u0016R\u0014\u0010\u0002\u001a\u00020\u0003X\u0084\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001b\u0010\n\u001a\u00020\t8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\r\u0010\u000e\u001a\u0004\b\u000b\u0010\f¨\u0006\u0013"},
   d2 = {"Lkotlin/time/AbstractLongTimeSource;", "Lkotlin/time/TimeSource$WithComparableMarks;", "unit", "Lkotlin/time/DurationUnit;", "<init>", "(Lkotlin/time/DurationUnit;)V", "getUnit", "()Lkotlin/time/DurationUnit;", "read", "", "zero", "getZero", "()J", "zero$delegate", "Lkotlin/Lazy;", "adjustedRead", "markNow", "Lkotlin/time/ComparableTimeMark;", "LongTimeMark", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.9"
)
@WasExperimental(
   markerClass = {ExperimentalTime.class}
)
public abstract class AbstractLongTimeSource implements TimeSource.WithComparableMarks {
   @NotNull
   private final DurationUnit unit;
   @NotNull
   private final Lazy zero$delegate;

   public AbstractLongTimeSource(@NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      super();
      this.unit = unit;
      this.zero$delegate = LazyKt.lazy(AbstractLongTimeSource::zero_delegate$lambda$0);
   }

   @NotNull
   protected final DurationUnit getUnit() {
      return this.unit;
   }

   protected abstract long read();

   private final long getZero() {
      Lazy var1 = this.zero$delegate;
      return ((Number)var1.getValue()).longValue();
   }

   private final long adjustedRead() {
      return this.read() - this.getZero();
   }

   @NotNull
   public ComparableTimeMark markNow() {
      return (ComparableTimeMark)(new AbstractLongTimeSource.LongTimeMark(this.adjustedRead(), this, Duration.Companion.getZERO-UwyO8pc(), (DefaultConstructorMarker)null));
   }

   private static final long zero_delegate$lambda$0(AbstractLongTimeSource this$0) {
      return this$0.read();
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\f\u0010\rJ\u0018\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u0007H\u0096\u0002¢\u0006\u0004\b\u0010\u0010\u0011J\u0018\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0001H\u0096\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0013\u001a\u0004\u0018\u00010\u0018H\u0096\u0002J\b\u0010\u0019\u001a\u00020\u001aH\u0016J\b\u0010\u001b\u001a\u00020\u001cH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\n¨\u0006\u001d"},
      d2 = {"Lkotlin/time/AbstractLongTimeSource$LongTimeMark;", "Lkotlin/time/ComparableTimeMark;", "startedAt", "", "timeSource", "Lkotlin/time/AbstractLongTimeSource;", "offset", "Lkotlin/time/Duration;", "<init>", "(JLkotlin/time/AbstractLongTimeSource;JLkotlin/jvm/internal/DefaultConstructorMarker;)V", "J", "elapsedNow", "elapsedNow-UwyO8pc", "()J", "plus", "duration", "plus-LRDsOJo", "(J)Lkotlin/time/ComparableTimeMark;", "minus", "other", "minus-UwyO8pc", "(Lkotlin/time/ComparableTimeMark;)J", "equals", "", "", "hashCode", "", "toString", "", "kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nTimeSources.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TimeSources.kt\nkotlin/time/AbstractLongTimeSource$LongTimeMark\n+ 2 longSaturatedMath.kt\nkotlin/time/LongSaturatedMathKt\n*L\n1#1,202:1\n80#2:203\n*S KotlinDebug\n*F\n+ 1 TimeSources.kt\nkotlin/time/AbstractLongTimeSource$LongTimeMark\n*L\n67#1:203\n*E\n"})
   private static final class LongTimeMark implements ComparableTimeMark {
      private final long startedAt;
      @NotNull
      private final AbstractLongTimeSource timeSource;
      private final long offset;

      private LongTimeMark(long startedAt, AbstractLongTimeSource timeSource, long offset) {
         Intrinsics.checkNotNullParameter(timeSource, "timeSource");
         super();
         this.startedAt = startedAt;
         this.timeSource = timeSource;
         this.offset = offset;
      }

      public long elapsedNow_UwyO8pc/* $FF was: elapsedNow-UwyO8pc*/() {
         return Duration.minus-LRDsOJo(LongSaturatedMathKt.saturatingOriginsDiff(this.timeSource.adjustedRead(), this.startedAt, this.timeSource.getUnit()), this.offset);
      }

      @NotNull
      public ComparableTimeMark plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long duration) {
         DurationUnit unit = this.timeSource.getUnit();
         long durationInUnit;
         if (Duration.isInfinite-impl(duration)) {
            durationInUnit = LongSaturatedMathKt.saturatingAdd-NuflL3o(this.startedAt, unit, duration);
            return (ComparableTimeMark)(new AbstractLongTimeSource.LongTimeMark(durationInUnit, this.timeSource, Duration.Companion.getZERO-UwyO8pc(), (DefaultConstructorMarker)null));
         } else {
            durationInUnit = Duration.truncateTo-UwyO8pc$kotlin_stdlib(duration, unit);
            long rest = Duration.plus-LRDsOJo(Duration.minus-LRDsOJo(duration, durationInUnit), this.offset);
            long sum = LongSaturatedMathKt.saturatingAdd-NuflL3o(this.startedAt, unit, durationInUnit);
            long restInUnit = Duration.truncateTo-UwyO8pc$kotlin_stdlib(rest, unit);
            sum = LongSaturatedMathKt.saturatingAdd-NuflL3o(sum, unit, restInUnit);
            long restUnderUnit = Duration.minus-LRDsOJo(rest, restInUnit);
            long restUnderUnitNs = Duration.getInWholeNanoseconds-impl(restUnderUnit);
            if (sum != 0L && restUnderUnitNs != 0L && (sum ^ restUnderUnitNs) < 0L) {
               long correction = DurationKt.toDuration(MathKt.getSign(restUnderUnitNs), unit);
               sum = LongSaturatedMathKt.saturatingAdd-NuflL3o(sum, unit, correction);
               restUnderUnit = Duration.minus-LRDsOJo(restUnderUnit, correction);
            }

            int $i$f$isSaturated = false;
            long newOffset = (sum - 1L | 1L) == Long.MAX_VALUE ? Duration.Companion.getZERO-UwyO8pc() : restUnderUnit;
            return (ComparableTimeMark)(new AbstractLongTimeSource.LongTimeMark(sum, this.timeSource, newOffset, (DefaultConstructorMarker)null));
         }
      }

      public long minus_UwyO8pc/* $FF was: minus-UwyO8pc*/(@NotNull ComparableTimeMark other) {
         Intrinsics.checkNotNullParameter(other, "other");
         if (other instanceof AbstractLongTimeSource.LongTimeMark && Intrinsics.areEqual((Object)this.timeSource, (Object)((AbstractLongTimeSource.LongTimeMark)other).timeSource)) {
            long startedAtDiff = LongSaturatedMathKt.saturatingOriginsDiff(this.startedAt, ((AbstractLongTimeSource.LongTimeMark)other).startedAt, this.timeSource.getUnit());
            return Duration.plus-LRDsOJo(startedAtDiff, Duration.minus-LRDsOJo(this.offset, ((AbstractLongTimeSource.LongTimeMark)other).offset));
         } else {
            throw new IllegalArgumentException("Subtracting or comparing time marks from different time sources is not possible: " + this + " and " + other);
         }
      }

      public boolean equals(@Nullable Object other) {
         return other instanceof AbstractLongTimeSource.LongTimeMark && Intrinsics.areEqual((Object)this.timeSource, (Object)((AbstractLongTimeSource.LongTimeMark)other).timeSource) && Duration.equals-impl0(this.minus-UwyO8pc((ComparableTimeMark)other), Duration.Companion.getZERO-UwyO8pc());
      }

      public int hashCode() {
         return Duration.hashCode-impl(this.offset) * 37 + Long.hashCode(this.startedAt);
      }

      @NotNull
      public String toString() {
         return "LongTimeMark(" + this.startedAt + DurationUnitKt.shortName(this.timeSource.getUnit()) + " + " + Duration.toString-impl(this.offset) + ", " + this.timeSource + ')';
      }

      @NotNull
      public ComparableTimeMark minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long duration) {
         return ComparableTimeMark.DefaultImpls.minus-LRDsOJo(this, duration);
      }

      public int compareTo(@NotNull ComparableTimeMark other) {
         return ComparableTimeMark.DefaultImpls.compareTo(this, other);
      }

      public boolean hasPassedNow() {
         return ComparableTimeMark.DefaultImpls.hasPassedNow(this);
      }

      public boolean hasNotPassedNow() {
         return ComparableTimeMark.DefaultImpls.hasNotPassedNow(this);
      }

      // $FF: synthetic method
      public LongTimeMark(long startedAt, AbstractLongTimeSource timeSource, long offset, DefaultConstructorMarker $constructor_marker) {
         this(startedAt, timeSource, offset);
      }
   }
}
