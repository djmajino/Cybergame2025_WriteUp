package kotlin.time;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\b\n\u0000\n\u0002\u0010\t\n\u0000*\f\b\u0000\u0010\u0000\"\u00020\u00012\u00020\u0001¨\u0006\u0002"},
   d2 = {"ValueTimeMarkReading", "", "kotlin-stdlib"}
)
public final class MonoTimeSourceKt {
   /** @deprecated */
   // $FF: synthetic method
   public static void ValueTimeMarkReading$annotations() {
   }
}
