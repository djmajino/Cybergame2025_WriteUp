package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B\u0017\u0012\u0006\u0010\u0003\u001a\u00028\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u000e\u001a\u00028\u0000HÆ\u0003¢\u0006\u0002\u0010\tJ\u0010\u0010\u000f\u001a\u00020\u0005HÆ\u0003¢\u0006\u0004\b\u0010\u0010\fJ*\u0010\u0011\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\b\b\u0002\u0010\u0003\u001a\u00028\u00002\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0002HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001R\u0013\u0010\u0003\u001a\u00028\u0000¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0004\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\r\u001a\u0004\b\u000b\u0010\f¨\u0006\u001b"},
   d2 = {"Lkotlin/time/TimedValue;", "T", "", "value", "duration", "Lkotlin/time/Duration;", "<init>", "(Ljava/lang/Object;JLkotlin/jvm/internal/DefaultConstructorMarker;)V", "getValue", "()Ljava/lang/Object;", "Ljava/lang/Object;", "getDuration-UwyO8pc", "()J", "J", "component1", "component2", "component2-UwyO8pc", "copy", "copy-RFiDyg4", "(Ljava/lang/Object;J)Lkotlin/time/TimedValue;", "equals", "", "other", "hashCode", "", "toString", "", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.9"
)
@WasExperimental(
   markerClass = {ExperimentalTime.class}
)
public final class TimedValue<T> {
   private final T value;
   private final long duration;

   private TimedValue(T value, long duration) {
      this.value = value;
      this.duration = duration;
   }

   public final T getValue() {
      return this.value;
   }

   public final long getDuration_UwyO8pc/* $FF was: getDuration-UwyO8pc*/() {
      return this.duration;
   }

   public final T component1() {
      return this.value;
   }

   public final long component2_UwyO8pc/* $FF was: component2-UwyO8pc*/() {
      return this.duration;
   }

   @NotNull
   public final TimedValue<T> copy_RFiDyg4/* $FF was: copy-RFiDyg4*/(T value, long duration) {
      return new TimedValue(value, duration, (DefaultConstructorMarker)null);
   }

   // $FF: synthetic method
   public static TimedValue copy_RFiDyg4$default/* $FF was: copy-RFiDyg4$default*/(TimedValue var0, Object var1, long var2, int var4, Object var5) {
      if ((var4 & 1) != 0) {
         var1 = var0.value;
      }

      if ((var4 & 2) != 0) {
         var2 = var0.duration;
      }

      return var0.copy-RFiDyg4(var1, var2);
   }

   @NotNull
   public String toString() {
      return "TimedValue(value=" + this.value + ", duration=" + Duration.toString-impl(this.duration) + ')';
   }

   public int hashCode() {
      int result = this.value == null ? 0 : this.value.hashCode();
      result = result * 31 + Duration.hashCode-impl(this.duration);
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof TimedValue)) {
         return false;
      } else {
         TimedValue var2 = (TimedValue)other;
         if (!Intrinsics.areEqual(this.value, var2.value)) {
            return false;
         } else {
            return Duration.equals-impl0(this.duration, var2.duration);
         }
      }
   }

   // $FF: synthetic method
   public TimedValue(Object value, long duration, DefaultConstructorMarker $constructor_marker) {
      this(value, duration);
   }
}
