package kotlin.time;

import kotlin.Metadata;

@Metadata(
   mv = {2, 1, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/time/DurationUnitKt__DurationUnitJvmKt", "kotlin/time/DurationUnitKt__DurationUnitKt"}
)
public final class DurationUnitKt extends DurationUnitKt__DurationUnitKt {
   private DurationUnitKt() {
   }
}
