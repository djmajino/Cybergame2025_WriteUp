package kotlin.time;

import java.io.Externalizable;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\b\u0003\u0018\u0000 \u001a2\u00020\u0001:\u0001\u001aB\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007B\t\b\u0016¢\u0006\u0004\b\u0006\u0010\bJ\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0010\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J\b\u0010\u0018\u001a\u00020\u0019H\u0002R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010¨\u0006\u001b"},
   d2 = {"Lkotlin/time/InstantSerialized;", "Ljava/io/Externalizable;", "epochSeconds", "", "nanosecondsOfSecond", "", "<init>", "(JI)V", "()V", "getEpochSeconds", "()J", "setEpochSeconds", "(J)V", "getNanosecondsOfSecond", "()I", "setNanosecondsOfSecond", "(I)V", "writeExternal", "", "output", "Ljava/io/ObjectOutput;", "readExternal", "input", "Ljava/io/ObjectInput;", "readResolve", "", "Companion", "kotlin-stdlib"}
)
@ExperimentalTime
final class InstantSerialized implements Externalizable {
   @NotNull
   public static final InstantSerialized.Companion Companion = new InstantSerialized.Companion((DefaultConstructorMarker)null);
   private long epochSeconds;
   private int nanosecondsOfSecond;
   private static final long serialVersionUID = 0L;

   public InstantSerialized(long epochSeconds, int nanosecondsOfSecond) {
      this.epochSeconds = epochSeconds;
      this.nanosecondsOfSecond = nanosecondsOfSecond;
   }

   public final long getEpochSeconds() {
      return this.epochSeconds;
   }

   public final void setEpochSeconds(long var1) {
      this.epochSeconds = var1;
   }

   public final int getNanosecondsOfSecond() {
      return this.nanosecondsOfSecond;
   }

   public final void setNanosecondsOfSecond(int var1) {
      this.nanosecondsOfSecond = var1;
   }

   public InstantSerialized() {
      this(0L, 0);
   }

   public void writeExternal(@NotNull ObjectOutput output) {
      Intrinsics.checkNotNullParameter(output, "output");
      output.writeLong(this.epochSeconds);
      output.writeInt(this.nanosecondsOfSecond);
   }

   public void readExternal(@NotNull ObjectInput input) {
      Intrinsics.checkNotNullParameter(input, "input");
      this.epochSeconds = input.readLong();
      this.nanosecondsOfSecond = input.readInt();
   }

   private final Object readResolve() {
      return Instant.Companion.fromEpochSeconds(this.epochSeconds, this.nanosecondsOfSecond);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lkotlin/time/InstantSerialized$Companion;", "", "<init>", "()V", "serialVersionUID", "", "kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
