package kotlin.time;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000,\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0006\n\u0000\u001a\u0010\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bH\u0002\u001a\u0018\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\n\u001a\u00020\u000bH\u0000\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u001c\u0010\u0004\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00060\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\b¨\u0006\u0010"},
   d2 = {"durationAssertionsEnabled", "", "getDurationAssertionsEnabled", "()Z", "precisionFormats", "", "Ljava/lang/ThreadLocal;", "Ljava/text/DecimalFormat;", "[Ljava/lang/ThreadLocal;", "createFormatForDecimals", "decimals", "", "formatToExactDecimals", "", "value", "", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nDurationJvm.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DurationJvm.kt\nkotlin/time/DurationJvmKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,28:1\n1#2:29\n*E\n"})
public final class DurationJvmKt {
   private static final boolean durationAssertionsEnabled = Duration.class.desiredAssertionStatus();
   @NotNull
   private static final ThreadLocal<DecimalFormat>[] precisionFormats;

   public static final boolean getDurationAssertionsEnabled() {
      return durationAssertionsEnabled;
   }

   private static final DecimalFormat createFormatForDecimals(int decimals) {
      DecimalFormat var1 = new DecimalFormat("0");
      int var3 = false;
      if (decimals > 0) {
         var1.setMinimumFractionDigits(decimals);
      }

      var1.setRoundingMode(RoundingMode.HALF_UP);
      return var1;
   }

   @NotNull
   public static final String formatToExactDecimals(double value, int decimals) {
      DecimalFormat var8;
      if (decimals < precisionFormats.length) {
         ThreadLocal var4 = precisionFormats[decimals];
         Object var10000 = var4.get();
         if (var10000 == null) {
            int var5 = false;
            DecimalFormat var7 = createFormatForDecimals(decimals);
            var4.set(var7);
            var10000 = var7;
         }

         var8 = (DecimalFormat)var10000;
      } else {
         var8 = createFormatForDecimals(decimals);
      }

      DecimalFormat format = var8;
      String var9 = format.format(value);
      Intrinsics.checkNotNullExpressionValue(var9, "format(...)");
      return var9;
   }

   static {
      int var0 = 0;

      ThreadLocal[] var1;
      for(var1 = new ThreadLocal[4]; var0 < 4; ++var0) {
         var1[var0] = new ThreadLocal();
      }

      precisionFormats = var1;
   }
}
