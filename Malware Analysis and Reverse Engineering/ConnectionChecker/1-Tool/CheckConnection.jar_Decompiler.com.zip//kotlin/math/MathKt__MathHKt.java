package kotlin.math;

import kotlin.Metadata;
import kotlin.SinceKotlin;

@Metadata(
   mv = {2, 1, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0005\"\u0016\u0010\u0000\u001a\u00020\u00018\u0006X\u0087T¢\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0004\u001a\u00020\u00018\u0006X\u0087T¢\u0006\b\n\u0000\u0012\u0004\b\u0005\u0010\u0003¨\u0006\u0006"},
   d2 = {"PI", "", "getPI$annotations", "()V", "E", "getE$annotations", "kotlin-stdlib"},
   xs = "kotlin/math/MathKt"
)
class MathKt__MathHKt {
   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.2"
   )
   public static void getPI$annotations() {
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.2"
   )
   public static void getE$annotations() {
   }

   public MathKt__MathHKt() {
   }
}
