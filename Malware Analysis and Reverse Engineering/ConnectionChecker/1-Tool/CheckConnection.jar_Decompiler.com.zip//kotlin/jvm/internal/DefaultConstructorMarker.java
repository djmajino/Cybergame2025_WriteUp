package kotlin.jvm.internal;

public final class DefaultConstructorMarker {
   private DefaultConstructorMarker() {
   }
}
