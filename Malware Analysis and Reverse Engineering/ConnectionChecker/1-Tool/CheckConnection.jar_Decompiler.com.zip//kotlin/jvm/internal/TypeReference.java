package kotlin.jvm.internal;

import java.lang.annotation.Annotation;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.SinceKotlin;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.reflect.KClass;
import kotlin.reflect.KClassifier;
import kotlin.reflect.KType;
import kotlin.reflect.KTypeProjection;
import kotlin.reflect.KVariance;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\r\n\u0002\u0010\u001b\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 *2\u00020\u0001:\u0001*B1\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0001\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bB'\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\f\u001a\u00020\r¢\u0006\u0004\b\n\u0010\u000eJ\u0013\u0010\u001e\u001a\u00020\r2\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0096\u0002J\b\u0010!\u001a\u00020\tH\u0016J\b\u0010\"\u001a\u00020#H\u0016J\u0010\u0010$\u001a\u00020#2\u0006\u0010%\u001a\u00020\rH\u0002J\f\u0010$\u001a\u00020#*\u00020\u0006H\u0002R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u001a\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u001e\u0010\u0007\u001a\u0004\u0018\u00010\u00018\u0000X\u0081\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016R\u001c\u0010\b\u001a\u00020\t8\u0000X\u0081\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0017\u0010\u0014\u001a\u0004\b\u0018\u0010\u0019R\u001a\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001b0\u00058VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u0012R\u0014\u0010\f\u001a\u00020\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\u001dR\u001c\u0010&\u001a\u00020#*\u0006\u0012\u0002\b\u00030'8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b(\u0010)¨\u0006+"},
   d2 = {"Lkotlin/jvm/internal/TypeReference;", "Lkotlin/reflect/KType;", "classifier", "Lkotlin/reflect/KClassifier;", "arguments", "", "Lkotlin/reflect/KTypeProjection;", "platformTypeUpperBound", "flags", "", "<init>", "(Lkotlin/reflect/KClassifier;Ljava/util/List;Lkotlin/reflect/KType;I)V", "isMarkedNullable", "", "(Lkotlin/reflect/KClassifier;Ljava/util/List;Z)V", "getClassifier", "()Lkotlin/reflect/KClassifier;", "getArguments", "()Ljava/util/List;", "getPlatformTypeUpperBound$kotlin_stdlib$annotations", "()V", "getPlatformTypeUpperBound$kotlin_stdlib", "()Lkotlin/reflect/KType;", "getFlags$kotlin_stdlib$annotations", "getFlags$kotlin_stdlib", "()I", "annotations", "", "getAnnotations", "()Z", "equals", "other", "", "hashCode", "toString", "", "asString", "convertPrimitiveToWrapper", "arrayClassName", "Ljava/lang/Class;", "getArrayClassName", "(Ljava/lang/Class;)Ljava/lang/String;", "Companion", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.4"
)
public final class TypeReference implements KType {
   @NotNull
   public static final TypeReference.Companion Companion = new TypeReference.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final KClassifier classifier;
   @NotNull
   private final List<KTypeProjection> arguments;
   @Nullable
   private final KType platformTypeUpperBound;
   private final int flags;
   public static final int IS_MARKED_NULLABLE = 1;
   public static final int IS_MUTABLE_COLLECTION_TYPE = 2;
   public static final int IS_NOTHING_TYPE = 4;

   @SinceKotlin(
      version = "1.6"
   )
   public TypeReference(@NotNull KClassifier classifier, @NotNull List<KTypeProjection> arguments, @Nullable KType platformTypeUpperBound, int flags) {
      Intrinsics.checkNotNullParameter(classifier, "classifier");
      Intrinsics.checkNotNullParameter(arguments, "arguments");
      super();
      this.classifier = classifier;
      this.arguments = arguments;
      this.platformTypeUpperBound = platformTypeUpperBound;
      this.flags = flags;
   }

   @NotNull
   public KClassifier getClassifier() {
      return this.classifier;
   }

   @NotNull
   public List<KTypeProjection> getArguments() {
      return this.arguments;
   }

   @Nullable
   public final KType getPlatformTypeUpperBound$kotlin_stdlib() {
      return this.platformTypeUpperBound;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.6"
   )
   public static void getPlatformTypeUpperBound$kotlin_stdlib$annotations() {
   }

   public final int getFlags$kotlin_stdlib() {
      return this.flags;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.6"
   )
   public static void getFlags$kotlin_stdlib$annotations() {
   }

   public TypeReference(@NotNull KClassifier classifier, @NotNull List<KTypeProjection> arguments, boolean isMarkedNullable) {
      Intrinsics.checkNotNullParameter(classifier, "classifier");
      Intrinsics.checkNotNullParameter(arguments, "arguments");
      this(classifier, arguments, (KType)null, isMarkedNullable ? 1 : 0);
   }

   @NotNull
   public List<Annotation> getAnnotations() {
      return CollectionsKt.emptyList();
   }

   public boolean isMarkedNullable() {
      return (this.flags & 1) != 0;
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof TypeReference && Intrinsics.areEqual((Object)this.getClassifier(), (Object)((TypeReference)other).getClassifier()) && Intrinsics.areEqual((Object)this.getArguments(), (Object)((TypeReference)other).getArguments()) && Intrinsics.areEqual((Object)this.platformTypeUpperBound, (Object)((TypeReference)other).platformTypeUpperBound) && this.flags == ((TypeReference)other).flags;
   }

   public int hashCode() {
      return (this.getClassifier().hashCode() * 31 + this.getArguments().hashCode()) * 31 + Integer.hashCode(this.flags);
   }

   @NotNull
   public String toString() {
      return this.asString(false) + " (Kotlin reflection is not available)";
   }

   private final String asString(boolean convertPrimitiveToWrapper) {
      KClassifier var4 = this.getClassifier();
      Class javaClass = (var4 instanceof KClass ? (KClass)var4 : null) != null ? JvmClassMappingKt.getJavaClass(var4 instanceof KClass ? (KClass)var4 : null) : null;
      String var10000;
      if (javaClass == null) {
         var10000 = this.getClassifier().toString();
      } else if ((this.flags & 4) != 0) {
         var10000 = "kotlin.Nothing";
      } else if (javaClass.isArray()) {
         var10000 = this.getArrayClassName(javaClass);
      } else if (convertPrimitiveToWrapper && javaClass.isPrimitive()) {
         KClassifier var10 = this.getClassifier();
         Intrinsics.checkNotNull(var10, "null cannot be cast to non-null type kotlin.reflect.KClass<*>");
         var10000 = JvmClassMappingKt.getJavaObjectType((KClass)var10).getName();
      } else {
         var10000 = javaClass.getName();
      }

      String klass = var10000;
      String args = this.getArguments().isEmpty() ? "" : CollectionsKt.joinToString$default((Iterable)this.getArguments(), (CharSequence)", ", (CharSequence)"<", (CharSequence)">", 0, (CharSequence)null, TypeReference::asString$lambda$0, 24, (Object)null);
      String nullable = this.isMarkedNullable() ? "?" : "";
      String result = klass + args + nullable;
      KType upper = this.platformTypeUpperBound;
      if (upper instanceof TypeReference) {
         String renderedUpper = ((TypeReference)upper).asString(true);
         var10000 = Intrinsics.areEqual((Object)renderedUpper, (Object)result) ? result : (Intrinsics.areEqual((Object)renderedUpper, (Object)(result + '?')) ? result + '!' : '(' + result + ".." + renderedUpper + ')');
      } else {
         var10000 = result;
      }

      return var10000;
   }

   private final String getArrayClassName(Class<?> $this$arrayClassName) {
      return Intrinsics.areEqual((Object)$this$arrayClassName, (Object)boolean[].class) ? "kotlin.BooleanArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)char[].class) ? "kotlin.CharArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)byte[].class) ? "kotlin.ByteArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)short[].class) ? "kotlin.ShortArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)int[].class) ? "kotlin.IntArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)float[].class) ? "kotlin.FloatArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)long[].class) ? "kotlin.LongArray" : (Intrinsics.areEqual((Object)$this$arrayClassName, (Object)double[].class) ? "kotlin.DoubleArray" : "kotlin.Array")))))));
   }

   private final String asString(KTypeProjection $this$asString) {
      if ($this$asString.getVariance() == null) {
         return "*";
      } else {
         String var4;
         label29: {
            KType var3 = $this$asString.getType();
            TypeReference var10000 = var3 instanceof TypeReference ? (TypeReference)var3 : null;
            if ((var3 instanceof TypeReference ? (TypeReference)var3 : null) != null) {
               var4 = var10000.asString(true);
               if (var4 != null) {
                  break label29;
               }
            }

            var4 = String.valueOf($this$asString.getType());
         }

         String typeString = var4;
         KVariance var5 = $this$asString.getVariance();
         switch(var5 == null ? -1 : TypeReference.WhenMappings.$EnumSwitchMapping$0[var5.ordinal()]) {
         case 1:
            var4 = typeString;
            break;
         case 2:
            var4 = "in " + typeString;
            break;
         case 3:
            var4 = "out " + typeString;
            break;
         default:
            throw new NoWhenBranchMatchedException();
         }

         return var4;
      }
   }

   private static final CharSequence asString$lambda$0(TypeReference this$0, KTypeProjection it) {
      Intrinsics.checkNotNullParameter(it, "it");
      return (CharSequence)this$0.asString(it);
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\b\u0080\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0080T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0080T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0080T¢\u0006\u0002\n\u0000¨\u0006\b"},
      d2 = {"Lkotlin/jvm/internal/TypeReference$Companion;", "", "<init>", "()V", "IS_MARKED_NULLABLE", "", "IS_MUTABLE_COLLECTION_TYPE", "IS_NOTHING_TYPE", "kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {2, 1, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[KVariance.values().length];

         try {
            var0[KVariance.INVARIANT.ordinal()] = 1;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[KVariance.IN.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[KVariance.OUT.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$0 = var0;
      }
   }
}
