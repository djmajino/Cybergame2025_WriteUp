package kotlin.jvm.internal;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import kotlin.Function;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.SinceKotlin;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.KotlinReflectionNotSupportedError;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function10;
import kotlin.jvm.functions.Function11;
import kotlin.jvm.functions.Function12;
import kotlin.jvm.functions.Function13;
import kotlin.jvm.functions.Function14;
import kotlin.jvm.functions.Function15;
import kotlin.jvm.functions.Function16;
import kotlin.jvm.functions.Function17;
import kotlin.jvm.functions.Function18;
import kotlin.jvm.functions.Function19;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function20;
import kotlin.jvm.functions.Function21;
import kotlin.jvm.functions.Function22;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.functions.Function6;
import kotlin.jvm.functions.Function7;
import kotlin.jvm.functions.Function8;
import kotlin.jvm.functions.Function9;
import kotlin.reflect.KCallable;
import kotlin.reflect.KClass;
import kotlin.reflect.KFunction;
import kotlin.reflect.KType;
import kotlin.reflect.KTypeParameter;
import kotlin.reflect.KVisibility;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0010\u001b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u0001\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\u0018\u0000 P2\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003:\u0001PB\u0013\u0012\n\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0012\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010\u0002H\u0017J\b\u0010I\u001a\u00020JH\u0002J\u0013\u0010K\u001a\u00020#2\b\u0010L\u001a\u0004\u0018\u00010\u0002H\u0096\u0002J\b\u0010M\u001a\u00020NH\u0016J\b\u0010O\u001a\u00020\u000bH\u0016R\u0018\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0016\u0010\n\u001a\u0004\u0018\u00010\u000b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0016\u0010\u000e\u001a\u0004\u0018\u00010\u000b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\rR\u001e\u0010\u0010\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00120\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014R \u0010\u0015\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00160\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0014R\u001e\u0010\u0018\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00010\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u0014R\u001a\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u001eR\u0016\u0010\u001f\u001a\u0004\u0018\u00010\u00028VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b \u0010!R \u0010%\u001a\b\u0012\u0004\u0012\u00020&0\u001b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b'\u0010(\u001a\u0004\b)\u0010\u001eR \u0010*\u001a\b\u0012\u0004\u0012\u00020+0\u001b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b,\u0010(\u001a\u0004\b-\u0010\u001eR(\u0010.\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00020\u00010\u001b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b/\u0010(\u001a\u0004\b0\u0010\u001eR\u001c\u00101\u001a\u0004\u0018\u0001028VX\u0097\u0004¢\u0006\f\u0012\u0004\b3\u0010(\u001a\u0004\b4\u00105R\u001a\u00106\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b7\u0010(\u001a\u0004\b6\u00108R\u001a\u00109\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b:\u0010(\u001a\u0004\b9\u00108R\u001a\u0010;\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b<\u0010(\u001a\u0004\b;\u00108R\u001a\u0010=\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b>\u0010(\u001a\u0004\b=\u00108R\u001a\u0010?\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b@\u0010(\u001a\u0004\b?\u00108R\u001a\u0010A\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bB\u0010(\u001a\u0004\bA\u00108R\u001a\u0010C\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bD\u0010(\u001a\u0004\bC\u00108R\u001a\u0010E\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bF\u0010(\u001a\u0004\bE\u00108R\u001a\u0010G\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bH\u0010(\u001a\u0004\bG\u00108¨\u0006Q"},
   d2 = {"Lkotlin/jvm/internal/ClassReference;", "Lkotlin/reflect/KClass;", "", "Lkotlin/jvm/internal/ClassBasedDeclarationContainer;", "jClass", "Ljava/lang/Class;", "<init>", "(Ljava/lang/Class;)V", "getJClass", "()Ljava/lang/Class;", "simpleName", "", "getSimpleName", "()Ljava/lang/String;", "qualifiedName", "getQualifiedName", "members", "", "Lkotlin/reflect/KCallable;", "getMembers", "()Ljava/util/Collection;", "constructors", "Lkotlin/reflect/KFunction;", "getConstructors", "nestedClasses", "getNestedClasses", "annotations", "", "", "getAnnotations", "()Ljava/util/List;", "objectInstance", "getObjectInstance", "()Ljava/lang/Object;", "isInstance", "", "value", "typeParameters", "Lkotlin/reflect/KTypeParameter;", "getTypeParameters$annotations", "()V", "getTypeParameters", "supertypes", "Lkotlin/reflect/KType;", "getSupertypes$annotations", "getSupertypes", "sealedSubclasses", "getSealedSubclasses$annotations", "getSealedSubclasses", "visibility", "Lkotlin/reflect/KVisibility;", "getVisibility$annotations", "getVisibility", "()Lkotlin/reflect/KVisibility;", "isFinal", "isFinal$annotations", "()Z", "isOpen", "isOpen$annotations", "isAbstract", "isAbstract$annotations", "isSealed", "isSealed$annotations", "isData", "isData$annotations", "isInner", "isInner$annotations", "isCompanion", "isCompanion$annotations", "isFun", "isFun$annotations", "isValue", "isValue$annotations", "error", "", "equals", "other", "hashCode", "", "toString", "Companion", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nClassReference.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ClassReference.kt\nkotlin/jvm/internal/ClassReference\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,205:1\n1573#2:206\n1604#2,4:207\n1267#2,4:211\n1252#2,4:217\n465#3:215\n415#3:216\n*S KotlinDebug\n*F\n+ 1 ClassReference.kt\nkotlin/jvm/internal/ClassReference\n*L\n107#1:206\n107#1:207,4\n155#1:211,4\n163#1:217,4\n163#1:215\n163#1:216\n*E\n"})
public final class ClassReference implements KClass<Object>, ClassBasedDeclarationContainer {
   @NotNull
   public static final ClassReference.Companion Companion = new ClassReference.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Class<?> jClass;
   @NotNull
   private static final Map<Class<? extends Function<?>>, Integer> FUNCTION_CLASSES;
   @NotNull
   private static final HashMap<String, String> primitiveFqNames;
   @NotNull
   private static final HashMap<String, String> primitiveWrapperFqNames;
   @NotNull
   private static final HashMap<String, String> classFqNames;
   @NotNull
   private static final Map<String, String> simpleNames;

   public ClassReference(@NotNull Class<?> jClass) {
      Intrinsics.checkNotNullParameter(jClass, "jClass");
      super();
      this.jClass = jClass;
   }

   @NotNull
   public Class<?> getJClass() {
      return this.jClass;
   }

   @Nullable
   public String getSimpleName() {
      return Companion.getClassSimpleName(this.getJClass());
   }

   @Nullable
   public String getQualifiedName() {
      return Companion.getClassQualifiedName(this.getJClass());
   }

   @NotNull
   public Collection<KCallable<?>> getMembers() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Collection<KFunction<Object>> getConstructors() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Collection<KClass<?>> getNestedClasses() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public List<Annotation> getAnnotations() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @Nullable
   public Object getObjectInstance() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @SinceKotlin(
      version = "1.1"
   )
   public boolean isInstance(@Nullable Object value) {
      return Companion.isInstance(value, this.getJClass());
   }

   @NotNull
   public List<KTypeParameter> getTypeParameters() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getTypeParameters$annotations() {
   }

   @NotNull
   public List<KType> getSupertypes() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getSupertypes$annotations() {
   }

   @NotNull
   public List<KClass<? extends Object>> getSealedSubclasses() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.3"
   )
   public static void getSealedSubclasses$annotations() {
   }

   @Nullable
   public KVisibility getVisibility() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getVisibility$annotations() {
   }

   public boolean isFinal() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isFinal$annotations() {
   }

   public boolean isOpen() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isOpen$annotations() {
   }

   public boolean isAbstract() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isAbstract$annotations() {
   }

   public boolean isSealed() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isSealed$annotations() {
   }

   public boolean isData() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isData$annotations() {
   }

   public boolean isInner() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isInner$annotations() {
   }

   public boolean isCompanion() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isCompanion$annotations() {
   }

   public boolean isFun() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.4"
   )
   public static void isFun$annotations() {
   }

   public boolean isValue() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.5"
   )
   public static void isValue$annotations() {
   }

   private final Void error() {
      throw new KotlinReflectionNotSupportedError();
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof ClassReference && Intrinsics.areEqual((Object)JvmClassMappingKt.getJavaObjectType((KClass)this), (Object)JvmClassMappingKt.getJavaObjectType((KClass)other));
   }

   public int hashCode() {
      return JvmClassMappingKt.getJavaObjectType((KClass)this).hashCode();
   }

   @NotNull
   public String toString() {
      return this.getJClass() + " (Kotlin reflection is not available)";
   }

   static {
      Class[] var0 = new Class[]{Function0.class, Function1.class, Function2.class, Function3.class, Function4.class, Function5.class, Function6.class, Function7.class, Function8.class, Function9.class, Function10.class, Function11.class, Function12.class, Function13.class, Function14.class, Function15.class, Function16.class, Function17.class, Function18.class, Function19.class, Function20.class, Function21.class, Function22.class};
      Iterable $this$mapIndexed$iv = (Iterable)CollectionsKt.listOf(var0);
      int $i$f$mapValues = false;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$mapIndexed$iv, 10)));
      int $i$f$mapValuesTo = false;
      int index$iv$iv = 0;
      Iterator var6 = $this$mapIndexed$iv.iterator();

      boolean var11;
      while(var6.hasNext()) {
         Object item$iv$iv = var6.next();
         int var8 = index$iv$iv++;
         if (var8 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         Class clazz = (Class)item$iv$iv;
         var11 = false;
         destination$iv$iv.add(TuplesKt.to(clazz, var8));
      }

      FUNCTION_CLASSES = MapsKt.toMap((Iterable)((List)destination$iv$iv));
      HashMap var19 = new HashMap();
      int var2 = false;
      var19.put("boolean", "kotlin.Boolean");
      var19.put("char", "kotlin.Char");
      var19.put("byte", "kotlin.Byte");
      var19.put("short", "kotlin.Short");
      var19.put("int", "kotlin.Int");
      var19.put("float", "kotlin.Float");
      var19.put("long", "kotlin.Long");
      var19.put("double", "kotlin.Double");
      primitiveFqNames = var19;
      var19 = new HashMap();
      var2 = false;
      var19.put("java.lang.Boolean", "kotlin.Boolean");
      var19.put("java.lang.Character", "kotlin.Char");
      var19.put("java.lang.Byte", "kotlin.Byte");
      var19.put("java.lang.Short", "kotlin.Short");
      var19.put("java.lang.Integer", "kotlin.Int");
      var19.put("java.lang.Float", "kotlin.Float");
      var19.put("java.lang.Long", "kotlin.Long");
      var19.put("java.lang.Double", "kotlin.Double");
      primitiveWrapperFqNames = var19;
      var19 = new HashMap();
      HashMap $this$classFqNames_u24lambda_u244 = var19;
      var2 = false;
      var19.put("java.lang.Object", "kotlin.Any");
      var19.put("java.lang.String", "kotlin.String");
      var19.put("java.lang.CharSequence", "kotlin.CharSequence");
      var19.put("java.lang.Throwable", "kotlin.Throwable");
      var19.put("java.lang.Cloneable", "kotlin.Cloneable");
      var19.put("java.lang.Number", "kotlin.Number");
      var19.put("java.lang.Comparable", "kotlin.Comparable");
      var19.put("java.lang.Enum", "kotlin.Enum");
      var19.put("java.lang.annotation.Annotation", "kotlin.Annotation");
      var19.put("java.lang.Iterable", "kotlin.collections.Iterable");
      var19.put("java.util.Iterator", "kotlin.collections.Iterator");
      var19.put("java.util.Collection", "kotlin.collections.Collection");
      var19.put("java.util.List", "kotlin.collections.List");
      var19.put("java.util.Set", "kotlin.collections.Set");
      var19.put("java.util.ListIterator", "kotlin.collections.ListIterator");
      var19.put("java.util.Map", "kotlin.collections.Map");
      var19.put("java.util.Map$Entry", "kotlin.collections.Map.Entry");
      var19.put("kotlin.jvm.internal.StringCompanionObject", "kotlin.String.Companion");
      var19.put("kotlin.jvm.internal.EnumCompanionObject", "kotlin.Enum.Companion");
      var19.putAll((Map)primitiveFqNames);
      var19.putAll((Map)primitiveWrapperFqNames);
      Collection var10000 = primitiveFqNames.values();
      Intrinsics.checkNotNullExpressionValue(var10000, "<get-values>(...)");
      Iterable $this$associateTo$iv = (Iterable)var10000;
      $i$f$mapValuesTo = false;
      Iterator var26 = $this$associateTo$iv.iterator();

      while(var26.hasNext()) {
         Object element$iv = var26.next();
         Map var32 = (Map)$this$classFqNames_u24lambda_u244;
         String kotlinName = (String)element$iv;
         int var37 = false;
         StringBuilder var39 = (new StringBuilder()).append("kotlin.jvm.internal.");
         Intrinsics.checkNotNull(kotlinName);
         Pair var35 = TuplesKt.to(var39.append(StringsKt.substringAfterLast$default(kotlinName, '.', (String)null, 2, (Object)null)).append("CompanionObject").toString(), kotlinName + ".Companion");
         var32.put(var35.getFirst(), var35.getSecond());
      }

      Map var40 = (Map)$this$classFqNames_u24lambda_u244;
      Iterator var23 = FUNCTION_CLASSES.entrySet().iterator();

      while(var23.hasNext()) {
         Entry var25 = (Entry)var23.next();
         Class klass = (Class)var25.getKey();
         int arity = ((Number)var25.getValue()).intValue();
         $this$classFqNames_u24lambda_u244.put(klass.getName(), "kotlin.Function" + arity);
      }

      classFqNames = var19;
      Map $this$mapValues$iv = (Map)classFqNames;
      $i$f$mapValues = false;
      Map destination$iv$iv = (Map)(new LinkedHashMap(MapsKt.mapCapacity($this$mapValues$iv.size())));
      $i$f$mapValuesTo = false;
      Iterable $this$associateByTo$iv$iv$iv = (Iterable)$this$mapValues$iv.entrySet();
      int $i$f$associateByTo = false;
      Iterator var33 = $this$associateByTo$iv$iv$iv.iterator();

      while(var33.hasNext()) {
         Object element$iv$iv$iv = var33.next();
         Entry it$iv$iv = (Entry)element$iv$iv$iv;
         var11 = false;
         Object var41 = it$iv$iv.getKey();
         Entry var12 = (Entry)element$iv$iv$iv;
         Object var16 = var41;
         int var13 = false;
         String fqName = (String)var12.getValue();
         Intrinsics.checkNotNull(fqName);
         String var17 = StringsKt.substringAfterLast$default(fqName, '.', (String)null, 2, (Object)null);
         destination$iv$iv.put(var16, var17);
      }

      simpleNames = destination$iv$iv;
   }

   @Metadata(
      mv = {2, 1, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\n\u0010\u0012\u001a\u0006\u0012\u0002\b\u00030\u0006J\u0014\u0010\u0013\u001a\u0004\u0018\u00010\u000b2\n\u0010\u0012\u001a\u0006\u0012\u0002\b\u00030\u0006J\u001c\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u00012\n\u0010\u0012\u001a\u0006\u0012\u0002\b\u00030\u0006R&\u0010\u0004\u001a\u001a\u0012\u0010\u0012\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006\u0012\u0004\u0012\u00020\b0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\t\u001a\u001e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b0\nj\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b`\fX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\r\u001a\u001e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b0\nj\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b`\fX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\u000e\u001a\u001e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b0\nj\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b`\fX\u0082\u0004¢\u0006\u0002\n\u0000R\"\u0010\u000f\u001a\u0016\u0012\f\u0012\n \u0010*\u0004\u0018\u00010\u000b0\u000b\u0012\u0004\u0012\u00020\u000b0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"},
      d2 = {"Lkotlin/jvm/internal/ClassReference$Companion;", "", "<init>", "()V", "FUNCTION_CLASSES", "", "Ljava/lang/Class;", "Lkotlin/Function;", "", "primitiveFqNames", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "primitiveWrapperFqNames", "classFqNames", "simpleNames", "kotlin.jvm.PlatformType", "getClassSimpleName", "jClass", "getClassQualifiedName", "isInstance", "", "value", "kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nClassReference.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ClassReference.kt\nkotlin/jvm/internal/ClassReference$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,205:1\n1#2:206\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      @Nullable
      public final String getClassSimpleName(@NotNull Class<?> jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         String var10000;
         if (jClass.isAnonymousClass()) {
            var10000 = null;
         } else if (jClass.isLocalClass()) {
            String name = jClass.getSimpleName();
            Method var9 = jClass.getEnclosingMethod();
            if (var9 != null) {
               Method method = var9;
               int var5 = false;
               Intrinsics.checkNotNull(name);
               var10000 = StringsKt.substringAfter$default(name, method.getName() + '$', (String)null, 2, (Object)null);
               if (var10000 != null) {
                  return var10000;
               }
            }

            Constructor var10 = jClass.getEnclosingConstructor();
            if (var10 != null) {
               Constructor constructor = var10;
               int var6 = false;
               Intrinsics.checkNotNull(name);
               var10000 = StringsKt.substringAfter$default(name, constructor.getName() + '$', (String)null, 2, (Object)null);
            } else {
               Intrinsics.checkNotNull(name);
               var10000 = StringsKt.substringAfter$default(name, '$', (String)null, 2, (Object)null);
            }
         } else if (jClass.isArray()) {
            Class componentType = jClass.getComponentType();
            if (componentType.isPrimitive()) {
               String var3 = (String)ClassReference.simpleNames.get(componentType.getName());
               var10000 = var3 != null ? var3 + "Array" : null;
            } else {
               var10000 = null;
            }

            if (var10000 == null) {
               var10000 = "Array";
            }
         } else {
            var10000 = (String)ClassReference.simpleNames.get(jClass.getName());
            if (var10000 == null) {
               var10000 = jClass.getSimpleName();
            }
         }

         return var10000;
      }

      @Nullable
      public final String getClassQualifiedName(@NotNull Class<?> jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         String var10000;
         if (jClass.isAnonymousClass()) {
            var10000 = null;
         } else if (jClass.isLocalClass()) {
            var10000 = null;
         } else if (jClass.isArray()) {
            Class componentType = jClass.getComponentType();
            if (componentType.isPrimitive()) {
               String var3 = (String)ClassReference.classFqNames.get(componentType.getName());
               var10000 = var3 != null ? var3 + "Array" : null;
            } else {
               var10000 = null;
            }

            if (var10000 == null) {
               var10000 = "kotlin.Array";
            }
         } else {
            var10000 = (String)ClassReference.classFqNames.get(jClass.getName());
            if (var10000 == null) {
               var10000 = jClass.getCanonicalName();
            }
         }

         return var10000;
      }

      public final boolean isInstance(@Nullable Object value, @NotNull Class<?> jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         Map var10000 = ClassReference.FUNCTION_CLASSES;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.get, V of kotlin.collections.MapsKt__MapsKt.get>");
         Integer var3 = (Integer)var10000.get(jClass);
         if (var3 != null) {
            int arity = ((Number)var3).intValue();
            int var5 = false;
            return TypeIntrinsics.isFunctionOfArity(value, arity);
         } else {
            Class objectType = jClass.isPrimitive() ? JvmClassMappingKt.getJavaObjectType(JvmClassMappingKt.getKotlinClass(jClass)) : jClass;
            return objectType.isInstance(value);
         }
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
