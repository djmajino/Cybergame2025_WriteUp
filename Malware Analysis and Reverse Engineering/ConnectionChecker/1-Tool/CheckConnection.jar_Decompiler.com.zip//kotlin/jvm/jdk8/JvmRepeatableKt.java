package kotlin.jvm.jdk8;

import kotlin.Metadata;
import kotlin.SinceKotlin;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004¨\u0006\u0005"},
   d2 = {"JvmRepeatable", "Ljava/lang/annotation/Repeatable;", "Lkotlin/SinceKotlin;", "version", "1.6", "kotlin-stdlib-jdk8"},
   pn = "kotlin.jvm"
)
public final class JvmRepeatableKt {
   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.6"
   )
   public static void JvmRepeatable$annotations() {
   }
}
