package kotlin.reflect.jvm.internal.impl.serialization.deserialization.builtins;

import java.io.IOException;
import java.io.InputStream;
import kotlin.Unit;

public class BuiltInsResourceLoader {
   public InputStream loadResource(String path) throws IOException {
      Module stdlib = Unit.class.getModule();
      return stdlib != null ? stdlib.getResourceAsStream(path) : null;
   }
}
